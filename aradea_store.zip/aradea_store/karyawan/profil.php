<?php
include '../config/koneksi.php';
include '../config/check_session.php';

if ($_SESSION['role'] !== 'Karyawan') {
    header('Location: ../index.php');
    exit;
}

// Ambil data karyawan
$user_id = $_SESSION['user_id'];

// Query yang sudah diperbaiki - tanpa kolom email
$query = "
    SELECT 
        k.id as karyawan_id,
        k.nama_lengkap,
        k.jabatan,
        k.barcode_id,
        k.sisa_cuti,
        k.user_id,
        u.id as user_id_table,
        u.username,
        u.created_at as tanggal_bergabung
    FROM karyawan k 
    JOIN users u ON k.user_id = u.id 
    WHERE u.id = $user_id
";

$result = mysqli_query($koneksi, $query);

if (!$result) {
    die("Error dalam query: " . mysqli_error($koneksi));
}

if (mysqli_num_rows($result) == 0) {
    die("Data karyawan tidak ditemukan untuk user ID: $user_id");
}

$karyawan = mysqli_fetch_assoc($result);

// Simpan karyawan_id yang benar
$karyawan_id = $karyawan['karyawan_id'];

$success = $error = '';

// Proses update password
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Cek password saat ini
    $query_check = "SELECT password FROM users WHERE id = $user_id";
    $result_check = mysqli_query($koneksi, $query_check);
    
    if (!$result_check) {
        $error = "Error: " . mysqli_error($koneksi);
    } elseif (mysqli_num_rows($result_check) > 0) {
        $user_data = mysqli_fetch_assoc($result_check);
        
        if (md5($current_password) == $user_data['password']) {
            if ($new_password == $confirm_password) {
                if (strlen($new_password) >= 6) {
                    $new_password_md5 = md5($new_password);
                    $query_update = "UPDATE users SET password = '$new_password_md5' WHERE id = $user_id";
                    
                    if (mysqli_query($koneksi, $query_update)) {
                        $success = "Password berhasil diubah!";
                    } else {
                        $error = "Gagal mengubah password: " . mysqli_error($koneksi);
                    }
                } else {
                    $error = "Password baru minimal 6 karakter!";
                }
            } else {
                $error = "Password baru dan konfirmasi tidak sama!";
            }
        } else {
            $error = "Password saat ini salah!";
        }
    } else {
        $error = "User tidak ditemukan!";
    }
}

// Hitung cuti yang sudah diambil tahun ini
$query_cuti_taken = "
    SELECT SUM(DATEDIFF(tanggal_akhir, tanggal_mulai) + 1) as total_hari
    FROM cuti 
    WHERE karyawan_id = $karyawan_id
    AND status_approv = 'Approved'
    AND YEAR(tanggal_mulai) = YEAR(CURDATE())
";
$result_cuti_taken = mysqli_query($koneksi, $query_cuti_taken);
$cuti_taken = mysqli_fetch_assoc($result_cuti_taken);
$total_cuti_taken = $cuti_taken['total_hari'] ?? 0;

// Siapkan data untuk sidebar
$nama_karyawan = isset($karyawan['nama_lengkap']) ? $karyawan['nama_lengkap'] : 'User';
$jabatan = isset($karyawan['jabatan']) ? $karyawan['jabatan'] : 'Karyawan';
$barcode_id = isset($karyawan['barcode_id']) ? $karyawan['barcode_id'] : '';
$sisa_cuti = isset($karyawan['sisa_cuti']) ? $karyawan['sisa_cuti'] : 12;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya - HRIS Aradea Store</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3a0ca3;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: #f8fafc;
        }
        
        .main-content {
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
        }
        
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
        }
        
        .profile-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 30px;
            border-radius: 15px 15px 0 0;
        }
        
        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: var(--primary-color);
            border: 5px solid rgba(255, 255, 255, 0.3);
        }
        
        .info-card {
            border-radius: 10px;
            border: none;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            margin-bottom: 20px;
        }
        
        .info-item {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .info-item:last-child {
            border-bottom: none;
        }
        
        .info-label {
            color: #666;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .info-value {
            color: #333;
            font-size: 1.1rem;
        }
        
        .badge-status {
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: 600;
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: 260px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: #1e293b;
            color: white;
            z-index: 1000;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }
            
            .main-content {
                margin-left: 0;
            }
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid #334155;
        }
        
        .user-info {
            padding: 20px;
            border-bottom: 1px solid #334155;
        }
        
        .nav-link {
            color: #cbd5e1;
            padding: 12px 20px;
            transition: all 0.3s;
        }
        
        .nav-link:hover {
            color: white;
            background-color: #334155;
        }
        
        .nav-link.active {
            color: white;
            background-color: #3b82f6;
        }
        
        .nav-link i {
            width: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <div class="sidebar-header">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-store text-white"></i>
                </div>
                <div>
                    <h5 class="mb-0 fw-bold">Aradea Store</h5>
                    <small class="text-muted">Portal Karyawan</small>
                </div>
            </div>
        </div>
        
        <div class="user-info">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-user text-white"></i>
                </div>
                <div>
                    <h6 class="mb-0"><?= htmlspecialchars($nama_karyawan) ?></h6>
                    <small class="text-muted"><?= $jabatan ?></small>
                </div>
            </div>
        </div>
        
        <ul class="nav flex-column mt-3">
            <li class="nav-item">
                <a class="nav-link text-white" href="dashboard.php">
                    <i class="fas fa-home me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="ajukan_cuti.php">
                    <i class="fas fa-calendar-plus me-2"></i> Ajukan Cuti
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="ajukan_lembur.php">
                    <i class="fas fa-clock me-2"></i> Ajukan Lembur
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="status_cuti.php">
                    <i class="fas fa-history me-2"></i> Status Cuti
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="status_lembur.php">
                    <i class="fas fa-tasks me-2"></i> Status Lembur
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white active" href="profil.php">
                    <i class="fas fa-user-circle me-2"></i> Profil Saya
                </a>
            </li>
            <li class="nav-item mt-4">
                <a class="nav-link text-white" href="../logout.php">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </li>
        </ul>
    </nav>
    
    <div class="main-content">
        <div class="mb-4">
            <a href="dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Kembali ke Dashboard
            </a>
        </div>
        
        <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <?= $success ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <!-- Profile Header -->
        <div class="profile-header mb-4">
            <div class="d-flex align-items-center">
                <div class="profile-avatar me-4">
                    <i class="fas fa-user"></i>
                </div>
                <div>
                    <h1 class="h3 mb-2"><?= htmlspecialchars($karyawan['nama_lengkap']) ?></h1>
                    <p class="mb-1">
                        <span class="badge-status bg-light text-dark"><?= $karyawan['jabatan'] ?></span>
                        <span class="badge-status bg-info ms-2"><?= $karyawan['barcode_id'] ?></span>
                    </p>
                    <p class="mb-0 opacity-75">
                        <i class="fas fa-calendar-alt me-1"></i>
                        Bergabung: <?= date('d M Y', strtotime($karyawan['tanggal_bergabung'])) ?>
                    </p>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- Personal Information -->
            <div class="col-md-6">
                <div class="info-card">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-id-card me-2"></i> Informasi Personal</h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="info-item">
                            <div class="info-label">Nama Lengkap</div>
                            <div class="info-value"><?= htmlspecialchars($karyawan['nama_lengkap']) ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Jabatan</div>
                            <div class="info-value"><?= $karyawan['jabatan'] ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">ID Barcode</div>
                            <div class="info-value">
                                <code><?= $karyawan['barcode_id'] ?></code>
                            </div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Username Login</div>
                            <div class="info-value"><?= $karyawan['username'] ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Tanggal Bergabung</div>
                            <div class="info-value">
                                <?= date('d M Y', strtotime($karyawan['tanggal_bergabung'])) ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Cuti Information -->
            <div class="col-md-6">
                <div class="info-card">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-calendar-alt me-2"></i> Informasi Cuti</h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="info-item">
                            <div class="info-label">Sisa Cuti Tahun Ini</div>
                            <div class="info-value">
                                <span class="badge bg-<?= $sisa_cuti <= 5 ? 'warning' : 'success' ?>">
                                    <?= $sisa_cuti ?> hari
                                </span>
                                <?php if ($sisa_cuti <= 5): ?>
                                <small class="text-warning ms-2"><i class="fas fa-exclamation-triangle"></i> Hampir habis</small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Cuti Diambil (<?= date('Y') ?>)</div>
                            <div class="info-value">
                                <?= $total_cuti_taken ?> hari
                            </div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Total Hak Cuti/Tahun</div>
                            <div class="info-value">12 hari</div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Status Akun</div>
                            <div class="info-value">
                                <span class="badge bg-success">Aktif</span>
                            </div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Kode Karyawan</div>
                            <div class="info-value">
                                <?= $karyawan['karyawan_id'] ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Change Password -->
        <div class="info-card mt-4">
            <div class="card-header bg-white">
                <h5 class="mb-0"><i class="fas fa-lock me-2"></i> Ubah Password</h5>
            </div>
            <div class="card-body">
                <form method="POST" id="passwordForm">
                    <input type="hidden" name="update_password" value="1">
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Password Saat Ini</label>
                                <input type="password" 
                                       class="form-control" 
                                       name="current_password" 
                                       required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Password Baru</label>
                                <input type="password" 
                                       class="form-control" 
                                       name="new_password" 
                                       minlength="6"
                                       required>
                                <small class="text-muted">Minimal 6 karakter</small>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Konfirmasi Password</label>
                                <input type="password" 
                                       class="form-control" 
                                       name="confirm_password" 
                                       minlength="6"
                                       required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-between">
                        <button type="reset" class="btn btn-outline-secondary">
                            <i class="fas fa-redo me-2"></i> Reset
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Simpan Password Baru
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Security Notes -->
        <div class="alert alert-info mt-4">
            <h6><i class="fas fa-shield-alt me-2"></i> Keamanan Akun</h6>
            <ul class="mb-0">
                <li>Gunakan password yang kuat dan unik</li>
                <li>Jangan bagikan password Anda kepada siapapun</li>
                <li>Pastikan logout setelah menggunakan komputer bersama</li>
                <li>Segera ubah password jika merasa ada aktivitas mencurigakan</li>
            </ul>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Password form validation
        document.getElementById('passwordForm').addEventListener('submit', function(e) {
            const newPassword = document.querySelector('[name="new_password"]').value;
            const confirmPassword = document.querySelector('[name="confirm_password"]').value;
            
            if (newPassword !== confirmPassword) {
                e.preventDefault();
                alert('Password baru dan konfirmasi tidak sama!');
                return false;
            }
            
            if (newPassword.length < 6) {
                e.preventDefault();
                alert('Password baru minimal 6 karakter!');
                return false;
            }
            
            if (!confirm('Anda yakin ingin mengubah password?')) {
                e.preventDefault();
                return false;
            }
        });
        
        // Auto-hide alert after 5 seconds
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    </script>
</body>
</html>
<?php
mysqli_close($koneksi);
?>