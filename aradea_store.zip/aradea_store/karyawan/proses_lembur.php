<?php
include '../config/koneksi.php';
include '../config/check_session.php';

if ($_SESSION['role'] !== 'Karyawan') {
    header('Location: ../index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    
    // Ambil data karyawan
    $query_karyawan = "
        SELECT k.* FROM karyawan k 
        JOIN users u ON k.user_id = u.id 
        WHERE u.id = $user_id
    ";
    $result_karyawan = mysqli_query($koneksi, $query_karyawan);
    $karyawan = mysqli_fetch_assoc($result_karyawan);
    
    $tanggal = $_POST['tanggal'];
    $jam_mulai = $_POST['jam_mulai'];
    $jam_akhir = $_POST['jam_akhir'];
    $alasan = mysqli_real_escape_string($koneksi, $_POST['alasan']);
    
    // Validasi
    $errors = [];
    
    // Validasi tanggal (hari ini atau besok)
    $today = date('Y-m-d');
    $tomorrow = date('Y-m-d', strtotime('+1 day'));
    
    if ($tanggal != $today && $tanggal != $tomorrow) {
        $errors[] = "Pengajuan lembur hanya untuk hari ini atau besok!";
    }
    
    // Validasi jam
    if ($jam_mulai >= $jam_akhir) {
        $errors[] = "Jam mulai harus lebih awal dari jam selesai!";
    }
    
    // Hitung durasi
    $start = new DateTime($jam_mulai);
    $end = new DateTime($jam_akhir);
    $duration = $start->diff($end);
    $jam_lembur = $duration->h + ($duration->i / 60);
    
    if ($jam_lembur > 4) {
        $errors[] = "Durasi lembur maksimal 4 jam per hari!";
    }
    
    if ($jam_lembur < 1) {
        $errors[] = "Durasi lembur minimal 1 jam!";
    }
    
    // Validasi jam kerja (18:00 - 22:00)
    $jam_mulai_num = (int) str_replace(':', '', $jam_mulai);
    if ($jam_mulai_num < 1800 || $jam_mulai_num > 2100) {
        $errors[] = "Jam mulai lembur antara 18:00 - 21:00!";
    }
    
    // Jika tidak ada error, proses
    if (empty($errors)) {
        $query = "INSERT INTO lembur (karyawan_id, tanggal, jam_mulai, jam_akhir, alasan, status_approv) 
                  VALUES ({$karyawan['id']}, '$tanggal', '$jam_mulai', '$jam_akhir', '$alasan', 'Pending')";
        
        if (mysqli_query($koneksi, $query)) {
            $_SESSION['success_message'] = "Pengajuan lembur berhasil dikirim! Durasi: " . number_format($jam_lembur, 1) . " jam";
            header('Location: status_lembur.php');
            exit;
        } else {
            $_SESSION['error_message'] = "Gagal mengajukan lembur: " . mysqli_error($koneksi);
            header('Location: ajukan_lembur.php');
            exit;
        }
    } else {
        $_SESSION['error_message'] = implode("<br>", $errors);
        header('Location: ajukan_lembur.php');
        exit;
    }
} else {
    header('Location: ajukan_lembur.php');
    exit;
}
?>