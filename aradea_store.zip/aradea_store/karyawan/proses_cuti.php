<?php
include '../config/koneksi.php';
include '../config/check_session.php';

if ($_SESSION['role'] !== 'Karyawan') {
    header('Location: ../index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    
    // Ambil data karyawan
    $query_karyawan = "
        SELECT k.* FROM karyawan k 
        JOIN users u ON k.user_id = u.id 
        WHERE u.id = $user_id
    ";
    $result_karyawan = mysqli_query($koneksi, $query_karyawan);
    $karyawan = mysqli_fetch_assoc($result_karyawan);
    
    $tanggal_mulai = $_POST['tanggal_mulai'];
    $tanggal_akhir = $_POST['tanggal_akhir'];
    $jenis_cuti = mysqli_real_escape_string($koneksi, $_POST['jenis_cuti']);
    $alasan = mysqli_real_escape_string($koneksi, $_POST['alasan']);
    
    // Validasi
    $errors = [];
    
    // Validasi tanggal minimal 3 hari sebelumnya
    $min_date = date('Y-m-d', strtotime('+3 days'));
    if ($tanggal_mulai < $min_date) {
        $errors[] = "Pengajuan cuti harus minimal 3 hari sebelum tanggal cuti!";
    }
    
    if ($tanggal_mulai > $tanggal_akhir) {
        $errors[] = "Tanggal mulai tidak boleh lebih besar dari tanggal akhir!";
    }
    
    // Hitung hari kerja
    $date1 = new DateTime($tanggal_mulai);
    $date2 = new DateTime($tanggal_akhir);
    $days = $date1->diff($date2)->days + 1;
    
    // Count weekdays
    $weekendDays = 0;
    $period = new DatePeriod($date1, new DateInterval('P1D'), $date2->modify('+1 day'));
    foreach ($period as $date) {
        if ($date->format('N') >= 6) {
            $weekendDays++;
        }
    }
    $jumlah_hari = $days - $weekendDays;
    
    // Cek sisa cuti
    if ($karyawan['sisa_cuti'] < $jumlah_hari) {
        $errors[] = "Sisa cuti tidak cukup! Sisa: {$karyawan['sisa_cuti']} hari, Butuh: $jumlah_hari hari";
    }
    
    // Cek max 14 hari
    if ($jumlah_hari > 14) {
        $errors[] = "Maksimal cuti 14 hari kerja per pengajuan!";
    }
    
    // Jika tidak ada error, proses
    if (empty($errors)) {
        $query = "INSERT INTO cuti (karyawan_id, tanggal_mulai, tanggal_akhir, jenis_cuti, alasan, status_approv) 
                  VALUES ({$karyawan['id']}, '$tanggal_mulai', '$tanggal_akhir', '$jenis_cuti', '$alasan', 'Pending')";
        
        if (mysqli_query($koneksi, $query)) {
            $_SESSION['success_message'] = "Pengajuan cuti berhasil dikirim! Status: Menunggu Persetujuan";
            header('Location: status_cuti.php');
            exit;
        } else {
            $_SESSION['error_message'] = "Gagal mengajukan cuti: " . mysqli_error($koneksi);
            header('Location: ajukan_cuti.php');
            exit;
        }
    } else {
        $_SESSION['error_message'] = implode("<br>", $errors);
        header('Location: ajukan_cuti.php');
        exit;
    }
} else {
    header('Location: ajukan_cuti.php');
    exit;
}
?>