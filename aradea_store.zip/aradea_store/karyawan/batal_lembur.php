<?php
include '../config/koneksi.php';
include '../config/check_session.php';

if ($_SESSION['role'] !== 'Karyawan') {
    header('Location: ../index.php');
    exit;
}

if (isset($_GET['id'])) {
    $lembur_id = intval($_GET['id']);
    $user_id = $_SESSION['user_id'];
    
    // Cek apakah lembur milik user ini dan masih pending
    $query_check = "
        SELECT l.* FROM lembur l
        JOIN karyawan k ON l.karyawan_id = k.id
        JOIN users u ON k.user_id = u.id
        WHERE l.id = $lembur_id AND u.id = $user_id AND l.status_approv = 'Pending'
    ";
    
    $result_check = mysqli_query($koneksi, $query_check);
    
    if (mysqli_num_rows($result_check) > 0) {
        $query_delete = "DELETE FROM lembur WHERE id = $lembur_id";
        
        if (mysqli_query($koneksi, $query_delete)) {
            $_SESSION['success_message'] = "Pengajuan lembur berhasil dibatalkan!";
        } else {
            $_SESSION['error_message'] = "Gagal membatalkan lembur: " . mysqli_error($koneksi);
        }
    } else {
        $_SESSION['error_message'] = "Lembur tidak ditemukan atau tidak dapat dibatalkan!";
    }
}

header('Location: status_lembur.php');
exit;
?>