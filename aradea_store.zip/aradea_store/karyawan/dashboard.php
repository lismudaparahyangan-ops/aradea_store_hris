<?php
include '../config/koneksi.php';
include '../config/check_session.php';

// Cek role karyawan
if ($_SESSION['role'] !== 'Karyawan') {
    header('Location: ../index.php');
    exit;
}

// Debug mode
$debug_mode = true; // Set false di production

// Ambil data karyawan dengan error handling - PERBAIKAN DI SINI
$user_id = $_SESSION['user_id'];
$query_karyawan = "
    SELECT k.*, u.username 
    FROM karyawan k 
    JOIN users u ON k.user_id = u.id 
    WHERE u.id = $user_id
";

$result_karyawan = mysqli_query($koneksi, $query_karyawan);

if (!$result_karyawan) {
    // Jika query gagal, tampilkan error dan hentikan
    if ($debug_mode) {
        die("Query Error: " . mysqli_error($koneksi) . "<br>Query: " . $query_karyawan);
    } else {
        die("Terjadi kesalahan sistem. Silakan hubungi administrator.");
    }
}

$karyawan = mysqli_fetch_assoc($result_karyawan);

// Jika karyawan tidak ditemukan
if (!$karyawan) {
    die("Data karyawan tidak ditemukan. Silakan hubungi administrator.");
}

// Inisialisasi variabel dengan nilai default
$data_cuti = ['total' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0];
$data_lembur = ['total' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'total_jam_approved' => 0];
$data_absensi = ['total_hadir' => 0, 'terlambat' => 0];

// ==============================================
// CEK TABEL DAN QUERY DENGAN ERROR HANDLING
// ==============================================

// 1. Query cuti (jika tabel cuti ada)
$query_cuti = "
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status_approv = 'Pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status_approv = 'Approved' THEN 1 ELSE 0 END) as approved,
        SUM(CASE WHEN status_approv = 'Rejected' THEN 1 ELSE 0 END) as rejected
    FROM cuti 
    WHERE karyawan_id = " . $karyawan['id']
;

$result_cuti = mysqli_query($koneksi, $query_cuti);
if ($result_cuti) {
    $data_cuti = mysqli_fetch_assoc($result_cuti);
    // Jika null, set ke default
    if (!$data_cuti) {
        $data_cuti = ['total' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0];
    }
}

// 2. Query lembur (jika tabel lembur ada)
$query_lembur = "
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status_approv = 'Pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status_approv = 'Approved' THEN 1 ELSE 0 END) as approved,
        SUM(CASE WHEN status_approv = 'Rejected' THEN 1 ELSE 0 END) as rejected,
        SUM(CASE WHEN status_approv = 'Approved' THEN TIME_TO_SEC(TIMEDIFF(jam_akhir, jam_mulai)) / 3600 ELSE 0 END) as total_jam_approved
    FROM lembur 
    WHERE karyawan_id = " . $karyawan['id']
;

$result_lembur = mysqli_query($koneksi, $query_lembur);
if ($result_lembur) {
    $data_lembur = mysqli_fetch_assoc($result_lembur);
    if (!$data_lembur) {
        $data_lembur = ['total' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'total_jam_approved' => 0];
    }
}

// 3. Query absensi (jika tabel absensi ada)
$current_month = date('Y-m');
$query_absensi = "
    SELECT 
        COUNT(*) as total_hadir,
        SUM(CASE WHEN TIME(jam_masuk) > '08:00:00' THEN 1 ELSE 0 END) as terlambat
    FROM absensi 
    WHERE karyawan_id = " . $karyawan['id'] . "
    AND DATE_FORMAT(tanggal, '%Y-%m') = '$current_month'
    AND status_kehadiran = 'Hadir'
";

$result_absensi = mysqli_query($koneksi, $query_absensi);
if ($result_absensi) {
    $data_absensi = mysqli_fetch_assoc($result_absensi);
    if (!$data_absensi) {
        $data_absensi = ['total_hadir' => 0, 'terlambat' => 0];
    }
}

// ==============================================
// DEBUG INFO (Hanya tampil jika debug_mode = true)
// ==============================================
if ($debug_mode) {
    echo "<div style='background: #f8f9fa; padding: 15px; margin-bottom: 20px; border-radius: 5px; border-left: 4px solid #007bff;'>";
    echo "<h5>Debug Information</h5>";
    echo "User ID: " . $user_id . "<br>";
    echo "Karyawan ID: " . ($karyawan['id'] ?? 'Not found') . "<br>";
    echo "Karyawan Name: " . ($karyawan['nama_lengkap'] ?? 'Not found') . "<br>";
    echo "Username: " . ($karyawan['username'] ?? 'Not found') . "<br>";
    
    // Cek tabel yang ada
   /* $tables_query = "SHOW TABLES";
    $tables_result = mysqli_query($koneksi, $tables_query);
    if ($tables_result) {
        echo "Tables in database: ";
        $tables = [];
        while ($row = mysqli_fetch_array($tables_result)) {
            $tables[] = $row[0];
        }
        echo implode(', ', $tables);
    }
    echo "</div>"; */
}
?>
<!DOCTYPE html>
<html lang="id" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Karyawan - HRIS Aradea Store</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3a0ca3;
            --sidebar-width: 260px;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: #f8fafc;
            overflow-x: hidden;
        }
        
        .sidebar {
            width: var(--sidebar-width);
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: linear-gradient(180deg, #1e293b, #0f172a);
            color: white;
            z-index: 1000;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
        }
        
        .nav-link {
            color: #cbd5e1;
            padding: 12px 20px;
            border-left: 4px solid transparent;
            transition: all 0.2s;
            border-radius: 0;
            font-weight: 500;
        }
        
        .nav-link:hover, .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            border-left-color: var(--primary-color);
        }
        
        .nav-link i {
            width: 20px;
            margin-right: 10px;
        }
        
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            min-height: 100vh;
            transition: all 0.3s;
        }
        
        .stats-card {
            border-radius: 12px;
            border: none;
            transition: transform 0.3s, box-shadow 0.3s;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        }
        
        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
        }
        
        .quick-action-card {
            border-radius: 12px;
            transition: all 0.3s;
            border: 2px solid transparent;
            cursor: pointer;
        }
        
        .quick-action-card:hover {
            transform: translateY(-5px);
            border-color: var(--primary-color);
            box-shadow: 0 10px 20px rgba(67, 97, 238, 0.1);
        }
        
        @media (max-width: 768px) {
            .sidebar {
                margin-left: -260px;
            }
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            .sidebar.active {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <div class="sidebar-header p-4">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-store text-white fa-lg"></i>
                </div>
                <div>
                    <h5 class="mb-0 fw-bold">Aradea Store</h5>
                    <small class="text-muted">Portal Karyawan</small>
                </div>
            </div>
        </div>
        
        <div class="user-info p-3 border-bottom border-secondary">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-user text-white"></i>
                </div>
                <div>
                    <h6 class="mb-0 fw-semibold"><?= htmlspecialchars($karyawan['nama_lengkap'] ?? 'Karyawan') ?></h6>
                    <small class="text-muted">
                        <i class="fas fa-briefcase me-1"></i><?= $karyawan['jabatan'] ?? 'Karyawan' ?>
                    </small>
                </div>
            </div>
            <div class="mt-2">
                <small class="text-muted">
                    <i class="fas fa-id-badge me-1"></i>ID: <?= $karyawan['barcode_id'] ?? 'N/A' ?>
                </small>
            </div>
        </div>
        
        <ul class="nav flex-column mt-3">
            <li class="nav-item">
                <a class="nav-link active" href="dashboard.php">
                    <i class="fas fa-home"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="ajukan_cuti.php">
                    <i class="fas fa-calendar-plus"></i> Ajukan Cuti
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="ajukan_lembur.php">
                    <i class="fas fa-clock"></i> Ajukan Lembur
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="status_cuti.php">
                    <i class="fas fa-history"></i> Status Cuti
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="status_lembur.php">
                    <i class="fas fa-tasks"></i> Status Lembur
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="absensi_karyawan.php">
                    <i class="fas fa-tasks"></i> Absensi Karyawan
                </a>
            </li>
            <li class="nav-item mt-4">
                <a class="nav-link" href="../logout.php">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
        
        <div class="sidebar-footer position-absolute bottom-0 w-100 p-3">
            <div class="text-center">
                <small class="text-muted">
                    HRIS Aradea Store<br>
                    &copy; <?= date('Y') ?> v1.0
                </small>
            </div>
        </div>
    </nav>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navbar -->
        <nav class="navbar navbar-light bg-white rounded-3 shadow-sm mb-4">
            <div class="container-fluid">
                <button class="btn btn-outline-primary d-md-none" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                
                <div class="d-flex align-items-center">
                    <span class="navbar-text me-3 d-none d-md-block">
                        <i class="fas fa-calendar-day me-1 text-primary"></i>
                        <?= date('l, d F Y') ?>
                    </span>
                    
                    <!-- Notifications -->
                    <?php 
                    $total_notif = ($data_cuti['pending'] ?? 0) + ($data_lembur['pending'] ?? 0);
                    if ($total_notif > 0): 
                    ?>
                    <div class="dropdown">
                        <button class="btn btn-light position-relative" type="button" data-bs-toggle="dropdown">
                            <i class="fas fa-bell text-primary fa-lg"></i>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                <?= $total_notif ?>
                            </span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                            <li><h6 class="dropdown-header">Notifikasi</h6></li>
                            <?php if (($data_cuti['pending'] ?? 0) > 0): ?>
                            <li>
                                <a class="dropdown-item" href="status_cuti.php">
                                    <i class="fas fa-calendar-times text-warning me-2"></i>
                                    <?= $data_cuti['pending'] ?> cuti menunggu
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if (($data_lembur['pending'] ?? 0) > 0): ?>
                            <li>
                                <a class="dropdown-item" href="status_lembur.php">
                                    <i class="fas fa-clock text-info me-2"></i>
                                    <?= $data_lembur['pending'] ?> lembur menunggu
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
        
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-2 fw-bold text-gray-800">Dashboard Karyawan</h1>
                <p class="text-muted">
                    <i class="fas fa-user-check me-1 text-success"></i>
                    Selamat datang, <span class="fw-semibold"><?= htmlspecialchars($karyawan['nama_lengkap'] ?? 'Karyawan') ?></span>
                </p>
            </div>
            <div class="d-flex gap-2">
                <div class="badge bg-primary p-2">
                    <i class="fas fa-id-card me-1"></i> <?= $karyawan['barcode_id'] ?? 'N/A' ?>
                </div>
                <div class="badge bg-info p-2">
                    <i class="fas fa-calendar-alt me-1"></i> Sisa Cuti: <?= $karyawan['sisa_cuti'] ?? 12 ?> hari
                </div>
            </div>
        </div>
        
        <!-- Database Warning (if tables missing) -->
        <?php 
        // Cek apakah tabel cuti dan lembur ada
        $check_cuti_table = mysqli_query($koneksi, "SHOW TABLES LIKE 'cuti'");
        $check_lembur_table = mysqli_query($koneksi, "SHOW TABLES LIKE 'lembur'");
        $check_absensi_table = mysqli_query($koneksi, "SHOW TABLES LIKE 'absensi'");
        
        if (!$check_cuti_table || mysqli_num_rows($check_cuti_table) == 0): 
        ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <strong>Tabel 'cuti' belum dibuat.</strong> Beberapa fitur tidak tersedia.
            <br>
            <small>Jalankan script SQL untuk membuat tabel cuti, lembur, dan absensi.</small>
            <br>
            <a href="../setup_tables.php" class="btn btn-sm btn-outline-primary mt-2">
                <i class="fas fa-database me-1"></i> Setup Database
            </a>
        </div>
        <?php endif; ?>
        
        <!-- Stats Overview -->
        <div class="row g-4 mb-5">
            <div class="col-xl-3 col-md-6">
                <div class="card stats-card border-0">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Sisa Cuti</h6>
                                <h2 class="mb-0 fw-bold"><?= $karyawan['sisa_cuti'] ?? 12 ?></h2>
                                <small class="text-muted">Hari tersedia</small>
                            </div>
                            <div class="stat-icon" style="background: rgba(67, 97, 238, 0.1);">
                                <i class="fas fa-calendar-alt text-primary"></i>
                            </div>
                        </div>
                        <div class="mt-3">
                            <?php if (($karyawan['sisa_cuti'] ?? 12) <= 5): ?>
                            <span class="text-warning"><i class="fas fa-exclamation-triangle me-1"></i> Hampir habis</span>
                            <?php else: ?>
                            <span class="text-success"><i class="fas fa-check-circle me-1"></i> Cukup</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card stats-card border-0">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Kehadiran Bulan Ini</h6>
                                <h2 class="mb-0 fw-bold"><?= $data_absensi['total_hadir'] ?? 0 ?></h2>
                                <small class="text-muted">Hari hadir</small>
                            </div>
                            <div class="stat-icon" style="background: rgba(40, 167, 69, 0.1);">
                                <i class="fas fa-user-check text-success"></i>
                            </div>
                        </div>
                        <div class="mt-3">
                            <span class="text-primary">
                                <i class="fas fa-clock me-1"></i>
                                <?= $data_absensi['terlambat'] ?? 0 ?>x terlambat
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card stats-card border-0">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Cuti Disetujui</h6>
                                <h2 class="mb-0 fw-bold"><?= $data_cuti['approved'] ?? 0 ?></h2>
                                <small class="text-muted">Pengajuan cuti</small>
                            </div>
                            <div class="stat-icon" style="background: rgba(255, 193, 7, 0.1);">
                                <i class="fas fa-calendar-check text-warning"></i>
                            </div>
                        </div>
                        <div class="mt-3">
                            <?php if (($data_cuti['pending'] ?? 0) > 0): ?>
                            <span class="text-warning">
                                <i class="fas fa-clock me-1"></i>
                                <?= $data_cuti['pending'] ?> menunggu
                            </span>
                            <?php else: ?>
                            <span class="text-success"><i class="fas fa-check me-1"></i> Selesai</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card stats-card border-0">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Lembur Disetujui</h6>
                                <h2 class="mb-0 fw-bold"><?= $data_lembur['approved'] ?? 0 ?></h2>
                                <small class="text-muted"><?= number_format($data_lembur['total_jam_approved'] ?? 0, 1) ?> jam</small>
                            </div>
                            <div class="stat-icon" style="background: rgba(111, 66, 193, 0.1);">
                                <i class="fas fa-clock text-purple"></i>
                            </div>
                        </div>
                        <div class="mt-3">
                            <?php if (($data_lembur['pending'] ?? 0) > 0): ?>
                            <span class="text-info">
                                <i class="fas fa-hourglass-half me-1"></i>
                                <?= $data_lembur['pending'] ?> menunggu
                            </span>
                            <?php else: ?>
                            <span class="text-success"><i class="fas fa-check me-1"></i> Selesai</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="row mb-5">
            <div class="col-12">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white py-3">
                        <h5 class="mb-0"><i class="fas fa-bolt text-primary me-2"></i> Akses Cepat</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-3 col-6">
                                <a href="ajukan_cuti.php" class="text-decoration-none">
                                    <div class="card quick-action-card text-center p-4">
                                        <div class="mb-2">
                                            <i class="fas fa-calendar-plus fa-3x text-primary"></i>
                                        </div>
                                        <h6 class="mb-1">Ajukan Cuti</h6>
                                        <small class="text-muted">Pengajuan cuti tahunan</small>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3 col-6">
                                <a href="ajukan_lembur.php" class="text-decoration-none">
                                    <div class="card quick-action-card text-center p-4">
                                        <div class="mb-2">
                                            <i class="fas fa-clock fa-3x text-success"></i>
                                        </div>
                                        <h6 class="mb-1">Ajukan Lembur</h6>
                                        <small class="text-muted">Kerja lembur</small>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3 col-6">
                                <a href="status_cuti.php" class="text-decoration-none">
                                    <div class="card quick-action-card text-center p-4">
                                        <div class="mb-2">
                                            <i class="fas fa-history fa-3x text-info"></i>
                                        </div>
                                        <h6 class="mb-1">Status Cuti</h6>
                                        <small class="text-muted">
                                            <?= $data_cuti['pending'] ?? 0 ?> menunggu
                                        </small>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3 col-6">
                                <a href="status_lembur.php" class="text-decoration-none">
                                    <div class="card quick-action-card text-center p-4">
                                        <div class="mb-2">
                                            <i class="fas fa-tasks fa-3x text-warning"></i>
                                        </div>
                                        <h6 class="mb-1">Status Lembur</h6>
                                        <small class="text-muted">
                                            <?= $data_lembur['pending'] ?? 0 ?> menunggu
                                        </small>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Recent Activity -->
        <div class="row">
            <div class="col-lg-8">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white py-3">
                        <h5 class="mb-0"><i class="fas fa-history me-2"></i> Aktivitas Terbaru</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        // Coba query aktivitas dengan error handling
                        $query_aktivitas = "
                            (SELECT 
                                tanggal_mulai as tanggal,
                                'Cuti' as jenis,
                                CONCAT('Cuti ', jenis_cuti, ' (', 
                                DATEDIFF(tanggal_akhir, tanggal_mulai) + 1, ' hari)') as keterangan,
                                status_approv as status
                            FROM cuti 
                            WHERE karyawan_id = " . $karyawan['id'] . ")
                            UNION ALL
                            (SELECT 
                                tanggal,
                                'Lembur' as jenis,
                                CONCAT('Lembur ', TIME_FORMAT(jam_mulai, '%H:%i'), ' - ', 
                                TIME_FORMAT(jam_akhir, '%H:%i')) as keterangan,
                                status_approv as status
                            FROM lembur 
                            WHERE karyawan_id = " . $karyawan['id'] . ")
                            ORDER BY tanggal DESC
                            LIMIT 5
                        ";
                        
                        $result_aktivitas = mysqli_query($koneksi, $query_aktivitas);
                        ?>
                        
                        <?php if (!$result_aktivitas): ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            Belum ada aktivitas terbaru atau tabel belum tersedia.
                        </div>
                        <?php elseif (mysqli_num_rows($result_aktivitas) == 0): ?>
                        <div class="text-center py-4">
                            <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                            <p class="text-muted mb-0">Belum ada aktivitas terbaru</p>
                        </div>
                        <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>Jenis</th>
                                        <th>Keterangan</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($aktivitas = mysqli_fetch_assoc($result_aktivitas)): ?>
                                    <tr>
                                        <td><?= date('d M Y', strtotime($aktivitas['tanggal'])) ?></td>
                                        <td>
                                            <span class="badge bg-<?= $aktivitas['jenis'] == 'Cuti' ? 'info' : 'warning' ?>">
                                                <?= $aktivitas['jenis'] ?>
                                            </span>
                                        </td>
                                        <td><?= $aktivitas['keterangan'] ?></td>
                                        <td>
                                            <?php
                                            $badge_class = [
                                                'Pending' => 'warning',
                                                'Approved' => 'success',
                                                'Rejected' => 'danger'
                                            ][$aktivitas['status']] ?? 'secondary';
                                            ?>
                                            <span class="badge bg-<?= $badge_class ?>">
                                                <?= $aktivitas['status'] ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white py-3">
                        <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i> Informasi Penting</h5>
                    </div>
                    <div class="card-body">
                        <ul class="list-unstyled mb-0">
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <small>Ajukan cuti minimal 3 hari kerja sebelumnya</small>
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <small>Lembur harus diajukan maksimal H-1</small>
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <small>Cuti tahunan maksimal 12 hari/tahun</small>
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <small>Jam kerja normal: 08:00 - 17:00</small>
                            </li>
                            <li>
                                <i class="fas fa-phone-alt text-primary me-2"></i>
                                <small>HR Contact: 021-1234567 ext. 101</small>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Toggle sidebar on mobile
        document.getElementById('sidebarToggle')?.addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
        
        // Auto update time
        function updateTime() {
            const now = new Date();
            const options = { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            };
            const timeElement = document.querySelector('.navbar-text');
            if (timeElement) {
                timeElement.innerHTML = 
                    `<i class="fas fa-calendar-day me-1 text-primary"></i> ${now.toLocaleDateString('id-ID', options)}`;
            }
        }
        
        updateTime();
        setInterval(updateTime, 60000);
    </script>
</body>
</html>
<?php
// Clean up
if (isset($result_karyawan)) mysqli_free_result($result_karyawan);
if (isset($result_cuti) && $result_cuti) mysqli_free_result($result_cuti);
if (isset($result_lembur) && $result_lembur) mysqli_free_result($result_lembur);
if (isset($result_absensi) && $result_absensi) mysqli_free_result($result_absensi);
if (isset($result_aktivitas) && $result_aktivitas) mysqli_free_result($result_aktivitas);
if (isset($check_cuti_table)) mysqli_free_result($check_cuti_table);
if (isset($check_lembur_table)) mysqli_free_result($check_lembur_table);
if (isset($check_absensi_table)) mysqli_free_result($check_absensi_table);

mysqli_close($koneksi);
?>