<?php
include '../config/koneksi.php';
include '../config/check_session.php';

if ($_SESSION['role'] !== 'Karyawan') {
    header('Location: ../index.php');
    exit;
}

// Ambil data karyawan
$user_id = $_SESSION['user_id'];
$query_karyawan = "
    SELECT k.* FROM karyawan k 
    JOIN users u ON k.user_id = u.id 
    WHERE u.id = $user_id
";
$result_karyawan = mysqli_query($koneksi, $query_karyawan);
$karyawan = mysqli_fetch_assoc($result_karyawan);

$success = $error = '';

// Proses pengajuan cuti
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tanggal_mulai = $_POST['tanggal_mulai'];
    $tanggal_akhir = $_POST['tanggal_akhir'];
    $jenis_cuti = mysqli_real_escape_string($koneksi, $_POST['jenis_cuti']);
    $alasan = mysqli_real_escape_string($koneksi, $_POST['alasan']);
    
    // Validasi tanggal
    $today = date('Y-m-d');
    $min_date = date('Y-m-d', strtotime('+3 days'));
    
    if ($tanggal_mulai < $min_date) {
        $error = "Pengajuan cuti harus minimal 3 hari sebelum tanggal cuti!";
    } elseif ($tanggal_mulai > $tanggal_akhir) {
        $error = "Tanggal mulai tidak boleh lebih besar dari tanggal akhir!";
    } else {
        // Hitung jumlah hari cuti (exclude weekends)
        $date1 = new DateTime($tanggal_mulai);
        $date2 = new DateTime($tanggal_akhir);
        $interval = $date1->diff($date2);
        $days = $interval->days + 1;
        
        // Count weekdays only
        $weekendDays = 0;
        $period = new DatePeriod($date1, new DateInterval('P1D'), $date2->modify('+1 day'));
        foreach ($period as $date) {
            if ($date->format('N') >= 6) { // 6 = Saturday, 7 = Sunday
                $weekendDays++;
            }
        }
        $jumlah_hari = $days - $weekendDays;
        
        // Cek apakah sisa cuti cukup
        if ($karyawan['sisa_cuti'] >= $jumlah_hari) {
            $query = "INSERT INTO cuti (karyawan_id, tanggal_mulai, tanggal_akhir, jenis_cuti, alasan, status_approv) 
                      VALUES ({$karyawan['id']}, '$tanggal_mulai', '$tanggal_akhir', '$jenis_cuti', '$alasan', 'Pending')";
            
            if (mysqli_query($koneksi, $query)) {
                $success = "Pengajuan cuti berhasil dikirim! Status: <strong>Menunggu Persetujuan</strong>";
            } else {
                $error = "Gagal mengajukan cuti: " . mysqli_error($koneksi);
            }
        } else {
            $error = "Sisa cuti tidak cukup!<br>
                     Sisa cuti Anda: <strong>{$karyawan['sisa_cuti']} hari</strong><br>
                     Butuh: <strong>$jumlah_hari hari</strong>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajukan Cuti - HRIS Aradea Store</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Flatpickr -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3a0ca3;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        
        .form-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .form-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 25px;
        }
        
        .form-label {
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
        }
        
        .form-control, .form-select, .form-textarea {
            border-radius: 8px;
            padding: 10px 15px;
            border: 1px solid #ddd;
            transition: all 0.3s;
        }
        
        .form-control:focus, .form-select:focus, .form-textarea:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(67, 97, 238, 0.25);
        }
        
        .btn-submit {
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            border: none;
            padding: 12px 30px;
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.3s;
        }
        
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 7px 14px rgba(67, 97, 238, 0.3);
        }
        
        .info-box {
            background: #e7f3ff;
            border-left: 4px solid var(--primary-color);
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .calc-box {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            border: 1px solid #dee2e6;
        }
    </style>
</head>
<body>
    <!-- Include Sidebar from dashboard -->
    <?php 
    // Simpan sidebar di variable untuk digunakan di semua halaman karyawan
    $sidebar = '
    <nav class="sidebar" style="width: 260px; height: 100vh; position: fixed; left: 0; top: 0; background: #1e293b; color: white;">
        <div class="sidebar-header p-3">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-store text-white"></i>
                </div>
                <div>
                    <h5 class="mb-0 fw-bold">Aradea Store</h5>
                    <small class="text-muted">Portal Karyawan</small>
                </div>
            </div>
        </div>
        
        <div class="user-info p-3 border-bottom border-secondary">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-user text-white"></i>
                </div>
                <div>
                    <h6 class="mb-0">' . htmlspecialchars($karyawan['nama_lengkap']) . '</h6>
                    <small class="text-muted">' . $karyawan['jabatan'] . '</small>
                </div>
            </div>
        </div>
        
        <ul class="nav flex-column mt-3">
            <li class="nav-item">
                <a class="nav-link text-white" href="dashboard.php">
                    <i class="fas fa-home me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white active" href="ajukan_cuti.php">
                    <i class="fas fa-calendar-plus me-2"></i> Ajukan Cuti
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="ajukan_lembur.php">
                    <i class="fas fa-clock me-2"></i> Ajukan Lembur
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="status_cuti.php">
                    <i class="fas fa-history me-2"></i> Status Cuti
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="status_lembur.php">
                    <i class="fas fa-tasks me-2"></i> Status Lembur
                </a>
            </li>
            <li class="nav-item mt-4">
                <a class="nav-link text-white" href="../logout.php">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </li>
        </ul>
    </nav>';
    
    echo $sidebar;
    ?>
    
    <div class="main-content" style="margin-left: 260px; padding: 30px;">
        <div class="form-container">
            <div class="form-header">
                <div class="d-flex align-items-center">
                    <div class="bg-white rounded-circle p-2 me-3">
                        <i class="fas fa-calendar-plus text-primary fa-lg"></i>
                    </div>
                    <div>
                        <h2 class="mb-1">Pengajuan Cuti</h2>
                        <p class="mb-0 opacity-75">HRIS Aradea Store</p>
                    </div>
                </div>
            </div>
            
            <div class="p-4">
                <div class="mb-4">
                    <a href="dashboard.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-2"></i> Kembali ke Dashboard
                    </a>
                </div>
                
                <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    <?= $success ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <?= $error ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php endif; ?>
                
                <div class="info-box mb-4">
                    <i class="fas fa-info-circle me-2 text-primary"></i>
                    <strong>Informasi:</strong> 
                    Pengajuan cuti harus diajukan minimal <strong>3 hari kerja</strong> sebelum tanggal cuti dimulai. 
                    Status akan diperiksa oleh admin dan akan diinformasikan melalui sistem.
                </div>
                
                <form method="POST" id="cutiForm">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="calc-box">
                                <h6 class="mb-3"><i class="fas fa-calculator me-2"></i> Informasi Cuti Anda</h6>
                                <table class="table table-sm mb-0">
                                    <tr>
                                        <td>Sisa Cuti Tahun Ini</td>
                                        <td class="text-end"><strong><?= $karyawan['sisa_cuti'] ?> hari</strong></td>
                                    </tr>
                                    <tr>
                                        <td>Minimal Pengajuan</td>
                                        <td class="text-end">3 hari sebelum</td>
                                    </tr>
                                    <tr>
                                        <td>Maksimal Per Pengajuan</td>
                                        <td class="text-end">14 hari kerja</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="calc-box">
                                <h6 class="mb-3"><i class="fas fa-calendar-alt me-2"></i> Periode Cuti</h6>
                                <div id="periodeInfo">
                                    <p class="text-muted mb-2">Pilih tanggal untuk menghitung hari</p>
                                    <p class="mb-0">Jumlah hari: <span id="jumlahHari" class="fw-bold">0 hari</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <h5 class="mb-3"><i class="fas fa-edit me-2"></i> Form Pengajuan Cuti</h5>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Tanggal Mulai Cuti <span class="text-danger">*</span></label>
                                <input type="date" 
                                       class="form-control" 
                                       name="tanggal_mulai" 
                                       id="tanggal_mulai"
                                       min="<?= date('Y-m-d', strtotime('+3 days')) ?>"
                                       required>
                                <small class="text-muted">Minimal 3 hari dari hari ini</small>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Tanggal Selesai Cuti <span class="text-danger">*</span></label>
                                <input type="date" 
                                       class="form-control" 
                                       name="tanggal_akhir" 
                                       id="tanggal_akhir"
                                       required>
                                <small class="text-muted">Maksimal 14 hari kerja</small>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Jenis Cuti <span class="text-danger">*</span></label>
                        <select class="form-select" name="jenis_cuti" required>
                            <option value="">Pilih Jenis Cuti</option>
                            <option value="Cuti Tahunan">Cuti Tahunan</option>
                            <option value="Cuti Sakit">Cuti Sakit (dengan surat dokter)</option>
                            <option value="Cuti Melahirkan">Cuti Melahirkan</option>
                            <option value="Cuti Pernikahan">Cuti Pernikahan</option>
                            <option value="Cuti Keluarga">Cuti Keluarga Meninggal</option>
                            <option value="Cuti Lainnya">Cuti Lainnya</option>
                        </select>
                    </div>
                    
                    <div class="mb-4">
                        <label class="form-label">Alasan Cuti <span class="text-danger">*</span></label>
                        <textarea class="form-control form-textarea" 
                                  name="alasan" 
                                  rows="4" 
                                  placeholder="Jelaskan alasan pengajuan cuti secara detail..."
                                  required></textarea>
                        <small class="text-muted">Minimal 50 karakter</small>
                    </div>
                    
                    <div class="d-flex justify-content-between">
                        <button type="reset" class="btn btn-outline-secondary">
                            <i class="fas fa-redo me-2"></i> Reset Form
                        </button>
                        <button type="submit" class="btn btn-submit text-white">
                            <i class="fas fa-paper-plane me-2"></i> Ajukan Cuti
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Flatpickr -->
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    
    <script>
        // Calculate days between dates
        function calculateDays() {
            const start = document.getElementById('tanggal_mulai').value;
            const end = document.getElementById('tanggal_akhir').value;
            
            if (start && end) {
                const startDate = new Date(start);
                const endDate = new Date(end);
                const diffTime = Math.abs(endDate - startDate);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
                
                // Exclude weekends
                let weekdays = 0;
                const currentDate = new Date(startDate);
                while (currentDate <= endDate) {
                    const dayOfWeek = currentDate.getDay();
                    if (dayOfWeek !== 0 && dayOfWeek !== 6) { // 0 = Sunday, 6 = Saturday
                        weekdays++;
                    }
                    currentDate.setDate(currentDate.getDate() + 1);
                }
                
                document.getElementById('jumlahHari').textContent = `${weekdays} hari kerja (${diffDays} hari total)`;
                
                // Check if enough leave balance
                const sisaCuti = <?= $karyawan['sisa_cuti'] ?>;
                if (weekdays > sisaCuti) {
                    document.getElementById('jumlahHari').className = 'fw-bold text-danger';
                    document.getElementById('jumlahHari').innerHTML += 
                        ' <i class="fas fa-exclamation-triangle"></i> Melebihi sisa cuti!';
                } else if (weekdays > 14) {
                    document.getElementById('jumlahHari').className = 'fw-bold text-warning';
                    document.getElementById('jumlahHari').innerHTML += 
                        ' <i class="fas fa-exclamation-triangle"></i> Melebihi batas maksimal!';
                } else {
                    document.getElementById('jumlahHari').className = 'fw-bold text-success';
                }
            }
        }
        
        // Set min date for end date based on start date
        document.getElementById('tanggal_mulai').addEventListener('change', function() {
            const startDate = this.value;
            const endDateInput = document.getElementById('tanggal_akhir');
            if (startDate) {
                const minEndDate = new Date(startDate);
                minEndDate.setDate(minEndDate.getDate() + 1);
                endDateInput.min = minEndDate.toISOString().split('T')[0];
                
                const maxEndDate = new Date(startDate);
                maxEndDate.setDate(maxEndDate.getDate() + 30); // Max 30 days
                endDateInput.max = maxEndDate.toISOString().split('T')[0];
                
                calculateDays();
            }
        });
        
        document.getElementById('tanggal_akhir').addEventListener('change', calculateDays);
        
        // Form validation
        document.getElementById('cutiForm').addEventListener('submit', function(e) {
            const startDate = document.getElementById('tanggal_mulai').value;
            const endDate = document.getElementById('tanggal_akhir').value;
            const jenisCuti = document.querySelector('[name="jenis_cuti"]').value;
            const alasan = document.querySelector('[name="alasan"]').value;
            
            if (!startDate || !endDate || !jenisCuti || alasan.length < 50) {
                e.preventDefault();
                alert('Harap isi semua field dengan benar! Alasan minimal 50 karakter.');
                return false;
            }
            
            // Confirm submission
            if (!confirm('Anda yakin ingin mengajukan cuti?')) {
                e.preventDefault();
                return false;
            }
        });
        
        // Auto-hide alert after 5 seconds
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    </script>
</body>
</html>
<?php
mysqli_close($koneksi);
?>