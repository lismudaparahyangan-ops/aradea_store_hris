<?php
include '../config/koneksi.php';
include '../config/check_session.php';

if ($_SESSION['role'] !== 'Karyawan') {
    header('Location: ../index.php');
    exit;
}

// Inisialisasi variabel
$success = '';
$error = '';
$absensi_data = [];
$today_absensi = null;

// Ambil data karyawan berdasarkan user yang login
$user_id = $_SESSION['user_id'];
$query_karyawan = "SELECT k.id, k.nama_lengkap, k.jabatan, k.barcode_id 
                   FROM karyawan k 
                   WHERE k.user_id = $user_id";
$result_karyawan = mysqli_query($koneksi, $query_karyawan);

if (!$result_karyawan) {
    $error = "Gagal mengambil data karyawan: " . mysqli_error($koneksi);
    $karyawan = ['id' => 0, 'nama_lengkap' => '', 'jabatan' => '', 'barcode_id' => ''];
} else {
    $karyawan = mysqli_fetch_assoc($result_karyawan) ?? ['id' => 0, 'nama_lengkap' => '', 'jabatan' => '', 'barcode_id' => ''];
    $karyawan_id = $karyawan['id'];
}

// Proses check-in/check-out hanya jika data karyawan valid
if ($karyawan_id > 0) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (isset($_POST['check_in'])) {
            // Check-in
            $tanggal = date('Y-m-d');
            $jam_masuk = date('H:i:s');
            
            // Cek apakah sudah check-in hari ini
            $query_check = "SELECT id FROM absensi 
                           WHERE karyawan_id = $karyawan_id 
                           AND tanggal = '$tanggal'";
            $result_check = mysqli_query($koneksi, $query_check);
            
            if (!$result_check) {
                $error = "Error: " . mysqli_error($koneksi);
            } elseif (mysqli_num_rows($result_check) > 0) {
                $error = "Anda sudah check-in hari ini!";
            } else {
                // Tentukan status kehadiran (Hadir atau Terlambat)
                $jam_batas_terlambat = '08:30:00';
                $status_kehadiran = ($jam_masuk > $jam_batas_terlambat) ? 'Terlambat' : 'Hadir';
                
                $query_insert = "INSERT INTO absensi 
                                (karyawan_id, tanggal, jam_masuk, status_kehadiran) 
                                VALUES 
                                ($karyawan_id, '$tanggal', '$jam_masuk', '$status_kehadiran')";
                
                if (mysqli_query($koneksi, $query_insert)) {
                    $success = "Check-in berhasil! Jam: " . date('H:i', strtotime($jam_masuk));
                    if ($status_kehadiran == 'Terlambat') {
                        $success .= " (Status: Terlambat)";
                    }
                } else {
                    $error = "Gagal check-in: " . mysqli_error($koneksi);
                }
            }
        }
        
        if (isset($_POST['check_out'])) {
            // Check-out
            $tanggal = date('Y-m-d');
            $jam_keluar = date('H:i:s');
            
            // Cek apakah sudah check-in hari ini
            $query_check_in = "SELECT jam_masuk FROM absensi 
                             WHERE karyawan_id = $karyawan_id 
                             AND tanggal = '$tanggal' 
                             AND jam_masuk IS NOT NULL";
            $result_check_in = mysqli_query($koneksi, $query_check_in);
            
            if (!$result_check_in) {
                $error = "Error: " . mysqli_error($koneksi);
            } elseif (mysqli_num_rows($result_check_in) == 0) {
                $error = "Anda belum check-in hari ini!";
            } else {
                // Cek apakah sudah check-out
                $query_check_out = "SELECT id FROM absensi 
                                   WHERE karyawan_id = $karyawan_id 
                                   AND tanggal = '$tanggal' 
                                   AND jam_keluar IS NOT NULL";
                $result_check_out = mysqli_query($koneksi, $query_check_out);
                
                if (mysqli_num_rows($result_check_out) > 0) {
                    $error = "Anda sudah check-out hari ini!";
                } else {
                    // Update jam keluar
                    $query_update = "UPDATE absensi 
                                    SET jam_keluar = '$jam_keluar' 
                                    WHERE karyawan_id = $karyawan_id 
                                    AND tanggal = '$tanggal'";
                    
                    if (mysqli_query($koneksi, $query_update)) {
                        $success = "Check-out berhasil! Jam: " . date('H:i', strtotime($jam_keluar));
                    } else {
                        $error = "Gagal check-out: " . mysqli_error($koneksi);
                    }
                }
            }
        }
    }

    // Ambil data absensi karyawan
    $query_absensi = "SELECT * FROM absensi 
                      WHERE karyawan_id = $karyawan_id 
                      ORDER BY tanggal DESC 
                      LIMIT 10";
    $result_absensi = mysqli_query($koneksi, $query_absensi);
    
    if ($result_absensi) {
        while ($row = mysqli_fetch_assoc($result_absensi)) {
            $absensi_data[] = $row;
            
            // Cek absensi hari ini
            if ($row['tanggal'] == date('Y-m-d')) {
                $today_absensi = $row;
            }
        }
    }
    
    // Jika tidak ada data absensi hari ini, set null
    if (!$today_absensi) {
        $today_absensi = null;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Absensi Karyawan - HRIS Aradea Store</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3a0ca3;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: #f8fafc;
        }
        
        .main-content {
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
        }
        
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
        }
        
        .attendance-card {
            border-radius: 15px;
            border: none;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            margin-bottom: 25px;
        }
        
        .attendance-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 25px;
        }
        
        .time-display {
            font-size: 3.5rem;
            font-weight: 700;
            font-family: 'Courier New', monospace;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }
        
        .btn-attendance {
            padding: 15px 30px;
            font-size: 1.2rem;
            font-weight: 600;
            border-radius: 10px;
            border: none;
            transition: all 0.3s;
        }
        
        .btn-checkin {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
        }
        
        .btn-checkin:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(40, 167, 69, 0.3);
        }
        
        .btn-checkout {
            background: linear-gradient(135deg, #dc3545, #fd7e14);
            color: white;
        }
        
        .btn-checkout:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(220, 53, 69, 0.3);
        }
        
        .btn-disabled {
            background: linear-gradient(135deg, #6c757d, #adb5bd);
            color: white;
            cursor: not-allowed;
            opacity: 0.7;
        }
        
        .status-badge {
            padding: 8px 20px;
            border-radius: 25px;
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .status-hadir { background-color: #d1e7dd; color: #0f5132; }
        .status-terlambat { background-color: #fff3cd; color: #664d03; }
        .status-sakit { background-color: #cfe2ff; color: #084298; }
        .status-izin { background-color: #e7f1ff; color: #0d6efd; }
        .status-cuti { background-color: #f8d7da; color: #842029; }
        
        .info-box {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            margin-bottom: 20px;
            height: 100%;
        }
        
        .time-badge {
            background-color: #e9ecef;
            color: #495057;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-family: monospace;
        }
        
        .sidebar {
            width: 260px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: #1e293b;
            color: white;
            z-index: 1000;
        }
        
        .nav-link {
            color: #cbd5e1;
            padding: 12px 20px;
            transition: all 0.2s;
        }
        
        .nav-link:hover, .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            border-left: 4px solid var(--primary-color);
        }
        
        .nav-link.active {
            border-left: 4px solid var(--primary-color);
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <div class="sidebar-header p-3">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-store text-white"></i>
                </div>
                <div>
                    <h5 class="mb-0 fw-bold">Aradea Store</h5>
                    <small class="text-muted">Portal Karyawan</small>
                </div>
            </div>
        </div>
        
        <div class="user-info p-3 border-bottom border-secondary">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-user text-white"></i>
                </div>
                <div>
                    <h6 class="mb-0"><?= htmlspecialchars($karyawan['nama_lengkap']) ?></h6>
                    <small class="text-muted"><?= htmlspecialchars($karyawan['jabatan']) ?></small>
                </div>
            </div>
        </div>
        
        <ul class="nav flex-column mt-3">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-home me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="absensi_karyawan.php">
                    <i class="fas fa-clock me-2"></i> Absensi
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="ajukan_cuti.php">
                    <i class="fas fa-calendar-plus me-2"></i> Ajukan Cuti
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="ajukan_lembur.php">
                    <i class="fas fa-clock me-2"></i> Ajukan Lembur
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="status_cuti.php">
                    <i class="fas fa-history me-2"></i> Status Cuti
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profil.php">
                    <i class="fas fa-user-circle me-2"></i> Profil Saya
                </a>
            </li>
            <li class="nav-item mt-4">
                <a class="nav-link" href="../logout.php">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </li>
        </ul>
    </nav>
    
    <div class="main-content">
        <div class="mb-4">
            <a href="dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Kembali ke Dashboard
            </a>
        </div>
        
        <?php if (!empty($success)): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <?= htmlspecialchars($success) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-1"><i class="fas fa-clock me-2"></i> Absensi Online</h1>
                <p class="text-muted mb-0">Check-in dan check-out harian Anda</p>
            </div>
            <div class="text-end">
                <div class="d-flex align-items-center">
                    <div class="me-3">
                        <small class="text-muted">ID Karyawan</small>
                        <div class="fw-bold"><?= htmlspecialchars($karyawan['barcode_id']) ?></div>
                    </div>
                    <div class="rounded-circle bg-primary bg-opacity-10 p-2">
                        <i class="fas fa-id-card text-primary"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Card Absensi -->
        <div class="attendance-card">
            <div class="attendance-header text-center">
                <h2 class="mb-3"><?= date('l, d F Y') ?></h2>
                <div class="time-display" id="liveClock">00:00:00</div>
                <small class="opacity-75">Waktu Server</small>
            </div>
            
            <div class="card-body p-4">
                <div class="row">
                    <div class="col-md-6">
                        <!-- Check-in Section -->
                        <div class="text-center mb-4">
                            <h4 class="mb-3">Check-in</h4>
                            <?php if ($today_absensi && $today_absensi['jam_masuk']): ?>
                            <div class="mb-3">
                                <div class="time-badge d-inline-block mb-2">
                                    <i class="fas fa-sign-in-alt me-2"></i>
                                    <?= date('H:i', strtotime($today_absensi['jam_masuk'])) ?>
                                </div>
                                <p class="text-success mb-0">
                                    <i class="fas fa-check-circle me-1"></i> Sudah check-in
                                </p>
                            </div>
                            <button class="btn btn-attendance btn-disabled w-100" disabled>
                                <i class="fas fa-check-circle me-2"></i> Sudah Check-in
                            </button>
                            <?php else: ?>
                            <form method="POST">
                                <button type="submit" name="check_in" class="btn btn-attendance btn-checkin w-100">
                                    <i class="fas fa-sign-in-alt me-2"></i> CHECK-IN SEKARANG
                                </button>
                                <p class="text-muted mt-2 small">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Check-in maksimal jam 08:30 WIB
                                </p>
                            </form>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <!-- Check-out Section -->
                        <div class="text-center mb-4">
                            <h4 class="mb-3">Check-out</h4>
                            <?php if ($today_absensi && $today_absensi['jam_keluar']): ?>
                            <div class="mb-3">
                                <div class="time-badge d-inline-block mb-2">
                                    <i class="fas fa-sign-out-alt me-2"></i>
                                    <?= date('H:i', strtotime($today_absensi['jam_keluar'])) ?>
                                </div>
                                <p class="text-success mb-0">
                                    <i class="fas fa-check-circle me-1"></i> Sudah check-out
                                </p>
                            </div>
                            <button class="btn btn-attendance btn-disabled w-100" disabled>
                                <i class="fas fa-check-circle me-2"></i> Sudah Check-out
                            </button>
                            <?php elseif ($today_absensi && $today_absensi['jam_masuk']): ?>
                            <form method="POST">
                                <button type="submit" name="check_out" class="btn btn-attendance btn-checkout w-100">
                                    <i class="fas fa-sign-out-alt me-2"></i> CHECK-OUT SEKARANG
                                </button>
                                <p class="text-muted mt-2 small">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Pastikan menyelesaikan pekerjaan
                                </p>
                            </form>
                            <?php else: ?>
                            <div class="mb-3">
                                <p class="text-warning mb-0">
                                    <i class="fas fa-exclamation-triangle me-1"></i> Silakan check-in terlebih dahulu
                                </p>
                            </div>
                            <button class="btn btn-attendance btn-disabled w-100" disabled>
                                <i class="fas fa-sign-out-alt me-2"></i> CHECK-OUT
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Info Box -->
        <div class="row">
            <div class="col-md-4">
                <div class="info-box">
                    <div class="d-flex align-items-center mb-3">
                        <div class="rounded-circle bg-primary bg-opacity-10 p-2 me-3">
                            <i class="fas fa-user-clock text-primary"></i>
                        </div>
                        <div>
                            <h6 class="mb-0">Status Hari Ini</h6>
                            <small class="text-muted">Kehadiran</small>
                        </div>
                    </div>
                    <?php if ($today_absensi): ?>
                    <div class="text-center">
                        <?php
                        $status_class = 'status-hadir';
                        if ($today_absensi['status_kehadiran'] == 'Terlambat') $status_class = 'status-terlambat';
                        if ($today_absensi['status_kehadiran'] == 'Sakit') $status_class = 'status-sakit';
                        if ($today_absensi['status_kehadiran'] == 'Izin') $status_class = 'status-izin';
                        if ($today_absensi['status_kehadiran'] == 'Cuti') $status_class = 'status-cuti';
                        ?>
                        <span class="status-badge <?= $status_class ?>">
                            <?= htmlspecialchars($today_absensi['status_kehadiran']) ?>
                        </span>
                        <?php if ($today_absensi['jam_keluar']): ?>
                        <div class="mt-3">
                            <small class="text-muted">Durasi Kerja</small>
                            <div class="fw-bold">
                                <?php
                                $start = new DateTime($today_absensi['jam_masuk']);
                                $end = new DateTime($today_absensi['jam_keluar']);
                                $diff = $start->diff($end);
                                echo $diff->format('%H jam %I menit');
                                ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php else: ?>
                    <div class="text-center">
                        <span class="status-badge" style="background-color: #f8f9fa; color: #6c757d;">
                            Belum Check-in
                        </span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="info-box">
                    <div class="d-flex align-items-center mb-3">
                        <div class="rounded-circle bg-success bg-opacity-10 p-2 me-3">
                            <i class="fas fa-calendar-check text-success"></i>
                        </div>
                        <div>
                            <h6 class="mb-0">Kehadiran Bulan Ini</h6>
                            <small class="text-muted"><?= date('F Y') ?></small>
                        </div>
                    </div>
                    <?php
                    $bulan_ini = date('Y-m');
                    $total_hadir = 0;
                    if ($karyawan_id > 0) {
                        $query_bulan = "SELECT COUNT(*) as total_hadir 
                                       FROM absensi 
                                       WHERE karyawan_id = $karyawan_id 
                                       AND DATE_FORMAT(tanggal, '%Y-%m') = '$bulan_ini' 
                                       AND status_kehadiran IN ('Hadir', 'Terlambat')";
                        $result_bulan = mysqli_query($koneksi, $query_bulan);
                        if ($result_bulan) {
                            $bulan_data = mysqli_fetch_assoc($result_bulan);
                            $total_hadir = $bulan_data['total_hadir'] ?? 0;
                        }
                    }
                    ?>
                    <div class="text-center">
                        <h1 class="display-6 text-success"><?= $total_hadir ?></h1>
                        <small class="text-muted">Hari Hadir</small>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="info-box">
                    <div class="d-flex align-items-center mb-3">
                        <div class="rounded-circle bg-info bg-opacity-10 p-2 me-3">
                            <i class="fas fa-chart-line text-info"></i>
                        </div>
                        <div>
                            <h6 class="mb-0">Rata-rata Check-in</h6>
                            <small class="text-muted">30 hari terakhir</small>
                        </div>
                    </div>
                    <?php
                    $avg_time = '08:00';
                    if ($karyawan_id > 0) {
                        $query_avg = "SELECT AVG(TIME_TO_SEC(jam_masuk)) as avg_seconds 
                                     FROM absensi 
                                     WHERE karyawan_id = $karyawan_id 
                                     AND tanggal >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                                     AND jam_masuk IS NOT NULL";
                        $result_avg = mysqli_query($koneksi, $query_avg);
                        if ($result_avg) {
                            $avg_data = mysqli_fetch_assoc($result_avg);
                            if ($avg_data['avg_seconds']) {
                                $avg_time = gmdate('H:i', $avg_data['avg_seconds']);
                            }
                        }
                    }
                    ?>
                    <div class="text-center">
                        <h1 class="display-6 text-info"><?= $avg_time ?></h1>
                        <small class="text-muted">Rata-rata Jam</small>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Riwayat Absensi -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-0">
                <h5 class="mb-0"><i class="fas fa-history me-2"></i> Riwayat Absensi Terbaru</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Hari</th>
                                <th>Check-in</th>
                                <th>Check-out</th>
                                <th>Status</th>
                                <th>Durasi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($absensi_data)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-4">
                                    <i class="fas fa-clock fa-2x text-muted mb-2 d-block"></i>
                                    <p class="text-muted mb-0">Belum ada riwayat absensi</p>
                                </td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($absensi_data as $absensi): ?>
                            <tr>
                                <td><?= date('d M Y', strtotime($absensi['tanggal'])) ?></td>
                                <td><?= date('l', strtotime($absensi['tanggal'])) ?></td>
                                <td>
                                    <?php if ($absensi['jam_masuk']): ?>
                                    <span class="time-badge">
                                        <i class="fas fa-sign-in-alt me-1"></i>
                                        <?= date('H:i', strtotime($absensi['jam_masuk'])) ?>
                                    </span>
                                    <?php else: ?>
                                    <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($absensi['jam_keluar']): ?>
                                    <span class="time-badge">
                                        <i class="fas fa-sign-out-alt me-1"></i>
                                        <?= date('H:i', strtotime($absensi['jam_keluar'])) ?>
                                    </span>
                                    <?php else: ?>
                                    <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                    $status_class = 'status-hadir';
                                    if ($absensi['status_kehadiran'] == 'Terlambat') $status_class = 'status-terlambat';
                                    if ($absensi['status_kehadiran'] == 'Sakit') $status_class = 'status-sakit';
                                    if ($absensi['status_kehadiran'] == 'Izin') $status_class = 'status-izin';
                                    if ($absensi['status_kehadiran'] == 'Cuti') $status_class = 'status-cuti';
                                    ?>
                                    <span class="status-badge <?= $status_class ?>">
                                        <?= htmlspecialchars($absensi['status_kehadiran']) ?>
                                    </span>
                                </td>
                                <td>
                                    <?php
                                    if ($absensi['jam_masuk'] && $absensi['jam_keluar']) {
                                        $start = new DateTime($absensi['jam_masuk']);
                                        $end = new DateTime($absensi['jam_keluar']);
                                        $diff = $start->diff($end);
                                        echo $diff->format('%H:%I');
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="text-center mt-3">
                    <a href="riwayat_absensi.php" class="btn btn-outline-primary">
                        <i class="fas fa-list me-2"></i> Lihat Semua Riwayat
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Informasi Penting -->
        <div class="alert alert-info mt-4">
            <h6><i class="fas fa-info-circle me-2"></i> Informasi Absensi</h6>
            <ul class="mb-0">
                <li>Jam kerja standar: 08:00 - 17:00 WIB</li>
                <li>Check-in maksimal pukul 08:30 (terlambat jika di atas jam tersebut)</li>
                <li>Jika tidak bisa check-in karena sakit/izin, harap hubungi admin</li>
                <li>Pastikan check-out sebelum meninggalkan kantor</li>
                <li>Data absensi digunakan untuk perhitungan gaji dan bonus</li>
            </ul>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Live Clock
        function updateClock() {
            const now = new Date();
            const hours = String(now.getHours()).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            const seconds = String(now.getSeconds()).padStart(2, '0');
            document.getElementById('liveClock').textContent = `${hours}:${minutes}:${seconds}`;
        }
        
        setInterval(updateClock, 1000);
        updateClock();
        
        // Auto-hide alert after 5 seconds
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
        
        // Confirm before check-in/check-out
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                const isCheckIn = this.querySelector('[name="check_in"]');
                const isCheckOut = this.querySelector('[name="check_out"]');
                
                let message = '';
                if (isCheckIn) {
                    message = 'Apakah Anda yakin ingin check-in sekarang?';
                } else if (isCheckOut) {
                    message = 'Apakah Anda yakin ingin check-out sekarang?';
                }
                
                if (message && !confirm(message)) {
                    e.preventDefault();
                }
            });
        });
        
        // Prevent double submission
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                const submitButton = this.querySelector('button[type="submit"]');
                if (submitButton) {
                    submitButton.disabled = true;
                    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Processing...';
                }
            });
        });
        
        // Update time every minute
        function updateTimeDisplay() {
            const now = new Date();
            const dateOptions = { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            };
            const dateStr = now.toLocaleDateString('id-ID', dateOptions);
            
            // Update header date if needed
            const dateHeader = document.querySelector('.attendance-header h2');
            if (dateHeader) {
                dateHeader.textContent = dateStr;
            }
        }
        
        updateTimeDisplay();
        setInterval(updateTimeDisplay, 60000); // Update every minute
    </script>
</body>
</html>
<?php
if (isset($koneksi)) {
    mysqli_close($koneksi);
}
?>