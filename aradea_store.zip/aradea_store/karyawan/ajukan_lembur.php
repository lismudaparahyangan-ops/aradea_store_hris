<?php
include '../config/koneksi.php';
include '../config/check_session.php';

if ($_SESSION['role'] !== 'Karyawan') {
    header('Location: ../index.php');
    exit;
}

// Ambil data karyawan
$user_id = $_SESSION['user_id'];
$query_karyawan = "
    SELECT k.* FROM karyawan k 
    JOIN users u ON k.user_id = u.id 
    WHERE u.id = $user_id
";
$result_karyawan = mysqli_query($koneksi, $query_karyawan);
$karyawan = mysqli_fetch_assoc($result_karyawan);

$success = $error = '';

// Proses pengajuan lembur
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tanggal = $_POST['tanggal'];
    $jam_mulai = $_POST['jam_mulai'];
    $jam_akhir = $_POST['jam_akhir'];
    $alasan = mysqli_real_escape_string($koneksi, $_POST['alasan']);
    
    // Validasi tanggal (max H-1)
    $today = date('Y-m-d');
    $max_date = date('Y-m-d', strtotime('+1 day'));
    
    if ($tanggal < $today || $tanggal > $max_date) {
        $error = "Pengajuan lembur hanya untuk hari ini atau besok!";
    } elseif ($jam_mulai >= $jam_akhir) {
        $error = "Jam mulai harus lebih awal dari jam selesai!";
    } else {
        // Hitung durasi lembur
        $start = new DateTime($jam_mulai);
        $end = new DateTime($jam_akhir);
        $duration = $start->diff($end);
        $jam_lembur = $duration->h + ($duration->i / 60);
        
        // Max 4 jam per hari
        if ($jam_lembur > 4) {
            $error = "Durasi lembur maksimal 4 jam per hari!";
        } else {
            $query = "INSERT INTO lembur (karyawan_id, tanggal, jam_mulai, jam_akhir, alasan, status_approv) 
                      VALUES ({$karyawan['id']}, '$tanggal', '$jam_mulai', '$jam_akhir', '$alasan', 'Pending')";
            
            if (mysqli_query($koneksi, $query)) {
                $success = "Pengajuan lembur berhasil dikirim! Durasi: <strong>" . number_format($jam_lembur, 1) . " jam</strong>";
            } else {
                $error = "Gagal mengajukan lembur: " . mysqli_error($koneksi);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajukan Lembur - HRIS Aradea Store</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3a0ca3;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        
        .form-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .form-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 25px;
        }
        
        .time-input-group {
            position: relative;
        }
        
        .time-input-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #666;
            z-index: 10;
        }
        
        .time-input-group input {
            padding-left: 45px;
        }
        
        .duration-box {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }
        
        .duration-value {
            font-size: 3rem;
            font-weight: bold;
            line-height: 1;
        }
    </style>
</head>
<body>
    <!-- Sidebar (sama seperti di ajukan_cuti.php) -->
    <?php 
    $sidebar = '
    <nav class="sidebar" style="width: 260px; height: 100vh; position: fixed; left: 0; top: 0; background: #1e293b; color: white;">
        <div class="sidebar-header p-3">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-store text-white"></i>
                </div>
                <div>
                    <h5 class="mb-0 fw-bold">Aradea Store</h5>
                    <small class="text-muted">Portal Karyawan</small>
                </div>
            </div>
        </div>
        
        <div class="user-info p-3 border-bottom border-secondary">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-user text-white"></i>
                </div>
                <div>
                    <h6 class="mb-0">' . htmlspecialchars($karyawan['nama_lengkap']) . '</h6>
                    <small class="text-muted">' . $karyawan['jabatan'] . '</small>
                </div>
            </div>
        </div>
        
        <ul class="nav flex-column mt-3">
            <li class="nav-item">
                <a class="nav-link text-white" href="dashboard.php">
                    <i class="fas fa-home me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="ajukan_cuti.php">
                    <i class="fas fa-calendar-plus me-2"></i> Ajukan Cuti
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white active" href="ajukan_lembur.php">
                    <i class="fas fa-clock me-2"></i> Ajukan Lembur
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="status_cuti.php">
                    <i class="fas fa-history me-2"></i> Status Cuti
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="status_lembur.php">
                    <i class="fas fa-tasks me-2"></i> Status Lembur
                </a>
            </li>
            <li class="nav-item mt-4">
                <a class="nav-link text-white" href="../logout.php">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </li>
        </ul>
    </nav>';
    
    echo $sidebar;
    ?>
    
    <div class="main-content" style="margin-left: 260px; padding: 30px;">
        <div class="form-container">
            <div class="form-header">
                <div class="d-flex align-items-center">
                    <div class="bg-white rounded-circle p-2 me-3">
                        <i class="fas fa-clock text-warning fa-lg"></i>
                    </div>
                    <div>
                        <h2 class="mb-1">Pengajuan Lembur</h2>
                        <p class="mb-0 opacity-75">HRIS Aradea Store</p>
                    </div>
                </div>
            </div>
            
            <div class="p-4">
                <div class="mb-4">
                    <a href="dashboard.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-2"></i> Kembali ke Dashboard
                    </a>
                </div>
                
                <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    <?= $success ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <?= $error ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php endif; ?>
                
                <div class="alert alert-info mb-4">
                    <i class="fas fa-info-circle me-2"></i>
                    <strong>Informasi:</strong> 
                    Pengajuan lembur hanya untuk hari ini atau besok. Durasi maksimal 4 jam per hari.
                    Lembur di luar jam kerja normal (18:00 - 22:00).
                </div>
                
                <div class="row mb-4">
                    <div class="col-md-8">
                        <form method="POST" id="lemburForm">
                            <div class="mb-3">
                                <label class="form-label">Tanggal Lembur <span class="text-danger">*</span></label>
                                <input type="date" 
                                       class="form-control" 
                                       name="tanggal" 
                                       id="tanggal"
                                       min="<?= date('Y-m-d') ?>"
                                       max="<?= date('Y-m-d', strtotime('+1 day')) ?>"
                                       required>
                                <small class="text-muted">Hari ini atau besok</small>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Jam Mulai <span class="text-danger">*</span></label>
                                    <div class="time-input-group">
                                        <i class="fas fa-play-circle"></i>
                                        <input type="time" 
                                               class="form-control" 
                                               name="jam_mulai" 
                                               id="jam_mulai"
                                               min="18:00"
                                               max="21:00"
                                               value="18:00"
                                               required>
                                    </div>
                                    <small class="text-muted">Minimal 18:00</small>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Jam Selesai <span class="text-danger">*</span></label>
                                    <div class="time-input-group">
                                        <i class="fas fa-stop-circle"></i>
                                        <input type="time" 
                                               class="form-control" 
                                               name="jam_akhir" 
                                               id="jam_akhir"
                                               min="19:00"
                                               max="22:00"
                                               value="20:00"
                                               required>
                                    </div>
                                    <small class="text-muted">Maksimal 22:00</small>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <label class="form-label">Alasan Lembur <span class="text-danger">*</span></label>
                                <textarea class="form-control" 
                                          name="alasan" 
                                          rows="4" 
                                          placeholder="Jelaskan alasan dan pekerjaan yang akan dilakukan selama lembur..."
                                          required></textarea>
                                <small class="text-muted">Jelaskan detail pekerjaan yang akan dilakukan</small>
                            </div>
                            
                            <div class="d-flex justify-content-between">
                                <button type="reset" class="btn btn-outline-secondary">
                                    <i class="fas fa-redo me-2"></i> Reset Form
                                </button>
                                <button type="submit" class="btn btn-warning text-white">
                                    <i class="fas fa-paper-plane me-2"></i> Ajukan Lembur
                                </button>
                            </div>
                        </form>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="duration-box">
                            <h5 class="mb-3"><i class="fas fa-hourglass-half"></i> Durasi Lembur</h5>
                            <div class="duration-value" id="durasiText">0 jam</div>
                            <p class="mb-0 mt-2">Total jam lembur</p>
                        </div>
                        
                        <div class="card mt-3">
                            <div class="card-body">
                                <h6><i class="fas fa-rules me-2"></i> Aturan Lembur</h6>
                                <ul class="list-unstyled mb-0 small">
                                    <li class="mb-1"><i class="fas fa-check-circle text-success me-2"></i> Max 4 jam/hari</li>
                                    <li class="mb-1"><i class="fas fa-check-circle text-success me-2"></i> Diluar jam 18:00-22:00</li>
                                    <li class="mb-1"><i class="fas fa-check-circle text-success me-2"></i> Diajukan H-1 maksimal</li>
                                    <li><i class="fas fa-check-circle text-success me-2"></i> Harus ada alasan jelas</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Calculate duration
        function calculateDuration() {
            const jamMulai = document.getElementById('jam_mulai').value;
            const jamAkhir = document.getElementById('jam_akhir').value;
            
            if (jamMulai && jamAkhir) {
                const start = new Date(`2000-01-01T${jamMulai}`);
                const end = new Date(`2000-01-01T${jamAkhir}`);
                const diffMs = end - start;
                const diffHours = diffMs / (1000 * 60 * 60);
                
                document.getElementById('durasiText').textContent = diffHours.toFixed(1) + ' jam';
                
                // Warning if > 4 hours
                if (diffHours > 4) {
                    document.getElementById('durasiText').className = 'duration-value text-danger';
                } else if (diffHours < 1) {
                    document.getElementById('durasiText').className = 'duration-value text-warning';
                } else {
                    document.getElementById('durasiText').className = 'duration-value';
                }
            }
        }
        
        // Set max end time based on start time
        document.getElementById('jam_mulai').addEventListener('change', function() {
            const startTime = this.value;
            const endTimeInput = document.getElementById('jam_akhir');
            
            if (startTime) {
                // Add 1 hour minimum, 4 hours maximum
                const start = new Date(`2000-01-01T${startTime}`);
                const minEnd = new Date(start.getTime() + (60 * 60 * 1000)); // +1 hour
                const maxEnd = new Date(start.getTime() + (4 * 60 * 60 * 1000)); // +4 hours
                
                endTimeInput.min = minEnd.toTimeString().substring(0, 5);
                endTimeInput.max = maxEnd.toTimeString().substring(0, 5);
                
                calculateDuration();
            }
        });
        
        document.getElementById('jam_akhir').addEventListener('change', calculateDuration);
        
        // Initial calculation
        calculateDuration();
        
        // Form validation
        document.getElementById('lemburForm').addEventListener('submit', function(e) {
            const tanggal = document.getElementById('tanggal').value;
            const jamMulai = document.getElementById('jam_mulai').value;
            const jamAkhir = document.getElementById('jam_akhir').value;
            const alasan = document.querySelector('[name="alasan"]').value;
            
            // Check if end time > start time
            if (jamMulai >= jamAkhir) {
                e.preventDefault();
                alert('Jam selesai harus lebih besar dari jam mulai!');
                return false;
            }
            
            // Check if duration > 4 hours
            const start = new Date(`2000-01-01T${jamMulai}`);
            const end = new Date(`2000-01-01T${jamAkhir}`);
            const diffHours = (end - start) / (1000 * 60 * 60);
            
            if (diffHours > 4) {
                e.preventDefault();
                alert('Durasi lembur maksimal 4 jam!');
                return false;
            }
            
            if (!tanggal || !jamMulai || !jamAkhir || alasan.length < 20) {
                e.preventDefault();
                alert('Harap isi semua field dengan benar! Alasan minimal 20 karakter.');
                return false;
            }
            
            // Confirm submission
            if (!confirm('Anda yakin ingin mengajukan lembur?')) {
                e.preventDefault();
                return false;
            }
        });
        
        // Auto-hide alert after 5 seconds
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    </script>
</body>
</html>
<?php
mysqli_close($koneksi);
?>