<?php
// Konfigurasi Database
$server = "localhost"; // Nama server biasanya localhost untuk XAMPP
$user = "root";        // Username default XAMPP
$pass = "";            // Password default XAMPP (biasanya kosong)
$database = "hris_aradea_store"; // Nama database yang sudah kita buat

// Membuat koneksi ke database menggunakan MySQLi
$koneksi = mysqli_connect($server, $user, $pass, $database);

// Cek koneksi
if (!$koneksi) {
    // Jika koneksi gagal, tampilkan pesan error dan hentikan script
    die("Koneksi gagal: " . mysqli_connect_error());
} 

// Jika koneksi berhasil, tidak perlu menampilkan apa-apa (hanya siap digunakan)
?>