<?php
include '../config/koneksi.php';
include '../config/check_session.php';

// Cek role admin
if ($_SESSION['role'] !== 'Admin') {
    header('Location: ../index.php');
    exit;
}

// Set default periode (bulan ini)
$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('Y-m');
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

// Parse bulan dan tahun
$bulan_num = date('m', strtotime($bulan));
$bulan_text = date('F Y', strtotime($bulan));

// Data untuk filter
$bulan_options = [];
for ($i = 1; $i <= 12; $i++) {
    $bulan_options[$i] = date('F', mktime(0, 0, 0, $i, 1));
}

$tahun_options = [];
$current_year = date('Y');
for ($i = $current_year; $i >= $current_year - 5; $i--) {
    $tahun_options[$i] = $i;
}

// ==============================================
// QUERY DATA STATISTIK
// ==============================================

// Total Karyawan
$query_total_karyawan = "SELECT COUNT(*) as total FROM karyawan";
$result_total = mysqli_query($koneksi, $query_total_karyawan);
$total_karyawan = $result_total ? mysqli_fetch_assoc($result_total)['total'] : 0;

// Karyawan per Jabatan
$query_jabatan = "
    SELECT jabatan, COUNT(*) as jumlah 
    FROM karyawan 
    GROUP BY jabatan 
    ORDER BY jumlah DESC
";
$result_jabatan = mysqli_query($koneksi, $query_jabatan);
$data_jabatan = [];
$labels_jabatan = [];
$values_jabatan = [];
if ($result_jabatan) {
    while ($row = mysqli_fetch_assoc($result_jabatan)) {
        $data_jabatan[] = $row;
        $labels_jabatan[] = $row['jabatan'];
        $values_jabatan[] = $row['jumlah'];
    }
}

// Absensi Bulan Ini
$query_absensi = "
    SELECT 
        COUNT(DISTINCT karyawan_id) as total_hadir,
        COUNT(*) as total_absensi,
        ROUND(AVG(TIME_TO_SEC(TIMEDIFF(jam_keluar, jam_masuk)) / 3600), 2) as rata_rata_jam_kerja
    FROM absensi 
    WHERE MONTH(tanggal) = '$bulan_num' AND YEAR(tanggal) = '$tahun'
    AND status_kehadiran = 'Hadir'
";
$result_absensi = mysqli_query($koneksi, $query_absensi);
$data_absensi = $result_absensi ? mysqli_fetch_assoc($result_absensi) : [
    'total_hadir' => 0,
    'total_absensi' => 0,
    'rata_rata_jam_kerja' => 0
];

// Cuti Bulan Ini
$query_cuti = "
    SELECT 
        COUNT(*) as total_cuti,
        SUM(CASE WHEN status_approv = 'Approved' THEN 1 ELSE 0 END) as cuti_disetujui,
        SUM(CASE WHEN status_approv = 'Pending' THEN 1 ELSE 0 END) as cuti_pending,
        SUM(CASE WHEN status_approv = 'Rejected' THEN 1 ELSE 0 END) as cuti_ditolak
    FROM cuti 
    WHERE MONTH(tanggal_mulai) = '$bulan_num' AND YEAR(tanggal_mulai) = '$tahun'
";
$result_cuti = mysqli_query($koneksi, $query_cuti);
$data_cuti = $result_cuti ? mysqli_fetch_assoc($result_cuti) : [
    'total_cuti' => 0,
    'cuti_disetujui' => 0,
    'cuti_pending' => 0,
    'cuti_ditolak' => 0
];

// Lembur Bulan Ini
$query_lembur = "
    SELECT 
        COUNT(*) as total_lembur,
        SUM(CASE WHEN status_approv = 'Approved' THEN 1 ELSE 0 END) as lembur_disetujui,
        SUM(CASE WHEN status_approv = 'Pending' THEN 1 ELSE 0 END) as lembur_pending,
        SUM(CASE WHEN status_approv = 'Rejected' THEN 1 ELSE 0 END) as lembur_ditolak,
        SUM(TIME_TO_SEC(TIMEDIFF(jam_akhir, jam_mulai)) / 3600) as total_jam_lembur
    FROM lembur 
    WHERE MONTH(tanggal) = '$bulan_num' AND YEAR(tanggal) = '$tahun'
";
$result_lembur = mysqli_query($koneksi, $query_lembur);
$data_lembur = $result_lembur ? mysqli_fetch_assoc($result_lembur) : [
    'total_lembur' => 0,
    'lembur_disetujui' => 0,
    'lembur_pending' => 0,
    'lembur_ditolak' => 0,
    'total_jam_lembur' => 0
];

// Top 5 Karyawan dengan Lembur Terbanyak
$query_top_lembur = "
    SELECT 
        k.nama_lengkap,
        k.jabatan,
        COUNT(l.id) as jumlah_lembur,
        SUM(TIME_TO_SEC(TIMEDIFF(l.jam_akhir, l.jam_mulai)) / 3600) as total_jam
    FROM karyawan k
    LEFT JOIN lembur l ON k.id = l.karyawan_id 
        AND l.status_approv = 'Approved'
        AND MONTH(l.tanggal) = '$bulan_num' 
        AND YEAR(l.tanggal) = '$tahun'
    GROUP BY k.id
    ORDER BY total_jam DESC
    LIMIT 5
";
$result_top_lembur = mysqli_query($koneksi, $query_top_lembur);
$top_lembur = [];
if ($result_top_lembur) {
    while ($row = mysqli_fetch_assoc($result_top_lembur)) {
        $top_lembur[] = $row;
    }
}

// Data untuk chart absensi 6 bulan terakhir
$query_absensi_chart = "
    SELECT 
        DATE_FORMAT(tanggal, '%Y-%m') as bulan,
        COUNT(*) as total_hadir,
        COUNT(DISTINCT karyawan_id) as karyawan_hadir
    FROM absensi 
    WHERE tanggal >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
    AND status_kehadiran = 'Hadir'
    GROUP BY DATE_FORMAT(tanggal, '%Y-%m')
    ORDER BY bulan
";
$result_absensi_chart = mysqli_query($koneksi, $query_absensi_chart);
$absensi_chart_data = [];
$absensi_chart_labels = [];
$absensi_chart_values = [];
if ($result_absensi_chart) {
    while ($row = mysqli_fetch_assoc($result_absensi_chart)) {
        $absensi_chart_data[] = $row;
        $absensi_chart_labels[] = date('M Y', strtotime($row['bulan'] . '-01'));
        $absensi_chart_values[] = $row['total_hadir'];
    }
}

// Karyawan dengan sisa cuti terendah
$query_sisa_cuti = "
    SELECT nama_lengkap, jabatan, sisa_cuti
    FROM karyawan
    WHERE sisa_cuti <= 5
    ORDER BY sisa_cuti ASC
    LIMIT 5
";
$result_sisa_cuti = mysqli_query($koneksi, $query_sisa_cuti);
$sisa_cuti_low = [];
if ($result_sisa_cuti) {
    while ($row = mysqli_fetch_assoc($result_sisa_cuti)) {
        $sisa_cuti_low[] = $row;
    }
}

// ==============================================
// PERHITUNGAN PERSENTASE
// ==============================================

$persentase_kehadiran = $total_karyawan > 0 ? 
    round(($data_absensi['total_hadir'] / $total_karyawan) * 100, 1) : 0;

$persentase_cuti_disetujui = $data_cuti['total_cuti'] > 0 ? 
    round(($data_cuti['cuti_disetujui'] / $data_cuti['total_cuti']) * 100, 1) : 0;

$persentase_lembur_disetujui = $data_lembur['total_lembur'] > 0 ? 
    round(($data_lembur['lembur_disetujui'] / $data_lembur['total_lembur']) * 100, 1) : 0;

?>
<!DOCTYPE html>
<html lang="id" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan SDM - HRIS Aradea Store</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3a0ca3;
            --sidebar-width: 260px;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: #f8fafc;
        }
        
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            min-height: 100vh;
        }
        
        .card-header-custom {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
        }
        
        .stats-card {
            border-radius: 10px;
            transition: all 0.3s;
            border: none;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        }
        
        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
        }
        
        .progress-thin {
            height: 6px;
        }
        
        .table-hover tbody tr:hover {
            background-color: rgba(67, 97, 238, 0.05);
        }
        
        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }
        
        .badge-indicator {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .filter-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            
            .chart-container {
                height: 250px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar" style="width: 260px; height: 100vh; position: fixed; left: 0; top: 0; background: #1e293b; color: white;">
        <div class="sidebar-header p-3">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-store text-white"></i>
                </div>
                <div>
                    <h5 class="mb-0 fw-bold">Aradea Store</h5>
                    <small class="text-muted">HRIS System</small>
                </div>
            </div>
        </div>
        
        <div class="user-info p-3 border-bottom border-secondary">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-user text-white"></i>
                </div>
                <div>
                    <h6 class="mb-0"><?= htmlspecialchars($_SESSION['nama_lengkap'] ?? $_SESSION['username']) ?></h6>
                    <small class="text-muted"><?= $_SESSION['role'] ?></small>
                </div>
            </div>
        </div>
        
        <ul class="nav flex-column mt-3">
            <li class="nav-item">
                <a class="nav-link text-white" href="dashboard.php">
                    <i class="fas fa-home me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="manajemen_karyawan.php">
                    <i class="fas fa-users me-2"></i> Data Karyawan
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="persetujuan_cuti.php">
                    <i class="fas fa-calendar-check me-2"></i> Persetujuan Cuti
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="persetujuan_lembur.php">
                    <i class="fas fa-clock me-2"></i> Persetujuan Lembur
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white active" href="laporan_sdm.php">
                    <i class="fas fa-chart-bar me-2"></i> Laporan SDM
                </a>
            </li>
            <li class="nav-item mt-4">
                <a class="nav-link text-white" href="../logout.php">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </li>
        </ul>
    </nav>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-2 fw-bold"><i class="fas fa-chart-bar me-2"></i> Laporan SDM</h1>
                <p class="text-muted mb-0">Analisis dan statistik sumber daya manusia Aradea Store</p>
            </div>
            <div>
                <a href="dashboard.php" class="btn btn-outline-secondary me-2">
                    <i class="fas fa-arrow-left me-2"></i> Dashboard
                </a>
                <button class="btn btn-primary" onclick="printReport()">
                    <i class="fas fa-print me-2"></i> Cetak Laporan
                </button>
            </div>
        </div>
        
        <!-- Filter Section -->
        <div class="filter-card">
            <h5 class="mb-3"><i class="fas fa-filter me-2"></i> Filter Laporan</h5>
            <form method="GET" action="" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Pilih Bulan</label>
                    <select name="bulan" class="form-select">
                        <?php foreach ($bulan_options as $num => $name): ?>
                        <option value="<?= date('Y') . '-' . str_pad($num, 2, '0', STR_PAD_LEFT) ?>" 
                                <?= $bulan_num == $num ? 'selected' : '' ?>>
                            <?= $name ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Pilih Tahun</label>
                    <select name="tahun" class="form-select">
                        <?php foreach ($tahun_options as $year): ?>
                        <option value="<?= $year ?>" <?= $tahun == $year ? 'selected' : '' ?>>
                            <?= $year ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary me-2">
                        <i class="fas fa-search me-2"></i> Tampilkan
                    </button>
                    <a href="laporan_sdm.php" class="btn btn-outline-secondary">
                        <i class="fas fa-redo me-2"></i> Reset
                    </a>
                </div>
            </form>
            <div class="mt-3">
                <span class="badge bg-primary">
                    <i class="fas fa-calendar me-1"></i>
                    Periode: <?= $bulan_text ?>
                </span>
                <span class="badge bg-secondary ms-2">
                    <i class="fas fa-users me-1"></i>
                    Total Karyawan: <?= $total_karyawan ?>
                </span>
            </div>
        </div>
        
        <!-- Stats Overview -->
        <div class="row g-4 mb-4">
            <div class="col-xl-3 col-md-6">
                <div class="card stats-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Total Karyawan</h6>
                                <h2 class="mb-0 fw-bold"><?= $total_karyawan ?></h2>
                                <small class="text-muted">Aktif</small>
                            </div>
                            <div class="stat-icon" style="background: rgba(67, 97, 238, 0.1);">
                                <i class="fas fa-users text-primary"></i>
                            </div>
                        </div>
                        <div class="mt-3">
                            <div class="d-flex justify-content-between mb-1">
                                <small>Kehadiran</small>
                                <small><?= $persentase_kehadiran ?>%</small>
                            </div>
                            <div class="progress progress-thin">
                                <div class="progress-bar bg-success" style="width: <?= $persentase_kehadiran ?>%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card stats-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Pengajuan Cuti</h6>
                                <h2 class="mb-0 fw-bold"><?= $data_cuti['total_cuti'] ?></h2>
                                <small class="text-muted">Bulan <?= $bulan_text ?></small>
                            </div>
                            <div class="stat-icon" style="background: rgba(255, 193, 7, 0.1);">
                                <i class="fas fa-calendar-times text-warning"></i>
                            </div>
                        </div>
                        <div class="mt-3">
                            <div class="d-flex justify-content-between mb-1">
                                <small>Disetujui</small>
                                <small><?= $persentase_cuti_disetujui ?>%</small>
                            </div>
                            <div class="progress progress-thin">
                                <div class="progress-bar bg-success" style="width: <?= $persentase_cuti_disetujui ?>%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card stats-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Pengajuan Lembur</h6>
                                <h2 class="mb-0 fw-bold"><?= $data_lembur['total_lembur'] ?></h2>
                                <small class="text-muted"><?= number_format($data_lembur['total_jam_lembur'], 1) ?> jam</small>
                            </div>
                            <div class="stat-icon" style="background: rgba(40, 167, 69, 0.1);">
                                <i class="fas fa-clock text-success"></i>
                            </div>
                        </div>
                        <div class="mt-3">
                            <div class="d-flex justify-content-between mb-1">
                                <small>Disetujui</small>
                                <small><?= $persentase_lembur_disetujui ?>%</small>
                            </div>
                            <div class="progress progress-thin">
                                <div class="progress-bar bg-success" style="width: <?= $persentase_lembur_disetujui ?>%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card stats-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Rata-rata Jam Kerja</h6>
                                <h2 class="mb-0 fw-bold"><?= number_format($data_absensi['rata_rata_jam_kerja'], 1) ?></h2>
                                <small class="text-muted">Jam per hari</small>
                            </div>
                            <div class="stat-icon" style="background: rgba(111, 66, 193, 0.1);">
                                <i class="fas fa-business-time text-purple"></i>
                            </div>
                        </div>
                        <div class="mt-3">
                            <div class="d-flex justify-content-between">
                                <small class="text-muted">Total Absensi</small>
                                <small class="text-muted"><?= $data_absensi['total_absensi'] ?></small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Charts Section -->
        <div class="row g-4 mb-4">
            <div class="col-xl-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-chart-pie me-2"></i> Distribusi Jabatan</h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="jabatanChart"></canvas>
                        </div>
                        <div class="mt-3">
                            <table class="table table-sm">
                                <tbody>
                                    <?php foreach ($data_jabatan as $jabatan): ?>
                                    <tr>
                                        <td><?= $jabatan['jabatan'] ?></td>
                                        <td class="text-end"><?= $jabatan['jumlah'] ?> orang</td>
                                        <td width="100">
                                            <?php 
                                            $percentage = $total_karyawan > 0 ? 
                                                round(($jabatan['jumlah'] / $total_karyawan) * 100, 1) : 0;
                                            ?>
                                            <div class="progress progress-thin">
                                                <div class="progress-bar" style="width: <?= $percentage ?>%"></div>
                                            </div>
                                        </td>
                                        <td class="text-muted text-end" width="50"><?= $percentage ?>%</td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-chart-line me-2"></i> Trend Kehadiran 6 Bulan</h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="absensiChart"></canvas>
                        </div>
                        <div class="row mt-3 text-center">
                            <div class="col-4">
                                <small class="text-muted d-block">Bulan Ini</small>
                                <strong class="text-primary"><?= $data_absensi['total_hadir'] ?></strong>
                            </div>
                            <div class="col-4">
                                <small class="text-muted d-block">Rata-rata</small>
                                <strong class="text-warning">
                                    <?= count($absensi_chart_values) > 0 ? 
                                        round(array_sum($absensi_chart_values) / count($absensi_chart_values), 0) : 0 ?>
                                </strong>
                            </div>
                            <div class="col-4">
                                <small class="text-muted d-block">Tertinggi</small>
                                <strong class="text-success">
                                    <?= count($absensi_chart_values) > 0 ? max($absensi_chart_values) : 0 ?>
                                </strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Detailed Tables -->
        <div class="row g-4">
            <!-- Top 5 Lembur -->
            <div class="col-xl-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">
                            <i class="fas fa-trophy me-2 text-warning"></i> 
                            Top 5 Karyawan Lembur Terbanyak
                            <small class="text-muted">(Bulan <?= $bulan_text ?>)</small>
                        </h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Nama Karyawan</th>
                                        <th>Jabatan</th>
                                        <th>Jumlah Lembur</th>
                                        <th>Total Jam</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($top_lembur)): ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-4">
                                            <i class="fas fa-clock fa-2x text-muted mb-2"></i>
                                            <p class="text-muted mb-0">Tidak ada data lembur</p>
                                        </td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach ($top_lembur as $index => $lembur): ?>
                                    <tr>
                                        <td>
                                            <?php if ($index == 0): ?>
                                            <span class="badge bg-warning">1</span>
                                            <?php elseif ($index == 1): ?>
                                            <span class="badge bg-secondary">2</span>
                                            <?php elseif ($index == 2): ?>
                                            <span class="badge bg-danger">3</span>
                                            <?php else: ?>
                                            <span class="badge bg-light text-dark"><?= $index + 1 ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <strong><?= htmlspecialchars($lembur['nama_lengkap']) ?></strong>
                                        </td>
                                        <td><?= $lembur['jabatan'] ?></td>
                                        <td><?= $lembur['jumlah_lembur'] ?>x</td>
                                        <td>
                                            <span class="badge bg-primary">
                                                <?= number_format($lembur['total_jam'], 1) ?> jam
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Sisa Cuti Rendah -->
            <div class="col-xl-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">
                            <i class="fas fa-exclamation-triangle me-2 text-danger"></i> 
                            Karyawan dengan Sisa Cuti Rendah
                            <small class="text-muted">(≤ 5 hari)</small>
                        </h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Nama Karyawan</th>
                                        <th>Jabatan</th>
                                        <th>Sisa Cuti</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($sisa_cuti_low)): ?>
                                    <tr>
                                        <td colspan="4" class="text-center py-4">
                                            <i class="fas fa-check-circle fa-2x text-success mb-2"></i>
                                            <p class="text-muted mb-0">Semua karyawan memiliki sisa cuti yang cukup</p>
                                        </td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach ($sisa_cuti_low as $karyawan): ?>
                                    <tr>
                                        <td>
                                            <strong><?= htmlspecialchars($karyawan['nama_lengkap']) ?></strong>
                                        </td>
                                        <td><?= $karyawan['jabatan'] ?></td>
                                        <td>
                                            <?php 
                                            $sisa = $karyawan['sisa_cuti'];
                                            $badge_class = $sisa <= 2 ? 'bg-danger' : 
                                                          ($sisa <= 5 ? 'bg-warning' : 'bg-info');
                                            ?>
                                            <span class="badge <?= $badge_class ?>">
                                                <?= $sisa ?> hari
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($sisa <= 2): ?>
                                            <span class="badge-indicator bg-danger text-white">Kritis</span>
                                            <?php elseif ($sisa <= 5): ?>
                                            <span class="badge-indicator bg-warning text-dark">Peringatan</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Summary Cards -->
        <div class="row g-4 mt-4">
            <div class="col-md-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h6 class="card-title mb-3">
                            <i class="fas fa-calendar-check me-2 text-success"></i>
                            Ringkasan Cuti
                        </h6>
                        <div class="d-flex justify-content-between mb-2">
                            <small class="text-muted">Disetujui</small>
                            <strong class="text-success"><?= $data_cuti['cuti_disetujui'] ?></strong>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <small class="text-muted">Menunggu</small>
                            <strong class="text-warning"><?= $data_cuti['cuti_pending'] ?></strong>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <small class="text-muted">Ditolak</small>
                            <strong class="text-danger"><?= $data_cuti['cuti_ditolak'] ?></strong>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between">
                            <strong>Total</strong>
                            <strong><?= $data_cuti['total_cuti'] ?></strong>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h6 class="card-title mb-3">
                            <i class="fas fa-clock me-2 text-primary"></i>
                            Ringkasan Lembur
                        </h6>
                        <div class="d-flex justify-content-between mb-2">
                            <small class="text-muted">Disetujui</small>
                            <strong class="text-success"><?= $data_lembur['lembur_disetujui'] ?></strong>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <small class="text-muted">Menunggu</small>
                            <strong class="text-warning"><?= $data_lembur['lembur_pending'] ?></strong>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <small class="text-muted">Ditolak</small>
                            <strong class="text-danger"><?= $data_lembur['lembur_ditolak'] ?></strong>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between">
                            <strong>Total Jam</strong>
                            <strong class="text-primary"><?= number_format($data_lembur['total_jam_lembur'], 1) ?> jam</strong>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h6 class="card-title mb-3">
                            <i class="fas fa-chart-bar me-2 text-info"></i>
                            Statistik Absensi
                        </h6>
                        <div class="d-flex justify-content-between mb-2">
                            <small class="text-muted">Hadir Bulan Ini</small>
                            <strong><?= $data_absensi['total_hadir'] ?></strong>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <small class="text-muted">Total Absensi</small>
                            <strong><?= $data_absensi['total_absensi'] ?></strong>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <small class="text-muted">Rata-rata Jam Kerja</small>
                            <strong><?= number_format($data_absensi['rata_rata_jam_kerja'], 1) ?> jam</strong>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between">
                            <strong>Persentase Kehadiran</strong>
                            <strong class="text-success"><?= $persentase_kehadiran ?>%</strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="mt-4 text-center">
            <small class="text-muted">
                <i class="fas fa-info-circle me-1"></i>
                Laporan SDM Aradea Store | Periode: <?= $bulan_text ?> | 
                Generated: <?= date('d M Y H:i:s') ?>
            </small>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Chart Colors
        const chartColors = {
            primary: '#4361ee',
            secondary: '#3a0ca3',
            success: '#28a745',
            warning: '#ffc107',
            danger: '#dc3545',
            info: '#17a2b8',
            purple: '#6f42c1'
        };
        
        // Jabatan Chart (Pie)
        const jabatanCtx = document.getElementById('jabatanChart').getContext('2d');
        const jabatanChart = new Chart(jabatanCtx, {
            type: 'pie',
            data: {
                labels: <?= json_encode($labels_jabatan) ?>,
                datasets: [{
                    data: <?= json_encode($values_jabatan) ?>,
                    backgroundColor: [
                        chartColors.primary,
                        chartColors.success,
                        chartColors.warning,
                        chartColors.danger,
                        chartColors.info,
                        chartColors.purple
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.raw || 0;
                                const total = <?= $total_karyawan ?>;
                                const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                                return `${label}: ${value} orang (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
        
        // Absensi Chart (Line)
        const absensiCtx = document.getElementById('absensiChart').getContext('2d');
        const absensiChart = new Chart(absensiCtx, {
            type: 'line',
            data: {
                labels: <?= json_encode($absensi_chart_labels) ?>,
                datasets: [{
                    label: 'Jumlah Kehadiran',
                    data: <?= json_encode($absensi_chart_values) ?>,
                    borderColor: chartColors.primary,
                    backgroundColor: chartColors.primary + '20',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Jumlah Kehadiran'
                        }
                    }
                }
            }
        });
        
        // Print Report Function
        function printReport() {
            const printContent = `
                <html>
                <head>
                    <title>Laporan SDM - Aradea Store</title>
                    <style>
                        body { font-family: Arial, sans-serif; margin: 20px; }
                        .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 10px; }
                        .section { margin-bottom: 20px; }
                        table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
                        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                        th { background-color: #f2f2f2; }
                        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 20px; }
                        .stat-box { border: 1px solid #ddd; padding: 15px; text-align: center; }
                        .footer { margin-top: 30px; text-align: center; font-size: 12px; color: #666; }
                        @media print {
                            .no-print { display: none; }
                            body { margin: 0; }
                        }
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>Laporan SDM Aradea Store</h1>
                        <p>Periode: <?= $bulan_text ?></p>
                        <p>Generated: <?= date('d M Y H:i:s') ?></p>
                    </div>
                    
                    <div class="stats-grid">
                        <div class="stat-box">
                            <h3><?= $total_karyawan ?></h3>
                            <p>Total Karyawan</p>
                        </div>
                        <div class="stat-box">
                            <h3><?= $data_cuti['total_cuti'] ?></h3>
                            <p>Pengajuan Cuti</p>
                        </div>
                        <div class="stat-box">
                            <h3><?= $data_lembur['total_lembur'] ?></h3>
                            <p>Pengajuan Lembur</p>
                        </div>
                        <div class="stat-box">
                            <h3><?= $persentase_kehadiran ?>%</h3>
                            <p>Kehadiran</p>
                        </div>
                    </div>
                    
                    <div class="section">
                        <h3>Distribusi Jabatan</h3>
                        <table>
                            <thead>
                                <tr>
                                    <th>Jabatan</th>
                                    <th>Jumlah</th>
                                    <th>Persentase</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($data_jabatan as $jabatan): ?>
                                <?php $percentage = $total_karyawan > 0 ? round(($jabatan['jumlah'] / $total_karyawan) * 100, 1) : 0; ?>
                                <tr>
                                    <td><?= $jabatan['jabatan'] ?></td>
                                    <td><?= $jabatan['jumlah'] ?> orang</td>
                                    <td><?= $percentage ?>%</td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="section">
                        <h3>Ringkasan Cuti</h3>
                        <table>
                            <tr>
                                <td>Disetujui</td>
                                <td><?= $data_cuti['cuti_disetujui'] ?></td>
                            </tr>
                            <tr>
                                <td>Menunggu</td>
                                <td><?= $data_cuti['cuti_pending'] ?></td>
                            </tr>
                            <tr>
                                <td>Ditolak</td>
                                <td><?= $data_cuti['cuti_ditolak'] ?></td>
                            </tr>
                            <tr>
                                <td><strong>Total</strong></td>
                                <td><strong><?= $data_cuti['total_cuti'] ?></strong></td>
                            </tr>
                        </table>
                    </div>
                    
                    <div class="footer">
                        <p>Laporan ini digenerate secara otomatis oleh Sistem HRIS Aradea Store</p>
                        <p>&copy; <?= date('Y') ?> Aradea Store. Hak Cipta Dilindungi.</p>
                    </div>
                </body>
                </html>
            `;
            
            const printWindow = window.open('', '_blank');
            printWindow.document.write(printContent);
            printWindow.document.close();
            printWindow.focus();
            setTimeout(() => {
                printWindow.print();
                printWindow.close();
            }, 500);
        }
        
        // Auto refresh data every 5 minutes (optional)
        // setTimeout(() => {
        //     window.location.reload();
        // }, 300000);
    </script>
</body>
</html>
<?php
// Clean up
if (isset($result_total)) mysqli_free_result($result_total);
if (isset($result_jabatan)) mysqli_free_result($result_jabatan);
if (isset($result_absensi)) mysqli_free_result($result_absensi);
if (isset($result_cuti)) mysqli_free_result($result_cuti);
if (isset($result_lembur)) mysqli_free_result($result_lembur);
if (isset($result_top_lembur)) mysqli_free_result($result_top_lembur);
if (isset($result_absensi_chart)) mysqli_free_result($result_absensi_chart);
if (isset($result_sisa_cuti)) mysqli_free_result($result_sisa_cuti);

mysqli_close($koneksi);
?>