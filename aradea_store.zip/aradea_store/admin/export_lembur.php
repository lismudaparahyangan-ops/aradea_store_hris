<?php
include '../config/koneksi.php';
include '../config/check_session.php';

// Cek role admin
if ($_SESSION['role'] !== 'Admin') {
    header('Location: ../index.php');
    exit;
}

// Ambil parameter
$start_date = $_POST['start_date'] ?? date('Y-m-01');
$end_date = $_POST['end_date'] ?? date('Y-m-t');
$status_filter = $_POST['status_filter'] ?? 'all';
$format = $_POST['format'] ?? 'excel';

// Build query
$status_condition = '';
if ($status_filter !== 'all') {
    $status_condition = " AND l.status_approv = '" . mysqli_real_escape_string($koneksi, ucfirst($status_filter)) . "'";
}

$query = "
    SELECT 
        l.tanggal,
        l.jam_mulai,
        l.jam_akhir,
        l.alasan,
        l.status_approv,
        k.nama_lengkap,
        k.jabatan,
        u.username,
        TIMEDIFF(l.jam_akhir, l.jam_mulai) as durasi,
        TIME_TO_SEC(TIMEDIFF(l.jam_akhir, l.jam_mulai)) / 3600 as jam_lembur
    FROM 
        lembur l
    JOIN 
        karyawan k ON l.karyawan_id = k.id
    JOIN
        users u ON k.user_id = u.id
    WHERE 
        l.tanggal BETWEEN '$start_date' AND '$end_date'
        $status_condition
    ORDER BY 
        l.tanggal DESC
";

$result = mysqli_query($koneksi, $query);

if ($format === 'csv') {
    // Export CSV
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="lembur_export_' . date('Ymd') . '.csv"');
    
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Tanggal', 'Nama Karyawan', 'Jabatan', 'Jam Mulai', 'Jam Selesai', 'Durasi', 'Jam Lembur', 'Alasan', 'Status']);
    
    while ($row = mysqli_fetch_assoc($result)) {
        fputcsv($output, [
            $row['tanggal'],
            $row['nama_lengkap'],
            $row['jabatan'],
            $row['jam_mulai'],
            $row['jam_akhir'],
            $row['durasi'],
            number_format($row['jam_lembur'], 2),
            $row['alasan'],
            $row['status_approv']
        ]);
    }
    
    fclose($output);
} else {
    // Export HTML/PDF (simplified)
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="lembur_export_' . date('Ymd') . '.xls"');
    
    echo '<table border="1">';
    echo '<tr><th>Tanggal</th><th>Nama Karyawan</th><th>Jabatan</th><th>Jam Mulai</th><th>Jam Selesai</th><th>Durasi</th><th>Jam Lembur</th><th>Alasan</th><th>Status</th></tr>';
    
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>';
        echo '<td>' . $row['tanggal'] . '</td>';
        echo '<td>' . $row['nama_lengkap'] . '</td>';
        echo '<td>' . $row['jabatan'] . '</td>';
        echo '<td>' . $row['jam_mulai'] . '</td>';
        echo '<td>' . $row['jam_akhir'] . '</td>';
        echo '<td>' . $row['durasi'] . '</td>';
        echo '<td>' . number_format($row['jam_lembur'], 2) . '</td>';
        echo '<td>' . $row['alasan'] . '</td>';
        echo '<td>' . $row['status_approv'] . '</td>';
        echo '</tr>';
    }
    
    echo '</table>';
}

mysqli_close($koneksi);
exit;
?>