<?php
// HAPUS semua session_start() dari sini
include '../config/koneksi.php';
include '../config/check_session.php'; // Session sudah dihandle disini

// Cek role
if ($_SESSION['role'] !== 'Admin') {
    header('Location: ../index.php');
    exit;
}

// Handle status messages dari URL
$status = $_GET['status'] ?? '';
$messages = [
    'sukses_tambah' => 'Data karyawan berhasil ditambahkan!',
    'sukses_edit' => 'Data karyawan berhasil diperbarui!',
    'sukses_hapus' => 'Data karyawan berhasil dihapus!',
    'error' => 'Terjadi kesalahan. Silakan coba lagi.'
];

// Query dengan error handling
$query = "
    SELECT 
        u.id as user_id,
        u.username, 
        u.role, 
        k.nama_lengkap, 
        k.jabatan,
        k.barcode_id
    FROM 
        users u
    JOIN 
        karyawan k ON u.id = k.user_id
    ORDER BY u.role DESC, k.nama_lengkap ASC
";

$result = mysqli_query($koneksi, $query);
$total_karyawan = $result ? mysqli_num_rows($result) : 0;

// Jika query gagal, set result ke false dan tampilkan error
if (!$result) {
    error_log("Query error: " . mysqli_error($koneksi));
}
?>
<!DOCTYPE html>
<html lang="id" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Karyawan - HRIS Aradea Store</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3a0ca3;
            --sidebar-width: 260px;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: #f8fafc;
        }
        
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            min-height: 100vh;
        }
        
        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        }
        
        .table th {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border: none;
            padding: 15px;
            font-weight: 600;
        }
        
        .badge-role {
            padding: 5px 12px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.85rem;
        }
        
        .badge-admin {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .badge-karyawan {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
        }
        
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <!-- Include Sidebar -->
    <nav class="sidebar" style="width: 260px; height: 100vh; position: fixed; left: 0; top: 0; background: #1e293b; color: white;">
        <div class="sidebar-header p-3">
            <h5><i class="fas fa-store"></i> Aradea Store</h5>
            <small>HRIS System</small>
        </div>
        <ul class="nav flex-column mt-3">
            <li class="nav-item">
                <a class="nav-link text-white" href="dashboard.php">
                    <i class="fas fa-home"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white active" href="manajemen_karyawan.php">
                    <i class="fas fa-users"></i> Data Karyawan
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="persetujuan_cuti.php">
                    <i class="fas fa-calendar-check"></i> Persetujuan Cuti
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="../logout.php">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
    </nav>
    
    <div class="main-content">
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="h4 mb-1 fw-bold"><i class="fas fa-users me-2"></i> Manajemen Data Karyawan</h2>
                <p class="text-muted mb-0">Kelola data karyawan Aradea Store</p>
            </div>
            <a href="tambah_karyawan.php" class="btn btn-primary">
                <i class="fas fa-user-plus me-2"></i> Tambah Karyawan
            </a>
        </div>
        
        <?php if (isset($messages[$status])): ?>
        <div class="alert alert-<?= $status == 'error' ? 'danger' : 'success' ?> alert-dismissible fade show" role="alert">
            <i class="fas fa-<?= $status == 'error' ? 'exclamation-triangle' : 'check-circle' ?> me-2"></i>
            <?= $messages[$status] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <!-- Data Table -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Daftar Karyawan (<?= $total_karyawan ?>)</h5>
                    <a href="dashboard.php" class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-arrow-left me-1"></i> Kembali ke Dashboard
                    </a>
                </div>
            </div>
            <div class="card-body p-0">
                <?php if (!$result): ?>
                <div class="alert alert-danger m-3">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <strong>Error Database:</strong> Tidak dapat mengambil data karyawan.
                    <?php if (isset($_SESSION['debug_mode']) && $_SESSION['debug_mode']): ?>
                    <br><small><?= mysqli_error($koneksi) ?></small>
                    <?php endif; ?>
                </div>
                <?php elseif ($total_karyawan == 0): ?>
                <div class="text-center py-5">
                    <i class="fas fa-users fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">Belum ada data karyawan</h5>
                    <p class="text-muted">Mulai dengan menambahkan karyawan baru</p>
                    <a href="tambah_karyawan.php" class="btn btn-primary">
                        <i class="fas fa-user-plus me-2"></i> Tambah Karyawan Pertama
                    </a>
                </div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th width="50">No</th>
                                <th>Nama Lengkap</th>
                                <th>Jabatan</th>
                                <th>ID Barcode</th>
                                <th>Role</th>
                                <th>Username</th>
                                <th width="150">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $no = 1;
                            mysqli_data_seek($result, 0);
                            while ($data = mysqli_fetch_assoc($result)):
                            ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= htmlspecialchars($data['nama_lengkap']) ?></td>
                                <td>
                                    <span class="badge bg-info bg-opacity-10 text-info">
                                        <?= htmlspecialchars($data['jabatan']) ?>
                                    </span>
                                </td>
                                <td>
                                    <code><?= htmlspecialchars($data['barcode_id']) ?></code>
                                </td>
                                <td>
                                    <span class="badge-role badge-<?= strtolower($data['role']) ?>">
                                        <?= $data['role'] ?>
                                    </span>
                                </td>
                                <td>
                                    <code><?= htmlspecialchars($data['username']) ?></code>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="edit_karyawan.php?id=<?= $data['barcode_id'] ?>" 
                                           class="btn btn-outline-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="hapus_karyawan_proses.php?id=<?= $data['barcode_id'] ?>" 
                                           class="btn btn-outline-danger"
                                           onclick="return confirm('Yakin ingin menghapus data ini?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="card-footer bg-white py-3">
                <div class="d-flex justify-content-between align-items-center">
                    <small class="text-muted">Total <?= $total_karyawan ?> karyawan</small>
                    <small class="text-muted">
                        <i class="fas fa-info-circle me-1"></i>
                        Sistem HRIS Aradea Store v1.0
                    </small>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Auto-hide alert after 5 seconds
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    </script>
</body>
</html>
<?php
// Tutup koneksi jika result ada
if (isset($result) && $result) {
    mysqli_free_result($result);
}
mysqli_close($koneksi);
?>