<?php
include '../config/koneksi.php';
include '../config/check_session.php';

if ($_SESSION['role'] !== 'Admin') {
    header('Location: ../index.php');
    exit;
}

$success = $error = '';
$karyawan_list = [];

// Ambil data karyawan untuk dropdown
$query_karyawan = "SELECT k.id, k.nama_lengkap, k.jabatan, k.barcode_id 
                   FROM karyawan k 
                   JOIN users u ON k.user_id = u.id 
                   WHERE u.role = 'Karyawan' 
                   ORDER BY k.nama_lengkap";
$result_karyawan = mysqli_query($koneksi, $query_karyawan);

if ($result_karyawan) {
    while ($row = mysqli_fetch_assoc($result_karyawan)) {
        $karyawan_list[] = $row;
    }
}

// Proses input absensi manual
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_absensi'])) {
    $karyawan_id = $_POST['karyawan_id'];
    $tanggal = $_POST['tanggal'];
    $jam_masuk = $_POST['jam_masuk'];
    $jam_keluar = $_POST['jam_keluar'];
    $status_kehadiran = $_POST['status_kehadiran'];
    
    // Validasi
    if (empty($karyawan_id) || empty($tanggal) || empty($status_kehadiran)) {
        $error = "Data karyawan, tanggal, dan status kehadiran wajib diisi!";
    } else {
        // Cek apakah sudah ada absensi untuk karyawan di tanggal tersebut
        $query_check = "SELECT id FROM absensi 
                       WHERE karyawan_id = $karyawan_id 
                       AND tanggal = '$tanggal'";
        $result_check = mysqli_query($koneksi, $query_check);
        
        if (mysqli_num_rows($result_check) > 0) {
            $error = "Absensi untuk karyawan ini pada tanggal $tanggal sudah ada!";
        } else {
            // Insert absensi baru
            $query_insert = "INSERT INTO absensi 
                            (karyawan_id, tanggal, jam_masuk, jam_keluar, status_kehadiran) 
                            VALUES 
                            ($karyawan_id, '$tanggal', '$jam_masuk', '$jam_keluar', '$status_kehadiran')";
            
            if (mysqli_query($koneksi, $query_insert)) {
                $success = "Absensi berhasil dicatat!";
                
                // Reset form
                $_POST = array();
            } else {
                $error = "Gagal mencatat absensi: " . mysqli_error($koneksi);
            }
        }
    }
}

// Proses edit/update absensi
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_absensi'])) {
    $absensi_id = $_POST['absensi_id'];
    $jam_masuk = $_POST['jam_masuk'];
    $jam_keluar = $_POST['jam_keluar'];
    $status_kehadiran = $_POST['status_kehadiran'];
    
    $query_update = "UPDATE absensi 
                    SET jam_masuk = '$jam_masuk', 
                        jam_keluar = '$jam_keluar', 
                        status_kehadiran = '$status_kehadiran' 
                    WHERE id = $absensi_id";
    
    if (mysqli_query($koneksi, $query_update)) {
        $success = "Absensi berhasil diperbarui!";
    } else {
        $error = "Gagal memperbarui absensi: " . mysqli_error($koneksi);
    }
}

// Proses hapus absensi
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $query_delete = "DELETE FROM absensi WHERE id = $id";
    
    if (mysqli_query($koneksi, $query_delete)) {
        $success = "Absensi berhasil dihapus!";
    } else {
        $error = "Gagal menghapus absensi: " . mysqli_error($koneksi);
    }
}

// Ambil data absensi untuk tabel
$query_absensi = "SELECT a.*, k.nama_lengkap, k.jabatan, k.barcode_id 
                  FROM absensi a 
                  JOIN karyawan k ON a.karyawan_id = k.id 
                  ORDER BY a.tanggal DESC, k.nama_lengkap 
                  LIMIT 50";
$result_absensi = mysqli_query($koneksi, $query_absensi);

$absensi_data = [];
if ($result_absensi) {
    while ($row = mysqli_fetch_assoc($result_absensi)) {
        $absensi_data[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Absensi Manual - HRIS Aradea Store</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Datepicker CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3a0ca3;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: #f8fafc;
        }
        
        .main-content {
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
        }
        
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
        }
        
        .card-header-custom {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border-radius: 10px 10px 0 0 !important;
        }
        
        .status-badge {
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.85rem;
        }
        
        .status-hadir {
            background-color: #d1e7dd;
            color: #0f5132;
        }
        
        .status-terlambat {
            background-color: #fff3cd;
            color: #664d03;
        }
        
        .status-sakit {
            background-color: #cfe2ff;
            color: #084298;
        }
        
        .status-izin {
            background-color: #e7f1ff;
            color: #0d6efd;
        }
        
        .status-alpha {
            background-color: #f8d7da;
            color: #842029;
        }
        
        .time-badge {
            background-color: #e9ecef;
            color: #495057;
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-family: monospace;
        }
        
        .form-section {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            padding: 25px;
            margin-bottom: 25px;
        }
        
        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: 260px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: #1e293b;
            color: white;
            z-index: 1000;
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid #334155;
        }
        
        .user-info {
            padding: 20px;
            border-bottom: 1px solid #334155;
        }
        
        .nav-link {
            color: #cbd5e1;
            padding: 12px 20px;
            transition: all 0.3s;
        }
        
        .nav-link:hover {
            color: white;
            background-color: #334155;
        }
        
        .nav-link.active {
            color: white;
            background-color: #3b82f6;
        }
        
        .nav-link i {
            width: 20px;
            text-align: center;
        }
        
        .action-buttons {
            min-width: 150px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <div class="sidebar-header">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-store text-white"></i>
                </div>
                <div>
                    <h5 class="mb-0 fw-bold">Aradea Store</h5>
                    <small class="text-muted">Portal Admin</small>
                </div>
            </div>
        </div>
        
        <div class="user-info">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-user text-white"></i>
                </div>
                <div>
                    <h6 class="mb-0"><?= htmlspecialchars($_SESSION['username'] ?? 'Admin') ?></h6>
                    <small class="text-muted">Administrator</small>
                </div>
            </div>
        </div>
        
        <ul class="nav flex-column mt-3">
            <li class="nav-item">
                <a class="nav-link text-white" href="dashboard.php">
                    <i class="fas fa-home me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white active" href="absensi_manual.php">
                    <i class="fas fa-clock me-2"></i> Absensi Manual
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="manajemen_karyawan.php">
                    <i class="fas fa-users me-2"></i> Manajemen Karyawan
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="approval_cuti.php">
                    <i class="fas fa-calendar-check me-2"></i> Approval Cuti
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="approval_lembur.php">
                    <i class="fas fa-tasks me-2"></i> Approval Lembur
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="laporan_absensi.php">
                    <i class="fas fa-chart-bar me-2"></i> Laporan Absensi
                </a>
            </li>
            <li class="nav-item mt-4">
                <a class="nav-link text-white" href="../logout.php">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </li>
        </ul>
    </nav>
    
    <div class="main-content">
        <div class="mb-4">
            <a href="dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Kembali ke Dashboard
            </a>
        </div>
        
        <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <?= $success ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-1"><i class="fas fa-clock me-2"></i> Absensi Manual</h1>
                <p class="text-muted mb-0">Input dan kelola data absensi karyawan secara manual</p>
            </div>
            <div class="text-end">
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">
                    <i class="fas fa-plus me-2"></i> Tambah Absensi
                </button>
            </div>
        </div>
        
        <!-- Form Input Absensi (Modal) -->
        <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header card-header-custom">
                        <h5 class="modal-title" id="addModalLabel">
                            <i class="fas fa-clock me-2"></i> Input Absensi Manual
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" id="absensiForm">
                            <input type="hidden" name="submit_absensi" value="1">
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Pilih Karyawan <span class="text-danger">*</span></label>
                                        <select class="form-select" name="karyawan_id" required>
                                            <option value="">-- Pilih Karyawan --</option>
                                            <?php foreach ($karyawan_list as $karyawan): ?>
                                            <option value="<?= $karyawan['id'] ?>" 
                                                    <?= isset($_POST['karyawan_id']) && $_POST['karyawan_id'] == $karyawan['id'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($karyawan['nama_lengkap']) ?> - <?= $karyawan['jabatan'] ?> (<?= $karyawan['barcode_id'] ?>)
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Tanggal <span class="text-danger">*</span></label>
                                        <input type="date" 
                                               class="form-control" 
                                               name="tanggal" 
                                               value="<?= isset($_POST['tanggal']) ? $_POST['tanggal'] : date('Y-m-d') ?>" 
                                               required>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Jam Masuk</label>
                                        <input type="time" 
                                               class="form-control" 
                                               name="jam_masuk" 
                                               value="<?= isset($_POST['jam_masuk']) ? $_POST['jam_masuk'] : '08:00' ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Jam Keluar</label>
                                        <input type="time" 
                                               class="form-control" 
                                               name="jam_keluar" 
                                               value="<?= isset($_POST['jam_keluar']) ? $_POST['jam_keluar'] : '17:00' ?>">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Status Kehadiran <span class="text-danger">*</span></label>
                                <div class="d-flex flex-wrap gap-2">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="status_kehadiran" id="hadir" value="Hadir" 
                                               <?= (!isset($_POST['status_kehadiran']) || $_POST['status_kehadiran'] == 'Hadir') ? 'checked' : '' ?> required>
                                        <label class="form-check-label" for="hadir">
                                            <span class="status-badge status-hadir">Hadir</span>
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="status_kehadiran" id="terlambat" value="Terlambat"
                                               <?= isset($_POST['status_kehadiran']) && $_POST['status_kehadiran'] == 'Terlambat' ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="terlambat">
                                            <span class="status-badge status-terlambat">Terlambat</span>
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="status_kehadiran" id="sakit" value="Sakit"
                                               <?= isset($_POST['status_kehadiran']) && $_POST['status_kehadiran'] == 'Sakit' ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="sakit">
                                            <span class="status-badge status-sakit">Sakit</span>
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="status_kehadiran" id="izin" value="Izin"
                                               <?= isset($_POST['status_kehadiran']) && $_POST['status_kehadiran'] == 'Izin' ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="izin">
                                            <span class="status-badge status-izin">Izin</span>
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="status_kehadiran" id="alpha" value="Alpha"
                                               <?= isset($_POST['status_kehadiran']) && $_POST['status_kehadiran'] == 'Alpha' ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="alpha">
                                            <span class="status-badge status-alpha">Alpha</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="d-flex justify-content-end gap-2">
                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                    <i class="fas fa-times me-2"></i> Batal
                                </button>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-2"></i> Simpan Absensi
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Tabel Data Absensi -->
        <div class="table-responsive">
            <table class="table table-hover table-striped mb-0">
                <thead class="table-dark">
                    <tr>
                        <th width="50">No</th>
                        <th>Nama Karyawan</th>
                        <th>Tanggal</th>
                        <th>Jam Masuk</th>
                        <th>Jam Keluar</th>
                        <th>Status</th>
                        <th>Jabatan</th>
                        <th width="150" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($absensi_data)): ?>
                    <tr>
                        <td colspan="8" class="text-center py-4">
                            <i class="fas fa-clock fa-2x text-muted mb-2 d-block"></i>
                            <p class="text-muted mb-0">Belum ada data absensi</p>
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($absensi_data as $index => $absensi): ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td>
                            <div class="d-flex align-items-center">
                                <div class="rounded-circle bg-primary bg-opacity-10 p-2 me-2">
                                    <i class="fas fa-user text-primary"></i>
                                </div>
                                <div>
                                    <strong><?= htmlspecialchars($absensi['nama_lengkap']) ?></strong><br>
                                    <small class="text-muted">ID: <?= $absensi['barcode_id'] ?></small>
                                </div>
                            </div>
                        </td>
                        <td>
                            <strong><?= date('d M Y', strtotime($absensi['tanggal'])) ?></strong><br>
                            <small class="text-muted"><?= date('l', strtotime($absensi['tanggal'])) ?></small>
                        </td>
                        <td>
                            <?php if ($absensi['jam_masuk']): ?>
                            <span class="time-badge">
                                <i class="fas fa-sign-in-alt me-1"></i>
                                <?= date('H:i', strtotime($absensi['jam_masuk'])) ?>
                            </span>
                            <?php else: ?>
                            <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($absensi['jam_keluar']): ?>
                            <span class="time-badge">
                                <i class="fas fa-sign-out-alt me-1"></i>
                                <?= date('H:i', strtotime($absensi['jam_keluar'])) ?>
                            </span>
                            <?php else: ?>
                            <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                            $status_class = '';
                            switch ($absensi['status_kehadiran']) {
                                case 'Hadir': $status_class = 'status-hadir'; break;
                                case 'Terlambat': $status_class = 'status-terlambat'; break;
                                case 'Sakit': $status_class = 'status-sakit'; break;
                                case 'Izin': $status_class = 'status-izin'; break;
                                case 'Alpha': $status_class = 'status-alpha'; break;
                                default: $status_class = 'status-hadir';
                            }
                            ?>
                            <span class="status-badge <?= $status_class ?>">
                                <?= $absensi['status_kehadiran'] ?>
                            </span>
                        </td>
                        <td><?= $absensi['jabatan'] ?></td>
                        <td class="text-center action-buttons">
                            <button class="btn btn-sm btn-warning me-1" 
                                    data-bs-toggle="modal" 
                                    data-bs-target="#editModal<?= $absensi['id'] ?>"
                                    title="Edit">
                                <i class="fas fa-edit"></i>
                            </button>
                            <a href="?hapus=<?= $absensi['id'] ?>" 
                               class="btn btn-sm btn-danger" 
                               onclick="return confirm('Yakin ingin menghapus absensi ini?')"
                               title="Hapus">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    
                    <!-- Modal Edit -->
                    <div class="modal fade" id="editModal<?= $absensi['id'] ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header card-header-custom">
                                    <h5 class="modal-title">
                                        <i class="fas fa-edit me-2"></i> Edit Absensi
                                    </h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <form method="POST">
                                        <input type="hidden" name="update_absensi" value="1">
                                        <input type="hidden" name="absensi_id" value="<?= $absensi['id'] ?>">
                                        
                                        <div class="mb-3">
                                            <label class="form-label">Karyawan</label>
                                            <input type="text" class="form-control" value="<?= htmlspecialchars($absensi['nama_lengkap']) ?>" disabled>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label class="form-label">Tanggal</label>
                                            <input type="date" class="form-control" value="<?= $absensi['tanggal'] ?>" disabled>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="mb-3">
                                                    <label class="form-label">Jam Masuk</label>
                                                    <input type="time" 
                                                           class="form-control" 
                                                           name="jam_masuk" 
                                                           value="<?= $absensi['jam_masuk'] ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="mb-3">
                                                    <label class="form-label">Jam Keluar</label>
                                                    <input type="time" 
                                                           class="form-control" 
                                                           name="jam_keluar" 
                                                           value="<?= $absensi['jam_keluar'] ?>">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label class="form-label">Status Kehadiran</label>
                                            <select class="form-select" name="status_kehadiran">
                                                <option value="Hadir" <?= $absensi['status_kehadiran'] == 'Hadir' ? 'selected' : '' ?>>Hadir</option>
                                                <option value="Terlambat" <?= $absensi['status_kehadiran'] == 'Terlambat' ? 'selected' : '' ?>>Terlambat</option>
                                                <option value="Sakit" <?= $absensi['status_kehadiran'] == 'Sakit' ? 'selected' : '' ?>>Sakit</option>
                                                <option value="Izin" <?= $absensi['status_kehadiran'] == 'Izin' ? 'selected' : '' ?>>Izin</option>
                                                <option value="Alpha" <?= $absensi['status_kehadiran'] == 'Alpha' ? 'selected' : '' ?>>Alpha</option>
                                            </select>
                                        </div>
                                        
                                        <div class="d-flex justify-content-end gap-2">
                                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                                <i class="fas fa-times me-2"></i> Batal
                                            </button>
                                            <button type="submit" class="btn btn-primary">
                                                <i class="fas fa-save me-2"></i> Simpan Perubahan
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Statistik -->
        <div class="row mt-4">
            <div class="col-md-3">
                <div class="card border-primary">
                    <div class="card-body text-center">
                        <h1 class="display-6 text-primary">
                            <i class="fas fa-users"></i>
                        </h1>
                        <h5 class="card-title">Total Karyawan</h5>
                        <h3 class="card-text"><?= count($karyawan_list) ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-success">
                    <div class="card-body text-center">
                        <h1 class="display-6 text-success">
                            <i class="fas fa-check-circle"></i>
                        </h1>
                        <h5 class="card-title">Absensi Hari Ini</h5>
                        <h3 class="card-text">
                            <?php
                            $today = date('Y-m-d');
                            $query_today = "SELECT COUNT(*) as total FROM absensi WHERE tanggal = '$today'";
                            $result_today = mysqli_query($koneksi, $query_today);
                            $today_data = mysqli_fetch_assoc($result_today);
                            echo $today_data['total'] ?? 0;
                            ?>
                        </h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-warning">
                    <div class="card-body text-center">
                        <h1 class="display-6 text-warning">
                            <i class="fas fa-clock"></i>
                        </h1>
                        <h5 class="card-title">Total Absensi</h5>
                        <h3 class="card-text"><?= count($absensi_data) ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-info">
                    <div class="card-body text-center">
                        <h1 class="display-6 text-info">
                            <i class="fas fa-calendar-alt"></i>
                        </h1>
                        <h5 class="card-title">Tanggal Hari Ini</h5>
                        <h5 class="card-text"><?= date('d M Y') ?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Flatpickr -->
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    
    <script>
        // Inisialisasi datepicker
        flatpickr("input[type=date]", {
            dateFormat: "Y-m-d",
            locale: "id"
        });
        
        // Auto-hide alert after 5 seconds
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
        
        // Form validation
        document.getElementById('absensiForm').addEventListener('submit', function(e) {
            const karyawan = document.querySelector('[name="karyawan_id"]').value;
            const tanggal = document.querySelector('[name="tanggal"]').value;
            const status = document.querySelector('[name="status_kehadiran"]:checked');
            
            if (!karyawan || !tanggal || !status) {
                e.preventDefault();
                alert('Harap lengkapi semua field yang wajib diisi!');
                return false;
            }
            
            if (!confirm('Anda yakin ingin menyimpan absensi ini?')) {
                e.preventDefault();
                return false;
            }
        });
        
        // Auto-open modal if there's an error
        <?php if ($error && isset($_POST['submit_absensi'])): ?>
        document.addEventListener('DOMContentLoaded', function() {
            const modal = new bootstrap.Modal(document.getElementById('addModal'));
            modal.show();
        });
        <?php endif; ?>
    </script>
</body>
</html>
<?php
mysqli_close($koneksi);
?>