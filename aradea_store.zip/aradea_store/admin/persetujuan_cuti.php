<?php
include '../config/koneksi.php';
include '../config/check_session.php';

// Cek role admin
if ($_SESSION['role'] !== 'Admin') {
    header('Location: ../index.php');
    exit;
}

// Handle actions (approve/reject)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $cuti_id = intval($_GET['id']);
    $action = $_GET['action'];
    
    // Validasi action
    if (in_array($action, ['approve', 'reject'])) {
        $status = ($action === 'approve') ? 'Approved' : 'Rejected';
        
        // Update status cuti
        $query = "UPDATE cuti SET status_approv = ? WHERE id = ?";
        $stmt = mysqli_prepare($koneksi, $query);
        mysqli_stmt_bind_param($stmt, "si", $status, $cuti_id);
        
        if (mysqli_stmt_execute($stmt)) {
            // Jika approved, kurangi sisa cuti karyawan
            if ($action === 'approve') {
                // Hitung jumlah hari cuti
                $query_hari = "SELECT karyawan_id, tanggal_mulai, tanggal_akhir 
                              FROM cuti WHERE id = $cuti_id";
                $result_hari = mysqli_query($koneksi, $query_hari);
                if ($result_hari && $row = mysqli_fetch_assoc($result_hari)) {
                    $karyawan_id = $row['karyawan_id'];
                    $tgl_mulai = new DateTime($row['tanggal_mulai']);
                    $tgl_akhir = new DateTime($row['tanggal_akhir']);
                    $jumlah_hari = $tgl_mulai->diff($tgl_akhir)->days + 1;
                    
                    // Kurangi sisa cuti
                    $query_kurangi = "UPDATE karyawan 
                                     SET sisa_cuti = sisa_cuti - $jumlah_hari 
                                     WHERE id = $karyawan_id";
                    mysqli_query($koneksi, $query_kurangi);
                }
            }
            
            // Redirect dengan status sukses
            header('Location: persetujuan_cuti.php?status=' . $action . '_success');
            exit;
        } else {
            $error_message = "Gagal memproses permohonan: " . mysqli_error($koneksi);
        }
    }
}

// Query untuk mendapatkan data cuti yang pending
$query = "
    SELECT 
        c.id,
        c.tanggal_mulai,
        c.tanggal_akhir,
        c.jenis_cuti,
        c.alasan,
        c.status_approv,
        k.nama_lengkap,
        k.jabatan,
        k.sisa_cuti,
        DATEDIFF(c.tanggal_akhir, c.tanggal_mulai) + 1 as jumlah_hari
    FROM 
        cuti c
    JOIN 
        karyawan k ON c.karyawan_id = k.id
    ORDER BY 
        c.tanggal_mulai ASC, 
        FIELD(c.status_approv, 'Pending', 'Approved', 'Rejected')
";

$result = mysqli_query($koneksi, $query);
$total_pending = 0;
$total_approved = 0;
$total_rejected = 0;
$total_cuti = $result ? mysqli_num_rows($result) : 0;

// Hitung status
if ($result) {
    mysqli_data_seek($result, 0);
    while ($row = mysqli_fetch_assoc($result)) {
        if ($row['status_approv'] == 'Pending') $total_pending++;
        if ($row['status_approv'] == 'Approved') $total_approved++;
        if ($row['status_approv'] == 'Rejected') $total_rejected++;
    }
    mysqli_data_seek($result, 0);
}

// Status messages
$status = $_GET['status'] ?? '';
$messages = [
    'approve_success' => 'Cuti berhasil disetujui!',
    'reject_success' => 'Cuti berhasil ditolak!',
    'error' => 'Terjadi kesalahan. Silakan coba lagi.'
];
?>
<!DOCTYPE html>
<html lang="id" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Persetujuan Cuti - HRIS Aradea Store</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3a0ca3;
            --sidebar-width: 260px;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: #f8fafc;
        }
        
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            min-height: 100vh;
        }
        
        .card-header-custom {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
        }
        
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.85rem;
        }
        
        .badge-pending {
            background: rgba(255, 193, 7, 0.15);
            color: #ffc107;
            border: 1px solid rgba(255, 193, 7, 0.3);
        }
        
        .badge-approved {
            background: rgba(40, 167, 69, 0.15);
            color: #28a745;
            border: 1px solid rgba(40, 167, 69, 0.3);
        }
        
        .badge-rejected {
            background: rgba(220, 53, 69, 0.15);
            color: #dc3545;
            border: 1px solid rgba(220, 53, 69, 0.3);
        }
        
        .cuti-card {
            border-left: 4px solid;
            border-radius: 8px;
            transition: transform 0.2s;
        }
        
        .cuti-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .cuti-pending {
            border-left-color: #ffc107;
            background: rgba(255, 193, 7, 0.05);
        }
        
        .cuti-approved {
            border-left-color: #28a745;
            background: rgba(40, 167, 69, 0.05);
        }
        
        .cuti-rejected {
            border-left-color: #dc3545;
            background: rgba(220, 53, 69, 0.05);
        }
        
        .action-buttons .btn {
            min-width: 90px;
        }
        
        .stats-card {
            border-radius: 10px;
            transition: all 0.3s;
        }
        
        .stats-card:hover {
            transform: translateY(-3px);
        }
        
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            
            .action-buttons {
                flex-direction: column;
                gap: 5px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar" style="width: 260px; height: 100vh; position: fixed; left: 0; top: 0; background: #1e293b; color: white;">
        <div class="sidebar-header p-3">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-store text-white"></i>
                </div>
                <div>
                    <h5 class="mb-0 fw-bold">Aradea Store</h5>
                    <small class="text-muted">HRIS System</small>
                </div>
            </div>
        </div>
        
        <div class="user-info p-3 border-bottom border-secondary">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-user text-white"></i>
                </div>
                <div>
                    <h6 class="mb-0"><?= htmlspecialchars($_SESSION['nama_lengkap'] ?? $_SESSION['username']) ?></h6>
                    <small class="text-muted"><?= $_SESSION['role'] ?></small>
                </div>
            </div>
        </div>
        
        <ul class="nav flex-column mt-3">
            <li class="nav-item">
                <a class="nav-link text-white" href="dashboard.php">
                    <i class="fas fa-home me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="manajemen_karyawan.php">
                    <i class="fas fa-users me-2"></i> Data Karyawan
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white active" href="persetujuan_cuti.php">
                    <i class="fas fa-calendar-check me-2"></i> Persetujuan Cuti
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="persetujuan_lembur.php">
                    <i class="fas fa-clock me-2"></i> Persetujuan Lembur
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="laporan_sdm.php">
                    <i class="fas fa-chart-bar me-2"></i> Laporan SDM
                </a>
            </li>
            <li class="nav-item mt-4">
                <a class="nav-link text-white" href="../logout.php">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </li>
        </ul>
    </nav>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-2 fw-bold"><i class="fas fa-calendar-check me-2"></i> Persetujuan Cuti Karyawan</h1>
                <p class="text-muted mb-0">Kelola pengajuan cuti karyawan Aradea Store</p>
            </div>
            <a href="dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Kembali ke Dashboard
            </a>
        </div>
        
        <!-- Status Messages -->
        <?php if (isset($messages[$status])): ?>
        <div class="alert alert-<?= strpos($status, 'success') ? 'success' : 'danger' ?> alert-dismissible fade show" role="alert">
            <i class="fas fa-<?= strpos($status, 'success') ? 'check-circle' : 'exclamation-triangle' ?> me-2"></i>
            <?= $messages[$status] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <?= $error_message ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <!-- Stats Cards -->
        <div class="row g-4 mb-4">
            <div class="col-xl-3 col-md-6">
                <div class="card stats-card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="bg-warning bg-opacity-10 p-3 rounded-circle me-3">
                                <i class="fas fa-clock fa-2x text-warning"></i>
                            </div>
                            <div>
                                <h6 class="text-muted mb-1">Menunggu</h6>
                                <h2 class="mb-0 fw-bold"><?= $total_pending ?></h2>
                                <small class="text-muted">Pengajuan cuti</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card stats-card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="bg-success bg-opacity-10 p-3 rounded-circle me-3">
                                <i class="fas fa-check-circle fa-2x text-success"></i>
                            </div>
                            <div>
                                <h6 class="text-muted mb-1">Disetujui</h6>
                                <h2 class="mb-0 fw-bold"><?= $total_approved ?></h2>
                                <small class="text-muted">Pengajuan cuti</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card stats-card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="bg-danger bg-opacity-10 p-3 rounded-circle me-3">
                                <i class="fas fa-times-circle fa-2x text-danger"></i>
                            </div>
                            <div>
                                <h6 class="text-muted mb-1">Ditolak</h6>
                                <h2 class="mb-0 fw-bold"><?= $total_rejected ?></h2>
                                <small class="text-muted">Pengajuan cuti</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card stats-card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="bg-info bg-opacity-10 p-3 rounded-circle me-3">
                                <i class="fas fa-calendar-alt fa-2x text-info"></i>
                            </div>
                            <div>
                                <h6 class="text-muted mb-1">Total</h6>
                                <h2 class="mb-0 fw-bold"><?= $total_cuti ?></h2>
                                <small class="text-muted">Semua pengajuan</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Filter Tabs -->
        <ul class="nav nav-tabs mb-4" id="cutiTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="pending-tab" data-bs-toggle="tab" data-bs-target="#pending" type="button">
                    <i class="fas fa-clock me-1"></i> Menunggu
                    <span class="badge bg-warning ms-2"><?= $total_pending ?></span>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="approved-tab" data-bs-toggle="tab" data-bs-target="#approved" type="button">
                    <i class="fas fa-check-circle me-1"></i> Disetujui
                    <span class="badge bg-success ms-2"><?= $total_approved ?></span>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="rejected-tab" data-bs-toggle="tab" data-bs-target="#rejected" type="button">
                    <i class="fas fa-times-circle me-1"></i> Ditolak
                    <span class="badge bg-danger ms-2"><?= $total_rejected ?></span>
                </button>
            </li>
        </ul>
        
        <!-- Tab Content -->
        <div class="tab-content" id="cutiTabContent">
            <!-- PENDING TAB -->
            <div class="tab-pane fade show active" id="pending" role="tabpanel">
                <?php if (!$result): ?>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Tidak dapat mengambil data cuti. Pastikan tabel cuti sudah dibuat.
                </div>
                <?php elseif ($total_pending == 0): ?>
                <div class="text-center py-5">
                    <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">Tidak ada pengajuan cuti yang menunggu</h5>
                    <p class="text-muted">Semua pengajuan cuti telah diproses</p>
                </div>
                <?php else: ?>
                <div class="row g-4">
                    <?php 
                    mysqli_data_seek($result, 0);
                    $found_pending = false;
                    while ($cuti = mysqli_fetch_assoc($result)):
                        if ($cuti['status_approv'] != 'Pending') continue;
                        $found_pending = true;
                        
                        // Format tanggal
                        $tanggal_mulai = date('d M Y', strtotime($cuti['tanggal_mulai']));
                        $tanggal_akhir = date('d M Y', strtotime($cuti['tanggal_akhir']));
                        $jumlah_hari = $cuti['jumlah_hari'];
                    ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card cuti-card cuti-pending h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div>
                                        <h6 class="card-title mb-1 fw-bold"><?= htmlspecialchars($cuti['nama_lengkap']) ?></h6>
                                        <small class="text-muted"><?= $cuti['jabatan'] ?></small>
                                    </div>
                                    <span class="status-badge badge-pending">Menunggu</span>
                                </div>
                                
                                <div class="mb-3">
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="fas fa-calendar-day text-warning me-2"></i>
                                        <span><?= $tanggal_mulai ?> - <?= $tanggal_akhir ?></span>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="fas fa-clock text-warning me-2"></i>
                                        <span><?= $jumlah_hari ?> hari kerja</span>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-user-clock text-warning me-2"></i>
                                        <span>Sisa cuti: <?= $cuti['sisa_cuti'] ?> hari</span>
                                    </div>
                                </div>
                                
                                <?php if (!empty($cuti['jenis_cuti'])): ?>
                                <div class="mb-2">
                                    <small class="text-muted">Jenis Cuti:</small>
                                    <p class="mb-0"><strong><?= htmlspecialchars($cuti['jenis_cuti']) ?></strong></p>
                                </div>
                                <?php endif; ?>
                                
                                <?php if (!empty($cuti['alasan'])): ?>
                                <div class="mb-3">
                                    <small class="text-muted">Alasan:</small>
                                    <p class="mb-0 small"><?= nl2br(htmlspecialchars($cuti['alasan'])) ?></p>
                                </div>
                                <?php endif; ?>
                                
                                <div class="action-buttons d-flex gap-2">
                                    <button class="btn btn-success btn-sm flex-fill" 
                                            onclick="confirmAction(<?= $cuti['id'] ?>, 'approve', '<?= htmlspecialchars($cuti['nama_lengkap']) ?>', <?= $jumlah_hari ?>)">
                                        <i class="fas fa-check me-1"></i> Setujui
                                    </button>
                                    <button class="btn btn-danger btn-sm flex-fill" 
                                            onclick="confirmAction(<?= $cuti['id'] ?>, 'reject', '<?= htmlspecialchars($cuti['nama_lengkap']) ?>', <?= $jumlah_hari ?>)">
                                        <i class="fas fa-times me-1"></i> Tolak
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                    
                    <?php if (!$found_pending): ?>
                    <div class="col-12">
                        <div class="text-center py-5">
                            <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                            <h5 class="text-success">Tidak ada pengajuan yang menunggu</h5>
                            <p class="text-muted">Semua pengajuan cuti telah diproses</p>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- APPROVED TAB -->
            <div class="tab-pane fade" id="approved" role="tabpanel">
                <?php if ($total_approved == 0): ?>
                <div class="text-center py-5">
                    <i class="fas fa-check-circle fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">Belum ada cuti yang disetujui</h5>
                </div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Karyawan</th>
                                <th>Periode</th>
                                <th>Lama</th>
                                <th>Jenis</th>
                                <th>Sisa Cuti</th>
                                <th>Tanggal Disetujui</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            mysqli_data_seek($result, 0);
                            while ($cuti = mysqli_fetch_assoc($result)):
                                if ($cuti['status_approv'] != 'Approved') continue;
                            ?>
                            <tr>
                                <td>
                                    <div>
                                        <strong><?= htmlspecialchars($cuti['nama_lengkap']) ?></strong>
                                        <br>
                                        <small class="text-muted"><?= $cuti['jabatan'] ?></small>
                                    </div>
                                </td>
                                <td>
                                    <?= date('d M Y', strtotime($cuti['tanggal_mulai'])) ?><br>
                                    <small class="text-muted">s/d</small><br>
                                    <?= date('d M Y', strtotime($cuti['tanggal_akhir'])) ?>
                                </td>
                                <td>
                                    <span class="badge bg-info"><?= $cuti['jumlah_hari'] ?> hari</span>
                                </td>
                                <td><?= htmlspecialchars($cuti['jenis_cuti'] ?? '-') ?></td>
                                <td><?= $cuti['sisa_cuti'] ?> hari</td>
                                <td>
                                    <span class="badge bg-success">Disetujui</span>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- REJECTED TAB -->
            <div class="tab-pane fade" id="rejected" role="tabpanel">
                <?php if ($total_rejected == 0): ?>
                <div class="text-center py-5">
                    <i class="fas fa-times-circle fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">Belum ada cuti yang ditolak</h5>
                </div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Karyawan</th>
                                <th>Periode</th>
                                <th>Lama</th>
                                <th>Jenis</th>
                                <th>Alasan</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            mysqli_data_seek($result, 0);
                            while ($cuti = mysqli_fetch_assoc($result)):
                                if ($cuti['status_approv'] != 'Rejected') continue;
                            ?>
                            <tr>
                                <td>
                                    <div>
                                        <strong><?= htmlspecialchars($cuti['nama_lengkap']) ?></strong>
                                        <br>
                                        <small class="text-muted"><?= $cuti['jabatan'] ?></small>
                                    </div>
                                </td>
                                <td>
                                    <?= date('d M Y', strtotime($cuti['tanggal_mulai'])) ?><br>
                                    <small class="text-muted">s/d</small><br>
                                    <?= date('d M Y', strtotime($cuti['tanggal_akhir'])) ?>
                                </td>
                                <td>
                                    <span class="badge bg-secondary"><?= $cuti['jumlah_hari'] ?> hari</span>
                                </td>
                                <td><?= htmlspecialchars($cuti['jenis_cuti'] ?? '-') ?></td>
                                <td>
                                    <?php if (!empty($cuti['alasan'])): ?>
                                    <small><?= substr(htmlspecialchars($cuti['alasan']), 0, 50) ?>...</small>
                                    <?php else: ?>
                                    <small class="text-muted">-</small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-danger">Ditolak</span>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Confirm action function
        function confirmAction(cutiId, action, namaKaryawan, jumlahHari) {
            const actionText = action === 'approve' ? 'menyetujui' : 'menolak';
            const hariText = jumlahHari > 1 ? `${jumlahHari} hari` : `${jumlahHari} hari`;
            
            let message = `Anda yakin ingin ${actionText} cuti untuk:\n`;
            message += `Karyawan: ${namaKaryawan}\n`;
            message += `Lama cuti: ${hariText}\n\n`;
            
            if (action === 'approve') {
                message += `*Sisa cuti akan dikurangi ${jumlahHari} hari`;
            }
            
            if (confirm(message)) {
                window.location.href = `persetujuan_cuti.php?action=${action}&id=${cutiId}`;
            }
        }
        
        // Auto-hide alerts after 5 seconds
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
        
        // Update tab badges based on data
        document.addEventListener('DOMContentLoaded', function() {
            const pendingTab = document.getElementById('pending-tab');
            const approvedTab = document.getElementById('approved-tab');
            const rejectedTab = document.getElementById('rejected-tab');
            
            // Set active tab based on URL parameter
            const urlParams = new URLSearchParams(window.location.search);
            const tabParam = urlParams.get('tab');
            
            if (tabParam) {
                const tabElement = document.getElementById(`${tabParam}-tab`);
                if (tabElement) {
                    const tab = new bootstrap.Tab(tabElement);
                    tab.show();
                }
            }
        });
    </script>
</body>
</html>
<?php
// Clean up
if (isset($result) && $result) {
    mysqli_free_result($result);
}
mysqli_close($koneksi);
?>