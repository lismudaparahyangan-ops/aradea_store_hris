<?php
// Panggil session check dan koneksi database
include '../config/koneksi.php';
include '../config/check_session.php'; 

// Pastikan hanya Admin yang bisa mengakses
if ($_SESSION['role'] !== 'Admin') {
    header('Location: ../index.php');
    exit;
}

// 1. Ambil Barcode ID dari URL
$barcode_id = mysqli_real_escape_string($koneksi, $_GET['id']);

if ($barcode_id) {
    
    // 2. Cari user_id yang terkait sebelum menghapus dari tabel karyawan
    $query_find_user = "SELECT user_id FROM karyawan WHERE barcode_id = '$barcode_id'";
    $result_find_user = mysqli_query($koneksi, $query_find_user);
    $data_karyawan = mysqli_fetch_assoc($result_find_user);
    
    if ($data_karyawan) {
        $user_id_to_delete = $data_karyawan['user_id'];

        // --- Proses Transaksi Hapus ---
        
        // A. Hapus dari tabel karyawan (Tabel Anak)
        $query_karyawan = "DELETE FROM karyawan WHERE barcode_id = '$barcode_id'";
        if (mysqli_query($koneksi, $query_karyawan)) {
            
            // B. Hapus dari tabel users (Tabel Induk)
            $query_user = "DELETE FROM users WHERE id = '$user_id_to_delete'";
            if (mysqli_query($koneksi, $query_user)) {
                
                // Sukses!
                header('Location: manajemen_karyawan.php?status=sukses_hapus');
                exit;
            } else {
                // Jika DELETE dari users gagal (Sangat jarang terjadi)
                echo "Gagal menghapus data login (users).";
            }
        } else {
            // Jika DELETE dari karyawan gagal
            echo "Gagal menghapus detail karyawan. Error: " . mysqli_error($koneksi);
        }
        
    } else {
        echo "Data karyawan tidak ditemukan.";
    }
} else {
    echo "ID Karyawan tidak valid.";
}

mysqli_close($koneksi);
?>