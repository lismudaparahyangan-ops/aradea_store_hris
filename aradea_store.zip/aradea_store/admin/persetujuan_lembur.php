<?php
include '../config/koneksi.php';
include '../config/check_session.php';

// Cek role admin
if ($_SESSION['role'] !== 'Admin') {
    header('Location: ../index.php');
    exit;
}

// Handle actions (approve/reject)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $lembur_id = intval($_GET['id']);
    $action = $_GET['action'];
    
    // Validasi action
    if (in_array($action, ['approve', 'reject'])) {
        $status = ($action === 'approve') ? 'Approved' : 'Rejected';
        
        // Update status lembur
        $query = "UPDATE lembur SET status_approv = ? WHERE id = ?";
        $stmt = mysqli_prepare($koneksi, $query);
        mysqli_stmt_bind_param($stmt, "si", $status, $lembur_id);
        
        if (mysqli_stmt_execute($stmt)) {
            // Redirect dengan status sukses
            header('Location: persetujuan_lembur.php?status=' . $action . '_success');
            exit;
        } else {
            $error_message = "Gagal memproses permohonan: " . mysqli_error($koneksi);
        }
    }
}

// Query untuk mendapatkan data lembur
$query = "
    SELECT 
        l.id,
        l.tanggal,
        l.jam_mulai,
        l.jam_akhir,
        l.alasan,
        l.status_approv,
        k.nama_lengkap,
        k.jabatan,
        u.username,
        TIMEDIFF(l.jam_akhir, l.jam_mulai) as durasi,
        TIME_TO_SEC(TIMEDIFF(l.jam_akhir, l.jam_mulai)) / 3600 as jam_lembur
    FROM 
        lembur l
    JOIN 
        karyawan k ON l.karyawan_id = k.id
    JOIN
        users u ON k.user_id = u.id
    ORDER BY 
        l.tanggal DESC, 
        FIELD(l.status_approv, 'Pending', 'Approved', 'Rejected')
";

$result = mysqli_query($koneksi, $query);
$total_pending = 0;
$total_approved = 0;
$total_rejected = 0;
$total_lembur = $result ? mysqli_num_rows($result) : 0;

// Hitung total jam lembur
$total_jam_lembur = 0;
$total_jam_pending = 0;
$total_jam_approved = 0;

// Hitung status dan jam
if ($result) {
    mysqli_data_seek($result, 0);
    while ($row = mysqli_fetch_assoc($result)) {
        $jam_lembur = floatval($row['jam_lembur']);
        
        if ($row['status_approv'] == 'Pending') {
            $total_pending++;
            $total_jam_pending += $jam_lembur;
        }
        if ($row['status_approv'] == 'Approved') {
            $total_approved++;
            $total_jam_approved += $jam_lembur;
        }
        if ($row['status_approv'] == 'Rejected') $total_rejected++;
        
        $total_jam_lembur += $jam_lembur;
    }
    mysqli_data_seek($result, 0);
}

// Status messages
$status = $_GET['status'] ?? '';
$messages = [
    'approve_success' => 'Lembur berhasil disetujui!',
    'reject_success' => 'Lembur berhasil ditolak!',
    'error' => 'Terjadi kesalahan. Silakan coba lagi.'
];

// Filter by status
$filter_status = $_GET['filter'] ?? 'all';
$status_condition = '';
if ($filter_status !== 'all') {
    $status_condition = " WHERE l.status_approv = '" . mysqli_real_escape_string($koneksi, ucfirst($filter_status)) . "'";
}

// Query filtered data
$filtered_query = "
    SELECT 
        l.id,
        l.tanggal,
        l.jam_mulai,
        l.jam_akhir,
        l.alasan,
        l.status_approv,
        k.nama_lengkap,
        k.jabatan,
        u.username,
        TIMEDIFF(l.jam_akhir, l.jam_mulai) as durasi,
        TIME_TO_SEC(TIMEDIFF(l.jam_akhir, l.jam_mulai)) / 3600 as jam_lembur
    FROM 
        lembur l
    JOIN 
        karyawan k ON l.karyawan_id = k.id
    JOIN
        users u ON k.user_id = u.id
    $status_condition
    ORDER BY 
        l.tanggal DESC
";

$filtered_result = mysqli_query($koneksi, $filtered_query);
?>
<!DOCTYPE html>
<html lang="id" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Persetujuan Lembur - HRIS Aradea Store</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Datepicker -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3a0ca3;
            --sidebar-width: 260px;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: #f8fafc;
        }
        
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            min-height: 100vh;
        }
        
        .card-header-custom {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
        }
        
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.85rem;
        }
        
        .badge-pending {
            background: rgba(255, 193, 7, 0.15);
            color: #ffc107;
            border: 1px solid rgba(255, 193, 7, 0.3);
        }
        
        .badge-approved {
            background: rgba(40, 167, 69, 0.15);
            color: #28a745;
            border: 1px solid rgba(40, 167, 69, 0.3);
        }
        
        .badge-rejected {
            background: rgba(220, 53, 69, 0.15);
            color: #dc3545;
            border: 1px solid rgba(220, 53, 69, 0.3);
        }
        
        .lembur-card {
            border-radius: 10px;
            transition: all 0.3s;
            border-left: 4px solid transparent;
        }
        
        .lembur-card.pending {
            border-left-color: #ffc107;
            background: rgba(255, 193, 7, 0.05);
        }
        
        .lembur-card.approved {
            border-left-color: #28a745;
            background: rgba(40, 167, 69, 0.05);
        }
        
        .lembur-card.rejected {
            border-left-color: #dc3545;
            background: rgba(220, 53, 69, 0.05);
        }
        
        .lembur-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .stats-card {
            border-radius: 10px;
            transition: all 0.3s;
        }
        
        .stats-card:hover {
            transform: translateY(-3px);
        }
        
        .time-badge {
            background: rgba(67, 97, 238, 0.1);
            color: var(--primary-color);
            padding: 8px 15px;
            border-radius: 8px;
            font-weight: 600;
        }
        
        .filter-badge.active {
            background: var(--primary-color);
            color: white;
        }
        
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar" style="width: 260px; height: 100vh; position: fixed; left: 0; top: 0; background: #1e293b; color: white;">
        <div class="sidebar-header p-3">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-store text-white"></i>
                </div>
                <div>
                    <h5 class="mb-0 fw-bold">Aradea Store</h5>
                    <small class="text-muted">HRIS System</small>
                </div>
            </div>
        </div>
        
        <div class="user-info p-3 border-bottom border-secondary">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-user text-white"></i>
                </div>
                <div>
                    <h6 class="mb-0"><?= htmlspecialchars($_SESSION['nama_lengkap'] ?? $_SESSION['username']) ?></h6>
                    <small class="text-muted"><?= $_SESSION['role'] ?></small>
                </div>
            </div>
        </div>
        
        <ul class="nav flex-column mt-3">
            <li class="nav-item">
                <a class="nav-link text-white" href="dashboard.php">
                    <i class="fas fa-home me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="manajemen_karyawan.php">
                    <i class="fas fa-users me-2"></i> Data Karyawan
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="persetujuan_cuti.php">
                    <i class="fas fa-calendar-check me-2"></i> Persetujuan Cuti
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white active" href="persetujuan_lembur.php">
                    <i class="fas fa-clock me-2"></i> Persetujuan Lembur
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="laporan_sdm.php">
                    <i class="fas fa-chart-bar me-2"></i> Laporan SDM
                </a>
            </li>
            <li class="nav-item mt-4">
                <a class="nav-link text-white" href="../logout.php">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </li>
        </ul>
    </nav>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-2 fw-bold"><i class="fas fa-clock me-2"></i> Persetujuan Lembur Karyawan</h1>
                <p class="text-muted mb-0">Kelola pengajuan lembur karyawan Aradea Store</p>
            </div>
            <div>
                <a href="dashboard.php" class="btn btn-outline-secondary me-2">
                    <i class="fas fa-arrow-left me-2"></i> Dashboard
                </a>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exportModal">
                    <i class="fas fa-download me-2"></i> Export
                </button>
            </div>
        </div>
        
        <!-- Status Messages -->
        <?php if (isset($messages[$status])): ?>
        <div class="alert alert-<?= strpos($status, 'success') ? 'success' : 'danger' ?> alert-dismissible fade show" role="alert">
            <i class="fas fa-<?= strpos($status, 'success') ? 'check-circle' : 'exclamation-triangle' ?> me-2"></i>
            <?= $messages[$status] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <?= $error_message ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <!-- Stats Cards -->
        <div class="row g-4 mb-4">
            <div class="col-xl-3 col-md-6">
                <div class="card stats-card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="bg-warning bg-opacity-10 p-3 rounded-circle me-3">
                                <i class="fas fa-clock fa-2x text-warning"></i>
                            </div>
                            <div>
                                <h6 class="text-muted mb-1">Menunggu</h6>
                                <h2 class="mb-0 fw-bold"><?= $total_pending ?></h2>
                                <small class="text-muted"><?= number_format($total_jam_pending, 1) ?> jam</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card stats-card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="bg-success bg-opacity-10 p-3 rounded-circle me-3">
                                <i class="fas fa-check-circle fa-2x text-success"></i>
                            </div>
                            <div>
                                <h6 class="text-muted mb-1">Disetujui</h6>
                                <h2 class="mb-0 fw-bold"><?= $total_approved ?></h2>
                                <small class="text-muted"><?= number_format($total_jam_approved, 1) ?> jam</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card stats-card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="bg-danger bg-opacity-10 p-3 rounded-circle me-3">
                                <i class="fas fa-times-circle fa-2x text-danger"></i>
                            </div>
                            <div>
                                <h6 class="text-muted mb-1">Ditolak</h6>
                                <h2 class="mb-0 fw-bold"><?= $total_rejected ?></h2>
                                <small class="text-muted">Pengajuan lembur</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card stats-card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="bg-primary bg-opacity-10 p-3 rounded-circle me-3">
                                <i class="fas fa-chart-line fa-2x text-primary"></i>
                            </div>
                            <div>
                                <h6 class="text-muted mb-1">Total Jam</h6>
                                <h2 class="mb-0 fw-bold"><?= number_format($total_jam_lembur, 1) ?></h2>
                                <small class="text-muted">Jam lembur total</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Filter Section -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-4 mb-3 mb-md-0">
                        <h6 class="mb-0">Filter Status:</h6>
                    </div>
                    <div class="col-md-8">
                        <div class="d-flex flex-wrap gap-2">
                            <a href="?filter=all" class="btn btn-sm <?= $filter_status == 'all' ? 'btn-primary' : 'btn-outline-primary' ?>">
                                Semua <span class="badge bg-light text-dark ms-1"><?= $total_lembur ?></span>
                            </a>
                            <a href="?filter=pending" class="btn btn-sm <?= $filter_status == 'pending' ? 'btn-warning' : 'btn-outline-warning' ?>">
                                <i class="fas fa-clock me-1"></i> Menunggu <span class="badge bg-light text-dark ms-1"><?= $total_pending ?></span>
                            </a>
                            <a href="?filter=approved" class="btn btn-sm <?= $filter_status == 'approved' ? 'btn-success' : 'btn-outline-success' ?>">
                                <i class="fas fa-check me-1"></i> Disetujui <span class="badge bg-light text-dark ms-1"><?= $total_approved ?></span>
                            </a>
                            <a href="?filter=rejected" class="btn btn-sm <?= $filter_status == 'rejected' ? 'btn-danger' : 'btn-outline-danger' ?>">
                                <i class="fas fa-times me-1"></i> Ditolak <span class="badge bg-light text-dark ms-1"><?= $total_rejected ?></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Data Table -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">
                    <i class="fas fa-list me-2"></i> Daftar Pengajuan Lembur
                    <small class="text-muted">(<?= $filter_status == 'all' ? 'Semua' : ucfirst($filter_status) ?>)</small>
                </h5>
            </div>
            
            <?php if (!$filtered_result || mysqli_num_rows($filtered_result) == 0): ?>
            <div class="card-body">
                <div class="text-center py-5">
                    <i class="fas fa-clock fa-4x text-muted mb-3"></i>
                    <h4 class="text-muted">Tidak ada data lembur</h4>
                    <p class="text-muted mb-4">
                        <?php if ($filter_status == 'all'): ?>
                        Belum ada pengajuan lembur dari karyawan.
                        <?php else: ?>
                        Tidak ada pengajuan lembur dengan status "<?= ucfirst($filter_status) ?>".
                        <?php endif; ?>
                    </p>
                    
                    <?php if ($filter_status !== 'all'): ?>
                    <a href="?filter=all" class="btn btn-outline-primary">
                        <i class="fas fa-eye me-2"></i> Lihat Semua Data
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <?php else: ?>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th width="50">No</th>
                                <th>Tanggal</th>
                                <th>Karyawan</th>
                                <th>Waktu Lembur</th>
                                <th>Durasi</th>
                                <th>Alasan</th>
                                <th>Status</th>
                                <th width="150" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $no = 1;
                            $total_jam_filtered = 0;
                            while ($lembur = mysqli_fetch_assoc($filtered_result)):
                                $jam_lembur = floatval($lembur['jam_lembur']);
                                $total_jam_filtered += $jam_lembur;
                                
                                // Format tanggal
                                $tanggal = date('d M Y', strtotime($lembur['tanggal']));
                                $jam_mulai = date('H:i', strtotime($lembur['jam_mulai']));
                                $jam_akhir = date('H:i', strtotime($lembur['jam_akhir']));
                                
                                // Status class
                                $status_class = strtolower($lembur['status_approv']);
                                $status_badge_class = "badge-" . $status_class;
                            ?>
                            <tr class="lembur-row <?= $status_class ?>">
                                <td><?= $no++ ?></td>
                                <td>
                                    <strong><?= $tanggal ?></strong><br>
                                    <small class="text-muted"><?= date('l', strtotime($lembur['tanggal'])) ?></small>
                                </td>
                                <td>
                                    <div>
                                        <strong><?= htmlspecialchars($lembur['nama_lengkap']) ?></strong><br>
                                        <small class="text-muted"><?= $lembur['jabatan'] ?></small><br>
                                        <small><code><?= $lembur['username'] ?></code></small>
                                    </div>
                                </td>
                                <td>
                                    <div class="time-badge d-inline-block">
                                        <i class="fas fa-play text-success me-1"></i> <?= $jam_mulai ?><br>
                                        <i class="fas fa-stop text-danger me-1"></i> <?= $jam_akhir ?>
                                    </div>
                                </td>
                                <td>
                                    <strong class="text-primary"><?= number_format($jam_lembur, 1) ?> jam</strong><br>
                                    <small class="text-muted"><?= $lembur['durasi'] ?></small>
                                </td>
                                <td>
                                    <?php if (!empty($lembur['alasan'])): ?>
                                    <div class="small"><?= htmlspecialchars(substr($lembur['alasan'], 0, 50)) ?>
                                        <?php if (strlen($lembur['alasan']) > 50): ?>
                                        ... <a href="#" class="text-primary" data-bs-toggle="popover" 
                                              data-bs-content="<?= htmlspecialchars($lembur['alasan']) ?>">
                                            selengkapnya
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                    <?php else: ?>
                                    <span class="text-muted small">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="status-badge <?= $status_badge_class ?>">
                                        <?php 
                                        $status_text = [
                                            'pending' => 'Menunggu',
                                            'approved' => 'Disetujui',
                                            'rejected' => 'Ditolak'
                                        ];
                                        echo $status_text[$status_class];
                                        ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <?php if ($lembur['status_approv'] == 'Pending'): ?>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-outline-success" 
                                                onclick="confirmAction(<?= $lembur['id'] ?>, 'approve', '<?= htmlspecialchars($lembur['nama_lengkap']) ?>', '<?= $tanggal ?>', <?= number_format($jam_lembur, 1) ?>)">
                                            <i class="fas fa-check"></i>
                                        </button>
                                        <button class="btn btn-outline-danger"
                                                onclick="confirmAction(<?= $lembur['id'] ?>, 'reject', '<?= htmlspecialchars($lembur['nama_lengkap']) ?>', '<?= $tanggal ?>', <?= number_format($jam_lembur, 1) ?>)">
                                            <i class="fas fa-times"></i>
                                        </button>
                                        <button class="btn btn-outline-info" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#detailModal<?= $lembur['id'] ?>">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </div>
                                    <?php else: ?>
                                    <button class="btn btn-outline-info btn-sm" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#detailModal<?= $lembur['id'] ?>">
                                        <i class="fas fa-eye me-1"></i> Detail
                                    </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            
                            <!-- Detail Modal -->
                            <div class="modal fade" id="detailModal<?= $lembur['id'] ?>" tabindex="-1">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">
                                                <i class="fas fa-info-circle me-2"></i>
                                                Detail Pengajuan Lembur
                                            </h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <h6>Data Karyawan</h6>
                                                    <table class="table table-sm">
                                                        <tr>
                                                            <td width="40%">Nama</td>
                                                            <td><?= htmlspecialchars($lembur['nama_lengkap']) ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Jabatan</td>
                                                            <td><?= $lembur['jabatan'] ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Username</td>
                                                            <td><code><?= $lembur['username'] ?></code></td>
                                                        </tr>
                                                    </table>
                                                </div>
                                                <div class="col-md-6">
                                                    <h6>Detail Lembur</h6>
                                                    <table class="table table-sm">
                                                        <tr>
                                                            <td width="40%">Tanggal</td>
                                                            <td><?= $tanggal ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Jam Mulai</td>
                                                            <td><?= $jam_mulai ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Jam Selesai</td>
                                                            <td><?= $jam_akhir ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Durasi</td>
                                                            <td><strong><?= number_format($jam_lembur, 1) ?> jam</strong></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Status</td>
                                                            <td>
                                                                <span class="status-badge <?= $status_badge_class ?>">
                                                                    <?= $status_text[$status_class] ?>
                                                                </span>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </div>
                                            </div>
                                            
                                            <div class="mt-3">
                                                <h6>Alasan Lembur</h6>
                                                <div class="card card-body bg-light">
                                                    <?= !empty($lembur['alasan']) ? nl2br(htmlspecialchars($lembur['alasan'])) : '<span class="text-muted">Tidak ada alasan</span>' ?>
                                                </div>
                                            </div>
                                            
                                            <?php if ($lembur['status_approv'] == 'Pending'): ?>
                                            <div class="mt-4">
                                                <h6>Persetujuan</h6>
                                                <div class="d-flex gap-2">
                                                    <button class="btn btn-success flex-fill" 
                                                            onclick="confirmAction(<?= $lembur['id'] ?>, 'approve', '<?= htmlspecialchars($lembur['nama_lengkap']) ?>', '<?= $tanggal ?>', <?= number_format($jam_lembur, 1) ?>)">
                                                        <i class="fas fa-check me-2"></i> Setujui Lembur
                                                    </button>
                                                    <button class="btn btn-danger flex-fill"
                                                            onclick="confirmAction(<?= $lembur['id'] ?>, 'reject', '<?= htmlspecialchars($lembur['nama_lengkap']) ?>', '<?= $tanggal ?>', <?= number_format($jam_lembur, 1) ?>)">
                                                        <i class="fas fa-times me-2"></i> Tolak Lembur
                                                    </button>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </tbody>
                        <tfoot class="table-light">
                            <tr>
                                <td colspan="4" class="text-end"><strong>Total Jam Lembur:</strong></td>
                                <td colspan="4">
                                    <strong class="text-primary"><?= number_format($total_jam_filtered, 1) ?> jam</strong>
                                    <small class="text-muted ms-2">
                                        (<?= mysqli_num_rows($filtered_result) ?> pengajuan)
                                    </small>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="card-footer bg-white py-3">
                <div class="d-flex justify-content-between align-items-center">
                    <small class="text-muted">
                        <i class="fas fa-info-circle me-1"></i>
                        Total <?= mysqli_num_rows($filtered_result ?? []) ?> data lembur
                    </small>
                    <small class="text-muted">
                        HRIS Aradea Store &copy; <?= date('Y') ?>
                    </small>
                </div>
            </div>
        </div>
    </div>

    <!-- Export Modal -->
    <div class="modal fade" id="exportModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-download me-2"></i> Export Data Lembur</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="exportForm" action="export_lembur.php" method="POST">
                        <div class="mb-3">
                            <label class="form-label">Periode</label>
                            <div class="row g-2">
                                <div class="col">
                                    <input type="text" class="form-control datepicker" name="start_date" placeholder="Dari Tanggal">
                                </div>
                                <div class="col">
                                    <input type="text" class="form-control datepicker" name="end_date" placeholder="Sampai Tanggal">
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Format Export</label>
                            <select class="form-select" name="format">
                                <option value="excel">Excel (.xlsx)</option>
                                <option value="pdf">PDF (.pdf)</option>
                                <option value="csv">CSV (.csv)</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Filter Status</label>
                            <select class="form-select" name="status_filter">
                                <option value="all">Semua Status</option>
                                <option value="pending">Menunggu</option>
                                <option value="approved">Disetujui</option>
                                <option value="rejected">Ditolak</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" form="exportForm" class="btn btn-primary">
                        <i class="fas fa-download me-2"></i> Export Data
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Flatpickr -->
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://npmcdn.com/flatpickr/dist/l10n/id.js"></script>
    
    <script>
        // Initialize datepicker
        flatpickr('.datepicker', {
            dateFormat: 'Y-m-d',
            locale: 'id',
            allowInput: true
        });
        
        // Confirm action function
        function confirmAction(lemburId, action, namaKaryawan, tanggal, jamLembur) {
            const actionText = action === 'approve' ? 'menyetujui' : 'menolak';
            
            let message = `Anda yakin ingin ${actionText} lembur untuk:\n\n`;
            message += `Karyawan: ${namaKaryawan}\n`;
            message += `Tanggal: ${tanggal}\n`;
            message += `Jam Lembur: ${jamLembur} jam\n\n`;
            
            if (action === 'approve') {
                message += `*Lembur ini akan dicatat dalam sistem penggajian`;
            } else {
                message += `*Pengajuan akan ditolak dan tidak bisa diajukan kembali`;
            }
            
            if (confirm(message)) {
                window.location.href = `persetujuan_lembur.php?action=${action}&id=${lemburId}`;
            }
        }
        
        // Initialize popovers
        const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
        popoverTriggerList.map(popoverTriggerEl => new bootstrap.Popover(popoverTriggerEl));
        
        // Auto-hide alerts after 5 seconds
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
        
        // Highlight pending rows
        document.addEventListener('DOMContentLoaded', function() {
            const pendingRows = document.querySelectorAll('.lembur-row.pending');
            pendingRows.forEach(row => {
                row.classList.add('table-warning');
            });
        });
    </script>
</body>
</html>
<?php
// Clean up
if (isset($result) && $result) {
    mysqli_free_result($result);
}
if (isset($filtered_result) && $filtered_result) {
    mysqli_free_result($filtered_result);
}
mysqli_close($koneksi);
?>