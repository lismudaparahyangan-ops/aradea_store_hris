<?php
// Panggil session check dan koneksi database
include '../config/koneksi.php';
include '../config/check_session.php'; 

if ($_SESSION['role'] !== 'Admin') {
    header('Location: ../index.php');
    exit;
}

// 1. Ambil Barcode ID dari URL untuk identifikasi data yang diedit
$barcode_id_edit = mysqli_real_escape_string($koneksi, $_GET['id']);

// 2. Query untuk mengambil data yang akan diedit (JOIN 2 tabel)
$query = "
    SELECT 
        u.id AS user_id, u.username, u.password, u.role, 
        k.nama_lengkap, k.jabatan, k.barcode_id
    FROM 
        users u
    JOIN 
        karyawan k ON u.id = k.user_id
    WHERE 
        k.barcode_id = '$barcode_id_edit'
";

$result = mysqli_query($koneksi, $query);
$data = mysqli_fetch_assoc($result);

// Cek apakah data ditemukan
if (!$data) {
    die("Data karyawan tidak ditemukan.");
}

// Data options untuk select box
$jabatan_options = ['Kasir', 'General Service', 'Gudang'];
$role_options = ['Admin', 'Karyawan'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Karyawan - HRIS Aradea Store</title>
    <style>
        .form-group { margin-bottom: 15px; }
        label { display: block; font-weight: bold; }
        input[type="text"], input[type="password"], select { width: 100%; padding: 8px; box-sizing: border-box; }
    </style>
</head>
<body>
    <h2>Edit Data Karyawan: <?php echo $data['nama_lengkap']; ?></h2>
    <p><a href="manajemen_karyawan.php">Kembali ke Manajemen Karyawan</a></p>

    <form action="edit_karyawan_proses.php" method="POST">
        
        <input type="hidden" name="user_id" value="<?php echo $data['user_id']; ?>">
        <input type="hidden" name="old_barcode_id" value="<?php echo $data['barcode_id']; ?>">
        
        <h3>A. Data Login dan Akses</h3>
        <div class="form-group">
            <label for="username">Username (Login):</label>
            <input type="text" id="username" name="username" value="<?php echo $data['username']; ?>" required>
        </div>
        
        <div class="form-group">
            <label for="password">Password Baru (Kosongkan jika tidak diubah):</label>
            <input type="password" id="password" name="password">
            <small>*Masukkan password baru jika ingin mengubah password lama.</small>
        </div>
        <div class="form-group">
            <label for="role">Role Sistem:</label>
            <select id="role" name="role" required>
                <?php foreach ($role_options as $role): ?>
                    <option value="<?php echo $role; ?>" <?php echo ($data['role'] == $role) ? 'selected' : ''; ?>>
                        <?php echo $role; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <hr>

        <h3>B. Data Detail Karyawan</h3>
        <div class="form-group">
            <label for="nama_lengkap">Nama Lengkap:</label>
            <input type="text" id="nama_lengkap" name="nama_lengkap" value="<?php echo $data['nama_lengkap']; ?>" required>
        </div>
        <div class="form-group">
            <label for="jabatan">Jabatan:</label>
            <select id="jabatan" name="jabatan" required>
                <?php foreach ($jabatan_options as $jabatan): ?>
                    <option value="<?php echo $jabatan; ?>" <?php echo ($data['jabatan'] == $jabatan) ? 'selected' : ''; ?>>
                        <?php echo $jabatan; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="barcode_id">ID Barcode:</label>
            <input type="text" id="barcode_id" name="barcode_id" value="<?php echo $data['barcode_id']; ?>" required>
            <small>*ID Barcode harus unik.</small>
        </div>
        
        <button type="submit" name="submit">Simpan Perubahan</button>
    </form>
</body>
</html>

<?php
mysqli_close($koneksi);
?>