<?php
include '../config/koneksi.php';
include '../config/check_session.php';

if ($_SESSION['role'] !== 'Admin') {
    header('Location: ../index.php');
    exit;
}

$filter_bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('Y-m');
$filter_karyawan = isset($_GET['karyawan']) ? $_GET['karyawan'] : '';

// Ambil data karyawan untuk filter
$query_karyawan = "SELECT k.id, k.nama_lengkap FROM karyawan k ORDER BY k.nama_lengkap";
$result_karyawan = mysqli_query($koneksi, $query_karyawan);

// Query untuk laporan absensi
$where_conditions = [];
$params = [];

if ($filter_bulan) {
    $where_conditions[] = "DATE_FORMAT(a.tanggal, '%Y-%m') = ?";
    $params[] = $filter_bulan;
}

if ($filter_karyawan) {
    $where_conditions[] = "a.karyawan_id = ?";
    $params[] = $filter_karyawan;
}

$where_sql = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

$query_laporan = "SELECT a.*, k.nama_lengkap, k.jabatan, k.barcode_id 
                  FROM absensi a 
                  JOIN karyawan k ON a.karyawan_id = k.id 
                  $where_sql
                  ORDER BY a.tanggal DESC, k.nama_lengkap";

// Prepare statement untuk keamanan
if (!empty($params)) {
    $stmt = mysqli_prepare($koneksi, $query_laporan);
    
    // Binding parameters
    $types = str_repeat('s', count($params));
    mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    $result_laporan = mysqli_stmt_get_result($stmt);
} else {
    $result_laporan = mysqli_query($koneksi, $query_laporan);
}

$laporan_data = [];
if ($result_laporan) {
    while ($row = mysqli_fetch_assoc($result_laporan)) {
        $laporan_data[] = $row;
    }
}

// Hitung statistik
$query_stats = "SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status_kehadiran = 'Hadir' THEN 1 ELSE 0 END) as hadir,
                SUM(CASE WHEN status_kehadiran = 'Terlambat' THEN 1 ELSE 0 END) as terlambat,
                SUM(CASE WHEN status_kehadiran = 'Sakit' THEN 1 ELSE 0 END) as sakit,
                SUM(CASE WHEN status_kehadiran = 'Izin' THEN 1 ELSE 0 END) as izin,
                SUM(CASE WHEN status_kehadiran = 'Alpha' THEN 1 ELSE 0 END) as alpha
                FROM absensi a $where_sql";

if (!empty($params)) {
    $stmt_stats = mysqli_prepare($koneksi, $query_stats);
    mysqli_stmt_bind_param($stmt_stats, $types, ...$params);
    mysqli_stmt_execute($stmt_stats);
    $result_stats = mysqli_stmt_get_result($stmt_stats);
} else {
    $result_stats = mysqli_query($koneksi, $query_stats);
}

$stats = mysqli_fetch_assoc($result_stats);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Absensi - HRIS Aradea Store</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3a0ca3;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: #f8fafc;
        }
        
        .main-content {
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
        }
        
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
        }
        
        .card-header-custom {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border-radius: 10px 10px 0 0 !important;
        }
        
        .filter-card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            padding: 20px;
            margin-bottom: 25px;
        }
        
        .stat-card {
            border-radius: 10px;
            border: none;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            margin-bottom: 20px;
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: 260px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: #1e293b;
            color: white;
            z-index: 1000;
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid #334155;
        }
        
        .user-info {
            padding: 20px;
            border-bottom: 1px solid #334155;
        }
        
        .nav-link {
            color: #cbd5e1;
            padding: 12px 20px;
            transition: all 0.3s;
        }
        
        .nav-link:hover {
            color: white;
            background-color: #334155;
        }
        
        .nav-link.active {
            color: white;
            background-color: #3b82f6;
        }
        
        .nav-link i {
            width: 20px;
            text-align: center;
        }
        
        .print-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 100;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
    <!-- Sidebar sama seperti di absensi_manual.php -->
    <!-- ... kode sidebar ... -->
    
    <div class="main-content">
        <div class="mb-4">
            <a href="absensi_manual.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Kembali ke Absensi
            </a>
        </div>
        
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-1"><i class="fas fa-chart-bar me-2"></i> Laporan Absensi</h1>
                <p class="text-muted mb-0">Analisis dan monitoring data absensi karyawan</p>
            </div>
        </div>
        
        <!-- Filter -->
        <div class="filter-card">
            <h5 class="mb-3"><i class="fas fa-filter me-2"></i> Filter Laporan</h5>
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Bulan</label>
                    <input type="month" class="form-control" name="bulan" value="<?= $filter_bulan ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Karyawan</label>
                    <select class="form-select" name="karyawan">
                        <option value="">Semua Karyawan</option>
                        <?php while ($k = mysqli_fetch_assoc($result_karyawan)): ?>
                        <option value="<?= $k['id'] ?>" <?= $filter_karyawan == $k['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($k['nama_lengkap']) ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-2"></i> Filter
                    </button>
                </div>
            </form>
        </div>
        
        <!-- Statistik -->
        <div class="row">
            <div class="col-md-2">
                <div class="stat-card card border-primary">
                    <div class="card-body text-center">
                        <h1 class="display-6 text-primary">
                            <?= $stats['total'] ?? 0 ?>
                        </h1>
                        <h6 class="card-title text-muted">Total Absensi</h6>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stat-card card border-success">
                    <div class="card-body text-center">
                        <h1 class="display-6 text-success">
                            <?= $stats['hadir'] ?? 0 ?>
                        </h1>
                        <h6 class="card-title text-muted">Hadir</h6>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stat-card card border-warning">
                    <div class="card-body text-center">
                        <h1 class="display-6 text-warning">
                            <?= $stats['terlambat'] ?? 0 ?>
                        </h1>
                        <h6 class="card-title text-muted">Terlambat</h6>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stat-card card border-info">
                    <div class="card-body text-center">
                        <h1 class="display-6 text-info">
                            <?= $stats['sakit'] ?? 0 ?>
                        </h1>
                        <h6 class="card-title text-muted">Sakit</h6>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stat-card card border-secondary">
                    <div class="card-body text-center">
                        <h1 class="display-6 text-secondary">
                            <?= $stats['izin'] ?? 0 ?>
                        </h1>
                        <h6 class="card-title text-muted">Izin</h6>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stat-card card border-danger">
                    <div class="card-body text-center">
                        <h1 class="display-6 text-danger">
                            <?= $stats['alpha'] ?? 0 ?>
                        </h1>
                        <h6 class="card-title text-muted">Alpha</h6>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Tabel Laporan -->
        <div class="table-responsive mt-4">
            <table class="table table-hover table-striped mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Karyawan</th>
                        <th>Tanggal</th>
                        <th>Jam Masuk</th>
                        <th>Jam Keluar</th>
                        <th>Status</th>
                        <th>Durasi</th>
                        <th>Jabatan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($laporan_data)): ?>
                    <tr>
                        <td colspan="8" class="text-center py-4">
                            <i class="fas fa-chart-bar fa-2x text-muted mb-2 d-block"></i>
                            <p class="text-muted mb-0">Tidak ada data absensi untuk filter ini</p>
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($laporan_data as $index => $data): ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><?= htmlspecialchars($data['nama_lengkap']) ?></td>
                        <td><?= date('d M Y', strtotime($data['tanggal'])) ?></td>
                        <td><?= $data['jam_masuk'] ? date('H:i', strtotime($data['jam_masuk'])) : '-' ?></td>
                        <td><?= $data['jam_keluar'] ? date('H:i', strtotime($data['jam_keluar'])) : '-' ?></td>
                        <td>
                            <?php
                            $badge_class = '';
                            switch ($data['status_kehadiran']) {
                                case 'Hadir': $badge_class = 'badge bg-success'; break;
                                case 'Terlambat': $badge_class = 'badge bg-warning'; break;
                                case 'Sakit': $badge_class = 'badge bg-info'; break;
                                case 'Izin': $badge_class = 'badge bg-secondary'; break;
                                case 'Alpha': $badge_class = 'badge bg-danger'; break;
                            }
                            ?>
                            <span class="<?= $badge_class ?>"><?= $data['status_kehadiran'] ?></span>
                        </td>
                        <td>
                            <?php
                            if ($data['jam_masuk'] && $data['jam_keluar']) {
                                $start = new DateTime($data['jam_masuk']);
                                $end = new DateTime($data['jam_keluar']);
                                $diff = $start->diff($end);
                                echo $diff->format('%H jam %I menit');
                            } else {
                                echo '-';
                            }
                            ?>
                        </td>
                        <td><?= $data['jabatan'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Tombol Print -->
        <button class="btn btn-primary print-btn" onclick="window.print()" title="Cetak Laporan">
            <i class="fas fa-print fa-lg"></i>
        </button>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Print styles
        const style = document.createElement('style');
        style.innerHTML = `
            @media print {
                .sidebar, .print-btn, .filter-card, .btn {
                    display: none !important;
                }
                .main-content {
                    margin-left: 0 !important;
                    padding: 0 !important;
                }
                body {
                    background-color: white !important;
                }
                .table {
                    font-size: 12px;
                }
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>
<?php
mysqli_close($koneksi);
?>