<?php
// Panggil session check dan koneksi database
include '../config/koneksi.php';
include '../config/check_session.php'; 

// Pastikan hanya Admin yang bisa mengakses
if ($_SESSION['role'] !== 'Admin') {
    header('Location: ../index.php');
    exit;
}

if (isset($_POST['submit'])) {
    
    // Ambil data dari form dan sanitasi (pencegahan SQL Injection)
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);
    $role = mysqli_real_escape_string($koneksi, $_POST['role']);
    
    $nama_lengkap = mysqli_real_escape_string($koneksi, $_POST['nama_lengkap']);
    $jabatan = mysqli_real_escape_string($koneksi, $_POST['jabatan']);
    $barcode_id = mysqli_real_escape_string($koneksi, $_POST['barcode_id']);
    
    // Default sisa cuti (sudah diatur di DB, tapi kita bisa tentukan di sini juga)
    $sisa_cuti = 12;

    // A. Query 1: INSERT ke tabel users
    // Password harus di-hash (MD5 digunakan sesuai DB, tapi sebaiknya gunakan password_hash)
    $hashed_password = MD5($password); 
    
    $query_user = "INSERT INTO users (username, password, role) VALUES ('$username', '$hashed_password', '$role')";

    if (mysqli_query($koneksi, $query_user)) {
        
        // Ambil ID user yang baru saja dibuat (kunci penting untuk relasi)
        $new_user_id = mysqli_insert_id($koneksi);

        // B. Query 2: INSERT ke tabel karyawan menggunakan ID user yang baru
        $query_karyawan = "INSERT INTO karyawan (user_id, nama_lengkap, jabatan, barcode_id, sisa_cuti) 
                           VALUES ('$new_user_id', '$nama_lengkap', '$jabatan', '$barcode_id', '$sisa_cuti')";
        
        if (mysqli_query($koneksi, $query_karyawan)) {
            // Sukses!
            header('Location: manajemen_karyawan.php?status=sukses_tambah');
            exit;
        } else {
            // JIKA INSERT karyawan GAGAL (misal barcode_id duplikat), 
            // kita harus MENGHAPUS record user yang sudah terlanjur dibuat.
            $delete_user = "DELETE FROM users WHERE id='$new_user_id'";
            mysqli_query($koneksi, $delete_user); // Rollback
            
            $error_message = "Gagal menambahkan detail karyawan. Kemungkinan ID Barcode sudah digunakan.";
            // Anda bisa menyimpan pesan error ini di session dan menampilkannya di halaman form.
            echo $error_message . "<br>" . "Error Detail: " . mysqli_error($koneksi);
        }

    } else {
        // JIKA INSERT user GAGAL (misal username duplikat)
        $error_message = "Gagal menambahkan user. Kemungkinan Username sudah digunakan.";
        echo $error_message . "<br>" . "Error Detail: " . mysqli_error($koneksi);
    }
} else {
    // Jika diakses tanpa submit form
    header('Location: manajemen_karyawan.php');
}

mysqli_close($koneksi);
?>