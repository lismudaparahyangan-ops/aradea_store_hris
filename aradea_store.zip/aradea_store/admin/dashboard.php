<?php
include '../config/koneksi.php';
include '../config/check_session.php';

if ($_SESSION['role'] !== 'Admin') {
    header('Location: ../index.php');
    exit;
}

// ==============================================
// QUERY DENGAN ERROR HANDLING
// ==============================================

// Default values
$total_karyawan = 0;
$total_admin = 0;
$total_cuti = 0;

// 1. Query total karyawan
$query_karyawan = "SELECT COUNT(*) as total FROM karyawan";
$result_karyawan = mysqli_query($koneksi, $query_karyawan);

if ($result_karyawan) {
    $row = mysqli_fetch_assoc($result_karyawan);
    $total_karyawan = $row['total'] ?? 0;
} else {
    // Log error untuk debugging
    error_log("Query karyawan gagal: " . mysqli_error($koneksi));
}

// 2. Query total admin
$query_admin = "SELECT COUNT(*) as total FROM users WHERE role = 'Admin'";
$result_admin = mysqli_query($koneksi, $query_admin);

if ($result_admin) {
    $row = mysqli_fetch_assoc($result_admin);
    $total_admin = $row['total'] ?? 0;
} else {
    error_log("Query admin gagal: " . mysqli_error($koneksi));
}

// 3. Query cuti pending (jika tabel cuti ada)
$query_cuti = "SELECT COUNT(*) as total FROM cuti WHERE status = 'Pending'";
$result_cuti = mysqli_query($koneksi, $query_cuti);

if ($result_cuti) {
    $row = mysqli_fetch_assoc($result_cuti);
    $total_cuti = $row['total'] ?? 0;
} else {
    // Jika tabel cuti tidak ada, set 0
    $total_cuti = 0;
    // Tampilkan error hanya di development
    // error_log("Query cuti gagal: " . mysqli_error($koneksi));
}

// ==============================================
// CEK STRUKTUR DATABASE (UNTUK DEBUG)
// ==============================================
$debug_mode = false; // Set true untuk debugging

if ($debug_mode) {
    echo "<pre style='background: #f8f9fa; padding: 20px;'>";
    echo "=== DEBUG DATABASE ===\n";
    
    // Cek tabel yang ada
    $tables = mysqli_query($koneksi, "SHOW TABLES");
    if ($tables) {
        echo "Tabel yang tersedia:\n";
        while ($table = mysqli_fetch_array($tables)) {
            echo "- " . $table[0] . "\n";
        }
    }
    
    // Cek struktur tabel users
    echo "\nStruktur tabel users:\n";
    $users_structure = mysqli_query($koneksi, "DESCRIBE users");
    if ($users_structure) {
        while ($col = mysqli_fetch_assoc($users_structure)) {
            echo $col['Field'] . " | " . $col['Type'] . " | " . $col['Null'] . "\n";
        }
    }
    
    // Cek struktur tabel karyawan
    echo "\nStruktur tabel karyawan:\n";
    $karyawan_structure = mysqli_query($koneksi, "DESCRIBE karyawan");
    if ($karyawan_structure) {
        while ($col = mysqli_fetch_assoc($karyawan_structure)) {
            echo $col['Field'] . " | " . $col['Type'] . " | " . $col['Null'] . "\n";
        }
    }
    
    echo "</pre>";
}
?>
<!DOCTYPE html>
<html lang="id" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - HRIS Aradea Store</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3a0ca3;
            --accent-color: #4cc9f0;
            --sidebar-width: 260px;
            --sidebar-bg: #1e293b;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: #f8fafc;
            overflow-x: hidden;
        }
        
        /* Sidebar */
        .sidebar {
            width: var(--sidebar-width);
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: var(--sidebar-bg);
            color: white;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-header {
            padding: 20px 15px;
            background: rgba(0, 0, 0, 0.2);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .nav-link {
            color: #cbd5e1;
            padding: 12px 20px;
            border-left: 4px solid transparent;
            transition: all 0.2s;
            border-radius: 0;
            font-weight: 500;
        }
        
        .nav-link:hover, .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            border-left-color: var(--primary-color);
        }
        
        .nav-link i {
            width: 20px;
            margin-right: 10px;
            font-size: 1.1rem;
        }
        
        /* Main Content */
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            transition: all 0.3s;
            min-height: 100vh;
        }
        
        /* Cards */
        .dashboard-card {
            border-radius: 12px;
            border: none;
            transition: transform 0.3s, box-shadow 0.3s;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }
        
        .card-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                margin-left: -260px;
            }
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            .sidebar.active {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <div class="sidebar-header">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle p-2 me-3">
                    <i class="fas fa-store text-white fa-lg"></i>
                </div>
                <div>
                    <h4 class="mb-0 fw-bold">Aradea Store</h4>
                    <small class="text-muted">HRIS System</small>
                </div>
            </div>
        </div>
        
        <div class="user-info p-3 border-bottom border-secondary">
            <div class="d-flex align-items-center">
                <div class="position-relative">
                    <div class="bg-primary rounded-circle p-2 me-3" style="width: 50px; height: 50px;">
                        <i class="fas fa-user text-white fa-lg"></i>
                    </div>
                    <span class="position-absolute top-0 start-75 translate-middle p-1 bg-success border border-light rounded-circle">
                        <span class="visually-hidden">Online</span>
                    </span>
                </div>
                <div>
                    <h6 class="mb-0 fw-semibold"><?= htmlspecialchars($_SESSION['nama_lengkap'] ?? $_SESSION['username']) ?></h6>
                    <small class="text-muted">
                        <i class="fas fa-shield-alt me-1"></i><?= $_SESSION['role'] ?>
                    </small>
                </div>
            </div>
        </div>
        
        <ul class="nav flex-column mt-3">
            <li class="nav-item">
                <a class="nav-link active" href="dashboard.php">
                    <i class="fas fa-home"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manajemen_karyawan.php">
                    <i class="fas fa-users"></i> Data Karyawan
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="persetujuan_cuti.php">
                    <i class="fas fa-calendar-check"></i> Persetujuan Cuti
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="persetujuan_lembur.php">
                    <i class="fas fa-clock"></i> Persetujuan Lembur
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="laporan_sdm.php">
                    <i class="fas fa-chart-bar"></i> Laporan SDM
                </a>
            </li>
             <li class="nav-item">
                <a class="nav-link" href="absensi_manual.php">
                    <i class="fas fa-chart-bar"></i> Absensi
                </a>
            </li>
           
        </ul>
        
        <div class="sidebar-footer position-absolute bottom-0 w-100 p-3">
            <a href="../logout.php" class="btn btn-outline-light btn-sm w-100">
                <i class="fas fa-sign-out-alt me-1"></i> Logout
            </a>
        </div>
    </nav>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navbar -->
        <nav class="navbar navbar-light bg-white rounded-3 shadow-sm mb-4">
            <div class="container-fluid">
                <button class="btn btn-outline-primary d-md-none" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                
                <div class="d-flex align-items-center">
                    <span class="navbar-text me-3 d-none d-md-block">
                        <i class="fas fa-calendar-day me-1 text-primary"></i>
                        <?= date('l, d F Y') ?>
                    </span>
                    <div class="dropdown">
                        <button class="btn btn-light position-relative" type="button" data-bs-toggle="dropdown">
                            <i class="fas fa-bell text-primary fa-lg"></i>
                            <?php if($total_cuti > 0): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                <?= $total_cuti ?>
                            </span>
                            <?php endif; ?>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow-sm" style="min-width: 300px;">
                            <li><h6 class="dropdown-header">Notifikasi</h6></li>
                            <?php if($total_cuti > 0): ?>
                            <li>
                                <a class="dropdown-item" href="persetujuan_cuti.php">
                                    <div class="d-flex">
                                        <div class="flex-shrink-0">
                                            <i class="fas fa-calendar-times text-warning fa-lg"></i>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <h6 class="mb-0"><?= $total_cuti ?> pengajuan cuti</h6>
                                            <small class="text-muted">Menunggu persetujuan</small>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-center text-primary" href="#"><small>Lihat semua</small></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
        
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-2 fw-bold text-gray-800">Dashboard Admin</h1>
                <p class="text-muted">
                    <i class="fas fa-user-check me-1 text-success"></i>
                    Selamat datang, <span class="fw-semibold"><?= htmlspecialchars($_SESSION['nama_lengkap'] ?? $_SESSION['username']) ?></span>!
                </p>
            </div>
            <a href="tambah_karyawan.php" class="btn btn-primary text-white">
                <i class="fas fa-plus me-2"></i> Tambah Karyawan
            </a>
        </div>
        
        <!-- Stats Cards -->
        <div class="row g-4 mb-5">
            <div class="col-xl-3 col-md-6">
                <div class="card dashboard-card border-0">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Total Karyawan</h6>
                                <h2 class="mb-0 fw-bold"><?= $total_karyawan ?></h2>
                                <small class="text-muted">Aktif</small>
                            </div>
                            <div class="card-icon" style="background: rgba(67, 97, 238, 0.1);">
                                <i class="fas fa-users text-primary"></i>
                            </div>
                        </div>
                        <div class="mt-3">
                            <span class="text-success"><i class="fas fa-arrow-up me-1"></i> 5.2%</span>
                            <span class="text-muted">dari bulan lalu</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card dashboard-card border-0">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Admin & Manager</h6>
                                <h2 class="mb-0 fw-bold"><?= $total_admin ?></h2>
                                <small class="text-muted">User dengan akses</small>
                            </div>
                            <div class="card-icon" style="background: rgba(40, 167, 69, 0.1);">
                                <i class="fas fa-user-shield text-success"></i>
                            </div>
                        </div>
                        <div class="mt-3">
                            <span class="text-primary"><i class="fas fa-user-plus me-1"></i> 1 baru</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card dashboard-card border-0">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Cuti Pending</h6>
                                <h2 class="mb-0 fw-bold"><?= $total_cuti ?></h2>
                                <small class="text-muted">Menunggu persetujuan</small>
                            </div>
                            <div class="card-icon" style="background: rgba(255, 193, 7, 0.1);">
                                <i class="fas fa-calendar-times text-warning"></i>
                            </div>
                        </div>
                        <div class="mt-3">
                            <a href="persetujuan_cuti.php" class="text-decoration-none">
                                <span class="text-warning"><i class="fas fa-eye me-1"></i> Lihat detail</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="card dashboard-card border-0">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Kehadiran Hari Ini</h6>
                                <h2 class="mb-0 fw-bold">89%</h2>
                                <small class="text-muted">Dari 124 karyawan</small>
                            </div>
                            <div class="card-icon" style="background: rgba(111, 66, 193, 0.1);">
                                <i class="fas fa-user-check text-purple"></i>
                            </div>
                        </div>
                        <div class="mt-3">
                            <span class="text-danger"><i class="fas fa-user-clock me-1"></i> 13 terlambat</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Database Status Alert (jika ada masalah) -->
        <?php if ($total_karyawan === 0 && $debug_mode): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <h5><i class="fas fa-database me-2"></i> Database Warning</h5>
            <p class="mb-2">Tabel mungkin belum dibuat atau kosong.</p>
            <hr>
            <p class="mb-1"><strong>Solusi:</strong></p>
            <ol class="mb-0">
                <li>Jalankan script SQL untuk membuat tabel</li>
                <li>Pastikan koneksi database benar</li>
                <li>Cek nama database di config/koneksi.php</li>
            </ol>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <!-- Quick Actions -->
        <div class="row mb-5">
            <div class="col-12">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white py-3">
                        <h5 class="mb-0"><i class="fas fa-bolt text-primary me-2"></i> Akses Cepat</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-3 col-6">
                                <a href="manajemen_karyawan.php" class="text-decoration-none">
                                    <div class="text-center p-3 border rounded-3 hover-shadow">
                                        <div class="mb-2">
                                            <i class="fas fa-user-plus fa-2x text-primary"></i>
                                        </div>
                                        <h6 class="mb-1">Tambah Karyawan</h6>
                                        <small class="text-muted">Input data baru</small>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3 col-6">
                                <a href="persetujuan_cuti.php" class="text-decoration-none">
                                    <div class="text-center p-3 border rounded-3 hover-shadow">
                                        <div class="mb-2">
                                            <i class="fas fa-calendar-check fa-2x text-success"></i>
                                        </div>
                                        <h6 class="mb-1">Persetujuan Cuti</h6>
                                        <small class="text-muted"><?= $total_cuti ?> menunggu</small>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3 col-6">
                                <a href="laporan_sdm.php" class="text-decoration-none">
                                    <div class="text-center p-3 border rounded-3 hover-shadow">
                                        <div class="mb-2">
                                            <i class="fas fa-chart-line fa-2x text-info"></i>
                                        </div>
                                        <h6 class="mb-1">Laporan SDM</h6>
                                        <small class="text-muted">Analisis bulanan</small>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3 col-6">
                                <a href="absensi_manual.php" class="text-decoration-none">
                                    <div class="text-center p-3 border rounded-3 hover-shadow">
                                        <div class="mb-2">
                                            <i class="fas fa-chart-line fa-2x text-info"></i>
                                        </div>
                                        <h6 class="mb-1">Absensi</h6>
                                        <small class="text-muted">Absensi Karyawan</small>
                                    </div>
                                </a>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Toggle sidebar on mobile
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
        
        // Auto update time
        function updateTime() {
            const now = new Date();
            const options = { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            };
            const timeElement = document.querySelector('.navbar-text');
            if (timeElement) {
                timeElement.innerHTML = 
                    `<i class="fas fa-calendar-day me-1 text-primary"></i> ${now.toLocaleDateString('id-ID', options)}`;
            }
        }
        
        updateTime();
        setInterval(updateTime, 60000);
    </script>
</body>
</html>