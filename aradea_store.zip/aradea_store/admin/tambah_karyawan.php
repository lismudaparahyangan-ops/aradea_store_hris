<?php
include '../config/koneksi.php';
include '../config/check_session.php';

if ($_SESSION['role'] !== 'Admin') {
    header('Location: ../index.php');
    exit;
}

$jabatan_options = ['Kasir', 'General Service', 'Gudang', 'Supervisor', 'Manager'];
$role_options = ['Admin', 'Karyawan'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Karyawan Baru - HRIS Aradea Store</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3a0ca3;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        
        .form-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .form-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 25px;
        }
        
        .form-section {
            padding: 25px;
            border-bottom: 1px solid #eee;
        }
        
        .form-section:last-child {
            border-bottom: none;
        }
        
        .form-label {
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
        }
        
        .form-control, .form-select {
            border-radius: 8px;
            padding: 10px 15px;
            border: 1px solid #ddd;
            transition: all 0.3s;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(67, 97, 238, 0.25);
        }
        
        .btn-submit {
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            border: none;
            padding: 12px 30px;
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.3s;
        }
        
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 7px 14px rgba(67, 97, 238, 0.3);
        }
        
        .info-box {
            background: #e7f3ff;
            border-left: 4px solid var(--primary-color);
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .step-indicator {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
            position: relative;
        }
        
        .step-indicator::before {
            content: '';
            position: absolute;
            top: 15px;
            left: 10%;
            right: 10%;
            height: 2px;
            background: #ddd;
            z-index: 1;
        }
        
        .step {
            position: relative;
            z-index: 2;
            text-align: center;
            width: 25%;
        }
        
        .step-number {
            width: 30px;
            height: 30px;
            background: #ddd;
            color: #666;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
            font-weight: bold;
        }
        
        .step.active .step-number {
            background: var(--primary-color);
            color: white;
        }
        
        .step-title {
            font-size: 0.9rem;
            color: #666;
        }
        
        .step.active .step-title {
            color: var(--primary-color);
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="form-container">
            <div class="form-header">
                <div class="d-flex align-items-center">
                    <div class="bg-white rounded-circle p-2 me-3">
                        <i class="fas fa-user-plus text-primary fa-lg"></i>
                    </div>
                    <div>
                        <h2 class="mb-1">Tambah Karyawan Baru</h2>
                        <p class="mb-0 opacity-75">HRIS Aradea Store</p>
                    </div>
                </div>
            </div>
            
            <div class="step-indicator px-4 pt-4">
                <div class="step active">
                    <div class="step-number">1</div>
                    <div class="step-title">Data Login</div>
                </div>
                <div class="step">
                    <div class="step-number">2</div>
                    <div class="step-title">Data Personal</div>
                </div>
                <div class="step">
                    <div class="step-number">3</div>
                    <div class="step-title">Jabatan & Role</div>
                </div>
                <div class="step">
                    <div class="step-number">4</div>
                    <div class="step-title">Konfirmasi</div>
                </div>
            </div>
            
            <form action="tambah_karyawan_proses.php" method="POST" id="karyawanForm">
                <div class="form-section">
                    <div class="info-box">
                        <i class="fas fa-info-circle me-2 text-primary"></i>
                        <strong>Informasi:</strong> Pastikan semua data diisi dengan benar. ID Barcode harus unik.
                    </div>
                    
                    <h4 class="mb-4"><i class="fas fa-user-circle me-2 text-primary"></i> Data Login & Akses</h4>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="username" class="form-label">Username</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-user text-muted"></i>
                                </span>
                                <input type="text" class="form-control" id="username" name="username" 
                                       placeholder="contoh: budi.santoso" required>
                            </div>
                            <small class="text-muted">Username untuk login ke sistem</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="password" class="form-label">Password</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-lock text-muted"></i>
                                </span>
                                <input type="password" class="form-control" id="password" name="password" 
                                       placeholder="Minimal 6 karakter" required>
                                <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <small class="text-muted">Password akan dienkripsi dengan MD5</small>
                        </div>
                    </div>
                </div>
                
                <div class="form-section">
                    <h4 class="mb-4"><i class="fas fa-id-card me-2 text-primary"></i> Data Personal Karyawan</h4>
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-signature text-muted"></i>
                                </span>
                                <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" 
                                       placeholder="Masukkan nama lengkap" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="jabatan" class="form-label">Jabatan</label>
                            <select class="form-select" id="jabatan" name="jabatan" required>
                                <option value="">Pilih Jabatan</option>
                                <?php foreach ($jabatan_options as $jabatan): ?>
                                    <option value="<?= $jabatan ?>"><?= $jabatan ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="barcode_id" class="form-label">ID Barcode</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-barcode text-muted"></i>
                                </span>
                                <input type="text" class="form-control" id="barcode_id" name="barcode_id" 
                                       placeholder="Contoh: BARC0001" required>
                            </div>
                            <small class="text-muted">Harus unik, tidak boleh sama dengan karyawan lain</small>
                        </div>
                    </div>
                </div>
                
                <div class="form-section">
                    <h4 class="mb-4"><i class="fas fa-shield-alt me-2 text-primary"></i> Hak Akses & Role</h4>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="role" class="form-label">Role Sistem</label>
                            <select class="form-select" id="role" name="role" required>
                                <option value="">Pilih Role</option>
                                <?php foreach ($role_options as $role): ?>
                                    <option value="<?= $role ?>"><?= $role ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="mt-2">
                                <small class="text-muted">
                                    <i class="fas fa-info-circle me-1"></i>
                                    <strong>Admin:</strong> Akses penuh sistem<br>
                                    <strong>Karyawan:</strong> Akses terbatas (absensi, cuti)
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="form-section bg-light">
                    <div class="d-flex justify-content-between">
                        <a href="manajemen_karyawan.php" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-2"></i> Kembali
                        </a>
                        <button type="submit" name="submit" class="btn btn-submit text-white">
                            <i class="fas fa-save me-2"></i> Simpan Data Karyawan
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Toggle password visibility
        document.getElementById('togglePassword').addEventListener('click', function() {
            const passwordInput = document.getElementById('password');
            const icon = this.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
        
        // Form validation
        document.getElementById('karyawanForm').addEventListener('submit', function(e) {
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value;
            const nama_lengkap = document.getElementById('nama_lengkap').value.trim();
            const barcode_id = document.getElementById('barcode_id').value.trim();
            
            if (!username || !password || !nama_lengkap || !barcode_id) {
                e.preventDefault();
                alert('Harap isi semua field yang wajib diisi!');
                return false;
            }
            
            if (password.length < 6) {
                e.preventDefault();
                alert('Password minimal 6 karakter!');
                return false;
            }
            
            // Confirm before submit
            if (!confirm('Simpan data karyawan ini?')) {
                e.preventDefault();
                return false;
            }
        });
        
        // Auto generate barcode ID suggestion
        document.getElementById('username').addEventListener('blur', function() {
            const username = this.value.trim();
            const barcodeInput = document.getElementById('barcode_id');
            
            if (username && !barcodeInput.value) {
                // Generate suggestion from username
                const suggestion = 'BARC' + username.toUpperCase().substring(0, 4) + Math.floor(Math.random() * 1000);
                barcodeInput.value = suggestion;
                barcodeInput.setAttribute('title', 'Saran ID Barcode otomatis');
            }
        });
    </script>
</body>
</html>
<?php
mysqli_close($koneksi);
?>