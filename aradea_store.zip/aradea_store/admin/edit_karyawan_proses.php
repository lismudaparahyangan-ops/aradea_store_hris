<?php
// Panggil session check dan koneksi database
include '../config/koneksi.php';
include '../config/check_session.php'; 

if ($_SESSION['role'] !== 'Admin') {
    header('Location: ../index.php');
    exit;
}

if (isset($_POST['submit'])) {
    
    // Ambil semua data dari form
    $user_id = mysqli_real_escape_string($koneksi, $_POST['user_id']);
    $old_barcode_id = mysqli_real_escape_string($koneksi, $_POST['old_barcode_id']);
    
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $new_password = mysqli_real_escape_string($koneksi, $_POST['password']); // Password baru (bisa kosong)
    $role = mysqli_real_escape_string($koneksi, $_POST['role']);
    
    $nama_lengkap = mysqli_real_escape_string($koneksi, $_POST['nama_lengkap']);
    $jabatan = mysqli_real_escape_string($koneksi, $_POST['jabatan']);
    $barcode_id = mysqli_real_escape_string($koneksi, $_POST['barcode_id']); // Barcode ID yang baru

    
    // 1. Tentukan query UPDATE untuk tabel users
    $query_user = "UPDATE users SET 
                    username = '$username', 
                    role = '$role'";

    // Jika password baru diisi, tambahkan perubahan password ke query
    if (!empty($new_password)) {
        $hashed_password = MD5($new_password); // Hash password baru
        $query_user .= ", password = '$hashed_password'";
    }

    $query_user .= " WHERE id = '$user_id'";


    // 2. Tentukan query UPDATE untuk tabel karyawan
    $query_karyawan = "UPDATE karyawan SET 
                        nama_lengkap = '$nama_lengkap', 
                        jabatan = '$jabatan', 
                        barcode_id = '$barcode_id'
                        WHERE user_id = '$user_id'";
    
    
    // 3. Jalankan kedua query update (dalam transaksi sederhana)
    $update_success = true;

    if (!mysqli_query($koneksi, $query_user)) {
        $update_success = false;
        $error_msg = "Gagal mengupdate data login (users). Error: " . mysqli_error($koneksi);
    }
    
    if ($update_success && !mysqli_query($koneksi, $query_karyawan)) {
        $update_success = false;
        $error_msg = "Gagal mengupdate detail karyawan. Error: " . mysqli_error($koneksi);
    }

    // 4. Redirect berdasarkan hasil
    if ($update_success) {
        header('Location: manajemen_karyawan.php?status=sukses_edit');
        exit;
    } else {
        echo "Update Gagal. " . $error_msg;
        // Anda bisa memberikan link kembali ke halaman edit
    }
} else {
    // Jika diakses tanpa submit form
    header('Location: manajemen_karyawan.php');
}

mysqli_close($koneksi);
?>