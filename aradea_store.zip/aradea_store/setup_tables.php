<?php
// setup_tables.php
include 'config/koneksi.php';

echo "<h2>Setup Database Tables for Karyawan Features</h2>";
echo "<p>Membuat tabel yang diperlukan untuk fitur karyawan...</p>";

// Script SQL untuk membuat tabel
$sql_queries = [
    // Tabel cuti
    "CREATE TABLE IF NOT EXISTS cuti (
        id INT(11) PRIMARY KEY AUTO_INCREMENT,
        karyawan_id INT(11) NOT NULL,
        tanggal_mulai DATE NOT NULL,
        tanggal_akhir DATE NOT NULL,
        jenis_cuti VARCHAR(100),
        alasan TEXT,
        status_approv ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
        catatan_admin TEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (karyawan_id) REFERENCES karyawan(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
    
    // Tabel lembur
    "CREATE TABLE IF NOT EXISTS lembur (
        id INT(11) PRIMARY KEY AUTO_INCREMENT,
        karyawan_id INT(11) NOT NULL,
        tanggal DATE NOT NULL,
        jam_mulai TIME NOT NULL,
        jam_akhir TIME NOT NULL,
        alasan TEXT,
        status_approv ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
        catatan_admin TEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (karyawan_id) REFERENCES karyawan(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
    
    // Tabel absensi (jika belum ada)
    "CREATE TABLE IF NOT EXISTS absensi (
        id INT(11) PRIMARY KEY AUTO_INCREMENT,
        karyawan_id INT(11) NOT NULL,
        tanggal DATE NOT NULL,
        jam_masuk TIME,
        jam_keluar TIME,
        status_kehadiran VARCHAR(50),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_absensi (karyawan_id, tanggal),
        FOREIGN KEY (karyawan_id) REFERENCES karyawan(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
    
    // Insert data contoh untuk testing
    "INSERT IGNORE INTO cuti (karyawan_id, tanggal_mulai, tanggal_akhir, jenis_cuti, alasan, status_approv) VALUES
    (1, DATE_ADD(CURDATE(), INTERVAL 5 DAY), DATE_ADD(CURDATE(), INTERVAL 7 DAY), 'Cuti Tahunan', 'Liburan keluarga', 'Pending'),
    (2, DATE_ADD(CURDATE(), INTERVAL -10 DAY), DATE_ADD(CURDATE(), INTERVAL -8 DAY), 'Cuti Sakit', 'Demam tinggi', 'Approved');",
    
    "INSERT IGNORE INTO lembur (karyawan_id, tanggal, jam_mulai, jam_akhir, alasan, status_approv) VALUES
    (2, CURDATE(), '18:00:00', '20:00:00', 'Laporan bulanan belum selesai', 'Pending'),
    (2, DATE_ADD(CURDATE(), INTERVAL -1 DAY), '18:30:00', '21:00:00', 'Stock opname', 'Approved');",
    
    "INSERT IGNORE INTO absensi (karyawan_id, tanggal, jam_masuk, jam_keluar, status_kehadiran) VALUES
    (2, CURDATE(), '08:00:00', '17:00:00', 'Hadir'),
    (2, DATE_ADD(CURDATE(), INTERVAL -1 DAY), '08:15:00', '17:30:00', 'Hadir');"
];

// Eksekusi query
foreach ($sql_queries as $index => $query) {
    echo "<p><strong>Query #" . ($index + 1) . ":</strong> ";
    
    if (mysqli_query($koneksi, $query)) {
        echo "<span style='color: green;'>✓ Berhasil</span>";
    } else {
        echo "<span style='color: red;'>✗ Gagal: " . mysqli_error($koneksi) . "</span>";
    }
    
    echo "</p>";
}

// Cek struktur tabel
echo "<h3>Struktur Tabel Saat Ini:</h3>";
$tables = ['cuti', 'lembur', 'absensi', 'karyawan', 'users'];

foreach ($tables as $table) {
    $check = mysqli_query($koneksi, "SHOW TABLES LIKE '$table'");
    if ($check && mysqli_num_rows($check) > 0) {
        echo "<h4>Tabel: $table</h4>";
        $columns = mysqli_query($koneksi, "DESCRIBE $table");
        if ($columns) {
            echo "<table border='1' cellpadding='5' style='margin-bottom: 20px;'>";
            echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
            while ($col = mysqli_fetch_assoc($columns)) {
                echo "<tr>";
                echo "<td>" . $col['Field'] . "</td>";
                echo "<td>" . $col['Type'] . "</td>";
                echo "<td>" . $col['Null'] . "</td>";
                echo "<td>" . $col['Key'] . "</td>";
                echo "<td>" . ($col['Default'] ?? 'NULL') . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
    } else {
        echo "<p style='color: red;'>Tabel '$table' tidak ditemukan!</p>";
    }
}

// Test data
echo "<h3>Data Testing:</h3>";

// Test user karyawan
$test_user = mysqli_query($koneksi, "SELECT u.username, k.nama_lengkap, k.jabatan FROM users u JOIN karyawan k ON u.id = k.user_id WHERE u.role = 'Karyawan'");
if ($test_user && mysqli_num_rows($test_user) > 0) {
    echo "<p>Karyawan ditemukan:</p>";
    while ($user = mysqli_fetch_assoc($test_user)) {
        echo "<p>- " . $user['nama_lengkap'] . " (" . $user['username'] . ") - " . $user['jabatan'] . "</p>";
    }
} else {
    echo "<p style='color: red;'>Tidak ada user karyawan. Buat user karyawan terlebih dahulu.</p>";
    echo "<p>Gunakan SQL berikut:</p>";
    echo "<pre>
    INSERT INTO users (username, password, role) VALUES 
    ('karyawan01', MD5('123456'), 'Karyawan');
    
    SET @user_id = LAST_INSERT_ID();
    
    INSERT INTO karyawan (user_id, nama_lengkap, jabatan, barcode_id) VALUES 
    (@user_id, 'Budi Santoso', 'Kasir', 'BARC0002');
    </pre>";
}

mysqli_close($koneksi);

echo "<hr>";
echo "<h3>Instruksi:</h3>";
echo "<ol>";
echo "<li>Jalankan file ini sekali saja untuk membuat tabel</li>";
echo "<li>Hapus file setup_tables.php setelah berhasil</li>";
echo "<li>Login sebagai karyawan dengan username: <strong>karyawan01</strong>, password: <strong>123456</strong></li>";
echo "<li>Test fitur pengajuan cuti dan lembur</li>";
echo "</ol>";
?>